# Returns & Refunds Policy

Return window: 30 days from delivery date.

Damaged or defective items
If the item arrives damaged, customers can request a replacement or refund regardless of the 30-day window, after verification.
Verification can include photos of packaging, labels, and the damaged item.

Used items
Used items are eligible for return only if the product is defective and the defect is reported within 7 days from delivery.

Exclusions
Personalized items cannot be returned unless damaged on arrival.
Digital goods are non-refundable once downloaded.

Processing time
Once approved, refunds are issued to the original payment method.
