# Knowledge Base: Delivery Issues

Common problems
- Package marked delivered but not received
- Address incomplete
- Carrier delay due to weather
- Item damaged in transit

What to do when marked delivered but not received
Ask the customer to check with neighbors/building reception and wait 24 hours.
If still missing, open a carrier investigation.

Damage in transit
Treat as damage-on-arrival:
- collect photos
- verify order and delivery date
- offer replacement/refund regardless of 30-day return window after verification
