# Support Playbook (Internal)

Decision ladder
1. Confirm order details (order id, delivery date, delivery address).
2. Identify issue type: return, refund, replacement, warranty claim, shipping delay.
3. Check policy constraints: time window, exclusions, damage-on-arrival exception.

Return vs replacement for damaged items
If damage-on-arrival is verified, offer replacement first when stock is available.
If the customer requests a refund, allow refund regardless of the 30-day window after verification.

Evidence collection
Ask for:
- photo of outer box
- photo of label
- photo of damaged item
- short description of damage
