# Shipping

Standard shipping
Delivery times vary by region and carrier.
Standard shipping is typically 3–7 business days in the EU and 5–12 business days internationally.

Express shipping
Shipping: express options vary by region.
Express is available in most major EU cities and may arrive in 1–2 business days.

Tracking
All tracked shipments include a tracking link in your order confirmation email.
