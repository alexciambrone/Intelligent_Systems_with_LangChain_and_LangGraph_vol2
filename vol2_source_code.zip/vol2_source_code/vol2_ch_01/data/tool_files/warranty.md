# Warranty

Coverage
We provide a 24-month warranty for manufacturing defects for EU customers.
For non-EU customers, warranty duration may vary by local regulations.

What is covered
Manufacturing defects in materials or workmanship.
Failures under normal use.

What is not covered
Accidental damage (drops, water damage) unless the product was damaged on arrival.
Cosmetic wear and tear.

How to claim
Contact support with proof of purchase and a description of the issue.
