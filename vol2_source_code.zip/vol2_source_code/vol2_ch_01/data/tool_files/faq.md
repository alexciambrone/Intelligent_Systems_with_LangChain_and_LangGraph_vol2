# FAQ

Refund timing
Refunds: allow 5–10 business days for processing once approved.
Banks may take additional time to post the transaction.

How to request a return
Start a return from your account page or contact support with your order number.
If the order is a gift, provide the recipient email and the delivery postcode.

Damaged items
For damaged items, attach photos of the outer box and the damaged product.
Support may request additional details for verification.
