# Payments

Accepted methods
We accept major credit/debit cards and selected digital wallets.

Refund method
Refunds are returned to the original payment method only.
If the original method is unavailable, support will offer store credit where legally permitted.

Chargebacks
If you initiate a chargeback, the return/refund process is paused until the dispute is resolved.
