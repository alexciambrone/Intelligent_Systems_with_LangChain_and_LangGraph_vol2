from __future__ import annotations

from langchain_community.document_loaders import YoutubeLoader
from langchain_community.document_loaders.youtube import TranscriptFormat
from youtube_transcript_api._errors import NotTranslatable


def _load(
    url: str,
    *,
    translation: str | None,
    chunk_size_seconds: int = 120,
):
    loader = YoutubeLoader.from_youtube_url(
        url,
        add_video_info=False,          # avoid pytube (fragile)
        language=["en", "it"],         # priority order
        translation=translation,       # None = no translation
        transcript_format=TranscriptFormat.CHUNKS,
        chunk_size_seconds=chunk_size_seconds,
    )
    return loader.load()


def load_youtube_transcript(
    url: str,
    *,
    chunk_size_seconds: int = 120,
):
    # 1) Try translated transcript chunks when translation is available.
    try:
        return _load(
            url,
            translation="en",
            chunk_size_seconds=chunk_size_seconds,
        )
    except NotTranslatable:
        # 2) Fallback: load original transcript chunks without translation.
        return _load(
            url,
            translation=None,
            chunk_size_seconds=chunk_size_seconds,
        )


if __name__ == "__main__":
    url = "https://www.youtube.com/watch?v=QsYGlZkevEg"

    docs = load_youtube_transcript(
        url,
        chunk_size_seconds=60,
    )

    print(f"Loaded {len(docs)} transcript chunk(s)")

    for i, doc in enumerate(docs[:5], start=1):
        md = doc.metadata or {}

        print(f"\n--- Chunk {i} ---")
        print("Metadata keys:", sorted(md.keys()))
        print("Source:", md.get("source", "-"))
        print("Start seconds:", md.get("start_seconds", "-"))
        print("Start timestamp:", md.get("start_timestamp", "-"))
        print("Preview:", doc.page_content[:300].replace("\n", " "))

    if len(docs) > 5:
        print(f"\n... {len(docs) - 5} more chunk(s)")