from __future__ import annotations

import os
import re
from typing import Iterator

from langchain_core.documents import Document

UA = "ai-book-sitemap-ingest/1.0 (contact: you@example.com)"
os.environ.setdefault("USER_AGENT", UA)
os.environ.setdefault("LANGCHAIN_USER_AGENT", UA)

def iter_documents(loader) -> Iterator[Document]:
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()

def bs4_text_extractor(html: str) -> str:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator="\n")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return text

def crawl_support_sitemap(sitemap_url: str) -> Iterator[Document]:
    from langchain_community.document_loaders import SitemapLoader

    # filter_urls is regex-based. Escape dots if you mean literal dots.
    filter_urls = [
        r"^https://www.samsung\.com/support/.*",
    ]

    loader = SitemapLoader(
        web_path=sitemap_url,
        filter_urls=filter_urls,
        parsing_function=bs4_text_extractor,
        continue_on_failure=True,
        restrict_to_same_domain=True,  # keep it on unless you truly know what you are doing
    )

    yield from iter_documents(loader)

def demo_sitemap() -> None:
    sitemap = "https://www.samsung.com/it/sitemap.xml"
    for i, d in enumerate(crawl_support_sitemap(sitemap), start=1):
        print(f"- {i:03d} {d.metadata.get('source')}")
        print("  ", (d.page_content or "")[:140].replace("\n", " "))

if __name__ == "__main__":
    demo_sitemap()

