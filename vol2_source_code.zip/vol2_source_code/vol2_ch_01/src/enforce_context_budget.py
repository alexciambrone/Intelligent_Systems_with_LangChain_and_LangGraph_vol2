from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, List, Tuple
from langchain_core.documents import Document

try:
    import tiktoken
except Exception:
    tiktoken = None

@dataclass(frozen=True)
class Budget:
    max_prompt_tokens: int
    reserved_tokens: int = 800

def _estimate_tokens(text: str, model_encoding: str = "cl100k_base") -> int:
    if not text:
        return 0
    if tiktoken is not None:
        enc = tiktoken.get_encoding(model_encoding)
        return len(enc.encode(text))
    return max(1, len(text) // 4)

def pack_context(
    question: str,
    candidates: Iterable[Tuple[float, Document]],
    *,
    budget: Budget,
    model_encoding: str = "cl100k_base",
):
    available = max(0, budget.max_prompt_tokens - budget.reserved_tokens)
    used = _estimate_tokens(question, model_encoding=model_encoding)

    packed: List[Document] = []
    dropped: List[tuple[float, str, int, int]] = []  # (score, source, cost, would_be_used)

    for score, doc in candidates:
        overhead = 16
        cost = overhead + _estimate_tokens(doc.page_content, model_encoding=model_encoding)
        would_be_used = used + cost

        if would_be_used > available:
            src = (doc.metadata or {}).get("source", "unknown")
            dropped.append((score, src, cost, would_be_used))
            continue

        packed.append(doc)
        used = would_be_used

    return packed, dropped, available, used

def format_evidence(docs: List[Document]) -> str:
    blocks = []
    for i, d in enumerate(docs, start=1):
        src = (d.metadata or {}).get("source", "unknown")
        blocks.append(f"[E{i} | {src}]\n{d.page_content.strip()}")
    return "\n\n".join(blocks).strip()

def demo() -> None:
    question = "What’s the return window, and are there exceptions for damaged items?"

    candidates = [
        (0.92, Document(page_content="Return window: 30 days from delivery date.", metadata={"source": "policies.md"})),
        (0.90, Document(page_content="If the item arrives damaged, customers can request a replacement or refund regardless of the 30-day window, after verification.", metadata={"source": "policies.md"})),
        (0.62, Document(page_content="Refunds: allow 5–10 business days for processing once approved.", metadata={"source": "faq.md"})),
        (0.55, Document(page_content="Shipping: express options vary by region.", metadata={"source": "shipping.md"})),
    ]

    # Intentionally small budget to force drops (so you can see enforcement).
    packed, dropped, available, used = pack_context(
        question,
        candidates,
        budget=Budget(max_prompt_tokens=120, reserved_tokens=40),
    )

    print(f"Budget: max_prompt_tokens=120, reserved_tokens=40, available_for_context={available}")
    print(f"Question tokens: {_estimate_tokens(question)}")
    print(f"Packed blocks: {len(packed)}")
    print(f"Dropped blocks: {len(dropped)}")
    if dropped:
        print("\nDropped (would exceed budget):")
        for score, src, cost, would_be_used in dropped:
            print(f"  - score={score:.2f} source={src} cost={cost} would_be_used={would_be_used} > available={available}")

    evidence = format_evidence(packed)
    print("\n--- Evidence to inject into the prompt ---\n")
    print(evidence)

if __name__ == "__main__":
    demo()
