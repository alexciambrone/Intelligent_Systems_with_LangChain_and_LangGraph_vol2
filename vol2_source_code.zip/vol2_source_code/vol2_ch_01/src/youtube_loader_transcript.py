from __future__ import annotations

from langchain_community.document_loaders import YoutubeLoader
from langchain_yt_dlp.youtube_loader import YoutubeLoaderDL
from youtube_transcript_api._errors import (
    NoTranscriptFound,
    TranscriptsDisabled,
    NotTranslatable,
    VideoUnavailable,
)


def _load_captions(url: str, *, translation: str | None):
    loader = YoutubeLoader.from_youtube_url(
        url,
        add_video_info=False,      # avoid pytube
        language=["en", "it"],     # priority order
        translation=translation,   # None = no translation
    )
    return loader.load()


def load_youtube_with_transcript(url: str):
    # 1) Metadata (robust)
    meta_doc = YoutubeLoaderDL.from_youtube_url(url, add_video_info=True).load()[0]

    # 2) Transcript (captions) – try translated, then original
    transcript_text = ""
    transcript_md = {}

    try:
        docs = _load_captions(url, translation="en")
        transcript_text = docs[0].page_content or ""
        transcript_md = docs[0].metadata or {}
    except NotTranslatable:
        docs = _load_captions(url, translation=None)
        transcript_text = docs[0].page_content or ""
        transcript_md = docs[0].metadata or {}
    except (NoTranscriptFound, TranscriptsDisabled, VideoUnavailable):
        # No captions available (or blocked) – keep transcript empty
        transcript_text = ""
        transcript_md = {}

    # 3) Merge: keep yt-dlp metadata, add transcript metadata if present
    merged_md = dict(meta_doc.metadata or {})
    for k, v in (transcript_md or {}).items():
        merged_md.setdefault(k, v)

    # Put transcript into page_content
    meta_doc.page_content = (transcript_text or "").strip()
    meta_doc.metadata = merged_md
    return [meta_doc]


if __name__ == "__main__":
    url = "https://www.youtube.com/watch?v=QsYGlZkevEg"
    docs = load_youtube_with_transcript(url)

    print(f"Loaded {len(docs)} document(s)")
    d0 = docs[0]
    md = d0.metadata or {}
    print("Metadata keys:", sorted(md.keys()))
    print(
        "Metadata sample:",
        {k: md.get(k) for k in ["title", "author", "publish_date", "length", "webpage_url"]},
    )
    print("Content length:", len(d0.page_content or ""))
    print("Preview:")
    print((d0.page_content or "")[:300].replace("\n", " ") or "<EMPTY page_content>")
