from __future__ import annotations

import re
from typing import List

import requests
from langchain_core.documents import Document
from langchain_community.document_transformers import Html2TextTransformer
from langchain_text_splitters import RecursiveCharacterTextSplitter


_WS = re.compile(r"[ \t]+")


def load_webpage_as_document(url: str, timeout_s: int = 20) -> Document:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0 Safari/537.36"
        )
    }
    r = requests.get(url, headers=headers, timeout=timeout_s)
    r.raise_for_status()
    return Document(
        page_content=r.text,
        metadata={"source": url, "content_type": r.headers.get("Content-Type", "")},
    )


def normalize_shape(text: str) -> str:
    # 1) Normalize line endings (Windows \r\n -> \n)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # 2) Trim each line and drop empty lines (keeps paragraphs readable)
    lines = [ln.strip() for ln in text.split("\n")]
    text = "\n".join([ln for ln in lines if ln])
    # 3) Collapse repeated spaces/tabs (don’t touch newlines now)
    text = _WS.sub(" ", text)
    return text.strip()


def practical_clean_and_split(url: str) -> List[Document]:
    # Load
    doc = load_webpage_as_document(url)

    # HTML -> text (format-specific cleanup)
    html2text = Html2TextTransformer(ignore_links=True, ignore_images=True)
    (doc_text,) = html2text.transform_documents([doc])

    # Normalize “shape”
    cleaned = Document(
        page_content=normalize_shape(doc_text.page_content),
        metadata=dict(doc_text.metadata),
        id=doc_text.id,
    )

    # Split with quality-friendly knobs
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=900,
        chunk_overlap=120,
        strip_whitespace=True,
        add_start_index=True,
    )
    chunks = splitter.split_documents([cleaned])

    # Final gate: drop any empty chunks
    return [c for c in chunks if c.page_content and c.page_content.strip()]


if __name__ == "__main__":
    url = "https://www.lipsum.com"  # replace with a real KB/article page
    chunks = practical_clean_and_split(url)

    print(f"Chunks: {len(chunks)}")
    for i, c in enumerate(chunks[:3], start=1):
        print(f"\n--- chunk {i} ---")
        print("source:", c.metadata.get("source"))
        print("start_index:", c.metadata.get("start_index"))
        print(c.page_content[:500])
        if len(c.page_content) > 500:
            print("... [truncated]")
