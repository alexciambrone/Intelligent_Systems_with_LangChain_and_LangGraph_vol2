from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document


def _connect(sqlite_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(sqlite_path))
    conn.row_factory = sqlite3.Row  # <- makes rows dict-like
    return conn


def load_ticket_rows(
    sqlite_path: str | Path,
    *,
    only_updated_after: Optional[str] = None,  # ISO string, e.g. "2026-02-01T00:00:00"
    limit: Optional[int] = None,
) -> List[Document]:
    """
    Reads rows from SQLite and converts each row (ticket) into one LangChain Document.

    Expected schema (as per your DB seeder):
      tickets(id, subject, body, status, customer_email, updated_at)
    """
    sqlite_path = Path(sqlite_path)

    where = ""
    params: list[Any] = []

    if only_updated_after:
        where = "WHERE updated_at > ?"
        params.append(only_updated_after)

    limit_sql = ""
    if limit is not None:
        limit_sql = "LIMIT ?"
        params.append(int(limit))

    query = f"""
    SELECT
      id,
      subject,
      body,
      status,
      customer_email,
      updated_at
    FROM tickets
    {where}
    ORDER BY updated_at DESC
    {limit_sql}
    """.strip()

    docs: List[Document] = []

    conn = _connect(sqlite_path)
    try:
        cur = conn.execute(query, params)
        for r in cur.fetchall():
            # sqlite3.Row supports dict-style access
            ticket_id = r["id"]
            subject = r["subject"] or ""
            body = r["body"] or ""
            status = r["status"] or ""
            email = r["customer_email"]
            updated_at = r["updated_at"]

            page_content = f"Subject: {subject}\nStatus: {status}\n\n{body}".strip()

            docs.append(
                Document(
                    page_content=page_content,
                    metadata={
                        "source_type": "db",
                        "source": f"sqlite:///{sqlite_path.as_posix()}#tickets",
                        "ticket_id": str(ticket_id),
                        "updated_at": updated_at,
                        "status": status,
                        "customer_email": email,
                    },
                )
            )
    finally:
        conn.close()

    return docs


def print_documents(docs: List[Document], *, max_docs: int = 10, max_chars: int = 220) -> None:
    """
    Prints Documents as:
      [1] tickets:<id> | status=... | updated_at=... | email=...
          <page_content preview...>
    """
    if not docs:
        print("No documents loaded.")
        return

    total = len(docs)
    shown = min(total, max_docs)

    for i, d in enumerate(docs[:shown], start=1):
        md = d.metadata or {}
        ticket_id = md.get("ticket_id", "?")
        status = md.get("status", "")
        updated_at = md.get("updated_at")
        email = md.get("customer_email") or "-"

        text = (d.page_content or "").replace("\r\n", "\n").replace("\r", "\n").strip()
        preview = text if len(text) <= max_chars else text[: max_chars - 1] + "…"
        preview = preview.replace("\n", " ")

        # Match your desired header style
        print(f"[{i}] tickets:{ticket_id} | status={status} | updated_at={updated_at} | email={email}")
        print(f"    {preview}\n")

    if total > shown:
        print(f"Showing {shown}/{total} documents (max_docs={max_docs}).")


if __name__ == "__main__":
    sqlite_path = "./data/support.sqlite"
    docs = load_ticket_rows(sqlite_path)
    print_documents(docs, max_docs=10, max_chars=240)
