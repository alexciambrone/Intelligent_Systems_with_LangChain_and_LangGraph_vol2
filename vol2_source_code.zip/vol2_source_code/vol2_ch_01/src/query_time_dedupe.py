from __future__ import annotations
import hashlib
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors import DocumentCompressorPipeline, EmbeddingsFilter
from langchain_community.document_transformers import (
    EmbeddingsRedundantFilter,
    LongContextReorder,
)

# ============================================================
# Deterministic embeddings (offline-friendly)
# ============================================================
class DeterministicEmbeddings(Embeddings):
    """
    Deterministic embeddings so this example runs without external services.

    IMPORTANT:
    - These vectors are NOT semantically meaningful like real embedding models.
    - They exist purely to demonstrate query-time de-duplication/compression mechanics.
    """

    def __init__(self, dim: int = 64):
        self.dim = dim

    def _vec(self, text: str) -> List[float]:
        digest = hashlib.sha256((text or "").encode("utf-8")).digest()
        raw = (digest * ((self.dim // len(digest)) + 1))[: self.dim]
        v = [(b / 255.0) for b in raw]
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / n for x in v]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._vec(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._vec(text)


# ============================================================
# Demo corpus: duplicates + near-duplicates on purpose
# ============================================================
def build_demo_docs() -> List[Document]:
    return [
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={"source_id": "kb/refunds", "topic": "refunds"},
        ),
        # Exact duplicate under a different id (common in messy KBs)
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={"source_id": "kb/refunds-duplicate", "topic": "refunds"},
        ),
        # Near-duplicate (same meaning, different phrasing)
        Document(
            page_content="Once approved, refunds typically take 5 to 10 business days to process.",
            metadata={"source_id": "kb/refunds-alt", "topic": "refunds"},
        ),
        Document(
            page_content="Returns policy: you can return items within 30 days of delivery.",
            metadata={"source_id": "kb/returns-policy", "topic": "returns"},
        ),
        Document(
            page_content="Return window: 30 days from the delivery date for standard returns.",
            metadata={"source_id": "kb/returns-window", "topic": "returns"},
        ),
        Document(
            page_content="Damaged on arrival: request photos of the outer box, label, and damaged item for verification.",
            metadata={"source_id": "kb/damage-on-arrival", "topic": "returns"},
        ),
        Document(
            page_content="Shipping: express options vary by region. Standard shipping is 3–7 business days in the EU.",
            metadata={"source_id": "kb/shipping-eu", "topic": "shipping"},
        ),
        Document(
            page_content="Express shipping availability depends on the region. EU standard delivery is typically 3–7 business days.",
            metadata={"source_id": "kb/shipping-alt", "topic": "shipping"},
        ),
        Document(
            page_content="Chargebacks: if a chargeback is initiated, pause refunds until the dispute is resolved.",
            metadata={"source_id": "kb/chargebacks", "topic": "payments"},
        ),
    ]


# ============================================================
# Pretty printing + duplication stats
# ============================================================
def _norm(text: str) -> str:
    return " ".join((text or "").split()).strip().lower()


def _content_sig(text: str) -> str:
    return hashlib.sha256(_norm(text).encode("utf-8")).hexdigest()


def duplication_report(docs: List[Document]) -> Tuple[int, int, Dict[str, List[str]]]:
    """
    Returns:
      - total_docs
      - unique_content_count (by normalized content)
      - duplicates map: sig -> [source_id, ...] for groups > 1
    """
    groups: Dict[str, List[str]] = {}
    for d in docs:
        sig = _content_sig(d.page_content or "")
        sid = (d.metadata or {}).get("source_id") or "-"
        groups.setdefault(sig, []).append(sid)
    dups = {sig: sids for sig, sids in groups.items() if len(sids) > 1}
    return len(docs), len(groups), dups


def print_docs(title: str, docs: List[Document], *, preview_chars: int = 140) -> None:
    total, unique_count, dups = duplication_report(docs)

    print(f"\n=== {title} ===")
    print(f"Docs returned: {total}")
    print(f"Unique content (normalized): {unique_count}")
    if dups:
        print("Duplicate groups (same normalized content):")
        for sids in dups.values():
            print("  -", sids)
    else:
        print("Duplicate groups: -")

    for i, d in enumerate(docs, start=1):
        md = d.metadata or {}
        sid = md.get("source_id", "-")
        topic = md.get("topic", "-")
        text = (d.page_content or "").strip().replace("\n", " ")
        preview = text[:preview_chars] + ("…" if len(text) > preview_chars else "")
        print(f"\n[{i}] source_id={sid} topic={topic}")
        print(preview)


# ============================================================
# Build base retriever + compression retriever
# ============================================================
def build_vectorstore(embeddings: Embeddings) -> InMemoryVectorStore:
    vs = InMemoryVectorStore(embedding=embeddings)
    vs.add_documents(build_demo_docs())
    return vs


def build_compression_retriever(base_retriever: Any, embeddings: Embeddings) -> ContextualCompressionRetriever:
    # 1) Remove redundant docs (embedding similarity among retrieved docs)
    redundant_filter = EmbeddingsRedundantFilter(
        embeddings=embeddings,
        similarity_threshold=0.95,
    )

    # 2) Filter to the most relevant docs to the query (embedding similarity query<->doc)
    relevant_filter = EmbeddingsFilter(
        embeddings=embeddings,
        k=6,  # keep top-N after filtering
        # optional: similarity_threshold=0.6
    )

    # 3) Reorder for long-context behavior (place most relevant at beginning/end)
    reorder = LongContextReorder()

    compressor = DocumentCompressorPipeline(
        transformers=[redundant_filter, relevant_filter, reorder]
    )

    return ContextualCompressionRetriever(
        base_retriever=base_retriever,
        base_compressor=compressor,
    )


# ============================================================
# Main demo
# ============================================================
def main() -> None:
    embeddings = DeterministicEmbeddings(dim=64)

    vs = build_vectorstore(embeddings)
    base_retriever = vs.as_retriever(search_kwargs={"k": 8})

    compression_retriever = build_compression_retriever(base_retriever, embeddings)

    query = "How long do refunds take once approved?"

    # Base retrieval
    base_hits = base_retriever.invoke(query)
    print_docs("Base retrieval (higher recall, may include duplicates/noise)", base_hits)

    # Query-time de-duplication + filtering + reorder
    compressed_hits = compression_retriever.invoke(query)
    print_docs("ContextualCompressionRetriever (deduped + filtered + reordered)", compressed_hits)

    # Make the “lesson” obvious
    print(
        "\nWhat this demonstrates:\n"
        "- Base retrieval can include redundant and loosely related chunks.\n"
        "- ContextualCompressionRetriever applies a DocumentCompressorPipeline at query time:\n"
        "  (1) drop redundant documents, (2) keep only the most relevant, (3) reorder for long contexts.\n"
    )


if __name__ == "__main__":
    main()