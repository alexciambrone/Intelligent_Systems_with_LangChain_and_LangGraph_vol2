from __future__ import annotations

import os
import re
from typing import Iterator

from langchain_core.documents import Document

UA = "ai-book-support-ingest/1.0 (contact: you@example.com)"
os.environ.setdefault("USER_AGENT", UA)
os.environ.setdefault("LANGCHAIN_USER_AGENT", UA)

_boilerplate_patterns = [
    r"\bskip to main content\b",
    r"\bskip to footer\b",
    r"\bcookie preferences\b",
    r"\baccept cookies\b",
    r"\blog in\b",
]
_boilerplate_re = re.compile("|".join(_boilerplate_patterns), re.IGNORECASE)

def iter_documents(loader) -> Iterator[Document]:
    # Prefer streaming if supported; fall back to eager loading.
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()

def clean_preview(text: str, limit: int = 140) -> str:
    t = (text or "").replace("\n", " ").strip()
    t = re.sub(r"\s+", " ", t)
    t = _boilerplate_re.sub("", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t[:limit] + ("…" if len(t) > limit else "")

def load_support_articles_single_pages(urls: list[str]) -> Iterator[Document]:
    from langchain_community.document_loaders import WebBaseLoader

    try:
        loader = WebBaseLoader(
            web_path=urls,
            requests_kwargs={
                "headers": {"User-Agent": UA},
                "timeout": 15,
            },
            continue_on_failure=True,
            requests_per_second=2,
            raise_for_status=False,
        )
    except TypeError:
        # Some versions accept fewer kwargs; rely on env vars for UA.
        loader = WebBaseLoader(web_path=urls)

    yield from iter_documents(loader)

def demo_single_pages() -> None:
    urls = [
        "https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents",
        "https://platform.claude.com/cookbook/tool-use-memory-cookbook",
    ]

    for d in load_support_articles_single_pages(urls):
        md = d.metadata or {}
        title = (md.get("title") or "").strip() or "(no title)"
        source = (md.get("source") or "").strip() or "(no source)"
        print(f"- {title} | {source}")
        print("  ", clean_preview(d.page_content))

if __name__ == "__main__":
    demo_single_pages()


