from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List

from langchain_core.documents import Document
from langchain_text_splitters import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
    MarkdownHeaderTextSplitter,
    HTMLHeaderTextSplitter,
)


@dataclass(frozen=True)
class ChunkingConfig:
    # Placeholder values; tune in 9.1.11.
    chunk_size: int = 1000
    chunk_overlap: int = 200


def chunk_documents(
    docs: Iterable[Document],
    *,
    cfg: ChunkingConfig = ChunkingConfig(),
) -> List[Document]:
    """
    Baseline strategy dispatcher:
      - markdown -> header-aware
      - html     -> header-aware
      - default  -> recursive generic text
    """
    out: List[Document] = []

    # Generic fallback (recursive is a strong default for plain text).
    recursive = RecursiveCharacterTextSplitter(
        chunk_size=cfg.chunk_size,
        chunk_overlap=cfg.chunk_overlap,
    )

    # A very simple fixed splitter (sometimes useful for uniform text sources).
    fixed = CharacterTextSplitter(
        separator="\n\n",
        chunk_size=cfg.chunk_size,
        chunk_overlap=cfg.chunk_overlap,
    )

    # Structure-aware splitters.
    md_headers = [
        ("#", "H1"),
        ("##", "H2"),
        ("###", "H3"),
    ]
    md_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=md_headers,
        strip_headers=False,      # keep headers in chunk text for better grounding
        return_each_line=False,   # keep chunks section-like, not line-like
    )

    # For HTML, define which header tags map to metadata keys.
    html_headers = [("h1", "H1"), ("h2", "H2"), ("h3", "H3")]
    html_splitter = HTMLHeaderTextSplitter(headers_to_split_on=html_headers)

    for doc in docs:
        source_type = (doc.metadata or {}).get("source_type", "text")

        if source_type == "markdown":
            # MarkdownHeaderTextSplitter operates on raw text.
            splits = md_splitter.split_text(doc.page_content)
            # Preserve original metadata (source, timestamps, etc.)
            for s in splits:
                s.metadata = {**(doc.metadata or {}), **(s.metadata or {})}
            out.extend(splits)

        elif source_type == "html":
            splits = html_splitter.split_text(doc.page_content)
            for s in splits:
                s.metadata = {**(doc.metadata or {}), **(s.metadata or {})}
            out.extend(splits)

        elif source_type == "fixed_text":
            # Demonstrates a simple fixed strategy (optional).
            out.extend(fixed.split_documents([doc]))

        else:
            out.extend(recursive.split_documents([doc]))

    return out


def demo() -> None:
    docs = [
        Document(
            page_content=(
                "# Returns Policy\n\n"
                "## Window\n"
                "Returns are allowed within 30 days.\n\n"
                "## Exceptions\n"
                "Damaged items can be refunded after verification.\n"
            ),
            metadata={"source": "policies.md", "source_type": "markdown"},
        ),
        Document(
            page_content=(
                "<h1>Troubleshooting</h1>"
                "<h2>Password reset</h2>"
                "<p>Confirm identity, send reset link, remind user links expire.</p>"
                "<h2>Account locked</h2>"
                "<p>Ask for error code, check recent login attempts.</p>"
            ),
            metadata={"source": "kb.html", "source_type": "html"},
        ),
        Document(
            page_content=(
                "Support notes:\n\n"
                "If the user cannot access email, verify identity and suggest changing the email.\n\n"
                "If MFA device is lost, follow the recovery workflow."
            ),
            metadata={"source": "notes.txt", "source_type": "text"},
        ),
    ]

    chunks = chunk_documents(docs)
    for i, c in enumerate(chunks[:8], start=1):
        print(f"[{i}] {c.metadata.get('source')} | meta={ {k:v for k,v in c.metadata.items() if k in ('H1','H2','H3','source_type')} }")
        print(c.page_content.strip())
        print("-" * 60)


if __name__ == "__main__":
    demo()


