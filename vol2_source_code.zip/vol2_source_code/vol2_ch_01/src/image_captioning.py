from __future__ import annotations

import json
from pathlib import Path

from langchain_community.document_loaders import ImageCaptionLoader


def caption_images(image_paths: list[str]):
    """
    Produces Document objects where:
      - page_content = caption text
      - metadata includes the image source path
    """
    loader = ImageCaptionLoader(images=image_paths)
    return loader.load()


if __name__ == "__main__":
    # Example images (replace with real files in your repo)
    images = [
        "./data/support_images/damaged_box.jpg",
        "./data/support_images/damaged_screen.jpg",
    ]

    # Fail fast if paths are wrong
    for p in images:
        if not Path(p).exists():
            raise FileNotFoundError(f"Missing image: {p}")

    docs = caption_images(images)

    print(f"Loaded {len(docs)} document(s)")
    for i, d in enumerate(docs, start=1):
        md = d.metadata or {}

        print(f"\n[{i}]")
        print("metadata keys:", sorted(md.keys()))
        print("metadata (dict):", md)
        print("metadata (pretty):")
        print(json.dumps(md, indent=2, ensure_ascii=False))

        print("caption:", (d.page_content or "").strip())
