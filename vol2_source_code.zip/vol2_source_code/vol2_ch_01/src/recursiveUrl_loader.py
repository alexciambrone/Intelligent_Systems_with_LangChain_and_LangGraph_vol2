from __future__ import annotations

import os
import re
from typing import Iterator
from urllib.parse import urlparse

from langchain_core.documents import Document

UA = "ai-book-support-crawler/1.0 (contact: you@example.com)"
os.environ.setdefault("USER_AGENT", UA)
os.environ.setdefault("LANGCHAIN_USER_AGENT", UA)

def iter_documents(loader) -> Iterator[Document]:
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()

def bs4_text_extractor(html: str) -> str:
    # Keep this intentionally simple and deterministic.
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "html.parser")

    # Strip obvious non-content.
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return text

def same_domain(url: str) -> str:
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}"

def crawl_support_recursive(root_url: str, *, max_depth: int = 2) -> Iterator[Document]:
    from langchain_community.document_loaders import RecursiveUrlLoader

    loader = RecursiveUrlLoader(
        root_url,
        max_depth = max_depth,
        extractor = bs4_text_extractor,
        prevent_outside = True,
        base_url = same_domain(root_url),
        continue_on_failure = True,
        check_response_status = True,
        timeout = 15,
        headers = {"User-Agent": UA},
    )

    yield from iter_documents(loader)

def demo_recursive() -> None:
    root = "https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents"
    for i, d in enumerate(crawl_support_recursive(root, max_depth=2), start=1):
        print(f"\nDoc {i}: {d.metadata.get('source')}")
        print((d.page_content or "")[:220].replace("\n", " "))

if __name__ == "__main__":
    demo_recursive()


