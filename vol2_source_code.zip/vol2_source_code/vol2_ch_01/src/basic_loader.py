from __future__ import annotations

import asyncio
from dataclasses import dataclass
from itertools import islice
from typing import AsyncIterator, Iterable, Iterator, Optional, TypeVar

from langchain_core.documents import Document

T = TypeVar("T")


def batched(it: Iterable[T], size: int) -> Iterator[list[T]]:
    """
    Pipeline-level batching: group items to control throughput downstream.
    This is intentionally not part of the loader.
    """
    it = iter(it)
    while batch := list(islice(it, size)):
        yield batch


@dataclass
class ToyLoader:
    """
    A minimal loader-like object demonstrating the four execution surfaces:

    - load(): eager sync
    - lazy_load(): streaming sync
    - aload(): eager async
    - alazy_load(): streaming async

    Real loaders typically read from files/web/DB and produce Documents.
    """
    items: list[str]
    source_type: str = "toy"
    source: str = "memory://toy"

    def _to_doc(self, idx: int, text: str) -> Document:
        return Document(
            page_content=text,
            metadata={"source_type": self.source_type, "source": self.source, "row": idx},
        )

    # ---- sync eager ----
    def load(self) -> list[Document]:
        return [self._to_doc(i, t) for i, t in enumerate(self.items, start=1)]

    # ---- sync lazy ----
    def lazy_load(self) -> Iterator[Document]:
        for i, t in enumerate(self.items, start=1):
            yield self._to_doc(i, t)

    # ---- async eager ----
    async def aload(self) -> list[Document]:
        # Simulate I/O latency
        await asyncio.sleep(0.01)
        return self.load()

    # ---- async lazy ----
    async def alazy_load(self) -> AsyncIterator[Document]:
        for i, t in enumerate(self.items, start=1):
            # Simulate I/O latency per item (network/API/page fetch)
            await asyncio.sleep(0.01)
            yield self._to_doc(i, t)


def iter_documents(loader) -> Iterator[Document]:
    """
    Sync pipeline adapter.
    Prefer streaming if available; fall back to eager.
    """
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()


async def aiter_documents(loader) -> AsyncIterator[Document]:
    """
    Async pipeline adapter.
    Prefer async streaming if available; fall back to async eager.
    """
    if hasattr(loader, "alazy_load"):
        async for d in loader.alazy_load():
            yield d
    else:
        docs = await loader.aload()
        for d in docs:
            yield d


def ingest_streaming(loader, batch_size: int = 3) -> None:
    """
    Streaming sync ingestion with pipeline-level batching.
    Downstream processing is represented by printing.
    """
    for doc_batch in batched(iter_documents(loader), batch_size):
        # In a real pipeline, this is where you would:
        # - normalize (9.1.1)
        # - split into chunks (later in 9.1)
        # - embed + upsert (9.4+ / 9.5+)
        print(f"\nSYNC batch ({len(doc_batch)} docs):")
        for d in doc_batch:
            print(f"  row={d.metadata['row']}: {d.page_content!r}")


async def ingest_streaming_async(loader, batch_size: int = 3) -> None:
    """
    Streaming async ingestion with pipeline-level batching.
    """
    batch: list[Document] = []
    async for doc in aiter_documents(loader):
        batch.append(doc)
        if len(batch) >= batch_size:
            print(f"\nASYNC batch ({len(batch)} docs):")
            for d in batch:
                print(f"  row={d.metadata['row']}: {d.page_content!r}")
            batch.clear()

    if batch:
        print(f"\nASYNC final batch ({len(batch)} docs):")
        for d in batch:
            print(f"  row={d.metadata['row']}: {d.page_content!r}")


def main() -> None:
    loader = ToyLoader(
        items=[
            "Password reset policy: verify identity before reset.",
            "Return window: 30 days from delivery date.",
            "Escalation: billing disputes go to Tier 2.",
            "Shipping: express options vary by region.",
            "Refunds: allow 5–10 business days for processing.",
            "Account lockout: 5 failed attempts triggers 15-minute lock.",
        ],
        source_type="support_kb",
        source="kb://policies",
    )

    print("=== Sync streaming ingestion ===")
    ingest_streaming(loader, batch_size=2)

    print("\n=== Async streaming ingestion ===")
    asyncio.run(ingest_streaming_async(loader, batch_size=2))


if __name__ == "__main__":
    main()



