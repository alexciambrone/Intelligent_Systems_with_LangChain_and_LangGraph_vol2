from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import whisper
from langchain_core.documents import Document


def yt_dlp_json(url: str) -> dict[str, Any]:
    """
    Read YouTube video metadata using yt-dlp.

    Requires:
        yt-dlp installed and available on PATH.
    """
    p = subprocess.run(
        ["yt-dlp", "--no-playlist", "-J", url],
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(p.stdout)


def download_audio(url: str, out_dir: Path) -> Path:
    """
    Download the best available audio and convert it to MP3.

    Requires:
        yt-dlp installed and available on PATH.
        ffmpeg installed and available on PATH.
    """
    out_tpl = str(out_dir / "audio.%(ext)s")

    subprocess.run(
        [
            "yt-dlp",
            "--no-playlist",
            "-f",
            "bestaudio/best",
            "--extract-audio",
            "--audio-format",
            "mp3",
            "-o",
            out_tpl,
            url,
        ],
        check=True,
    )

    mp3 = out_dir / "audio.mp3"
    if mp3.exists():
        return mp3

    matches = list(out_dir.glob("audio.*"))
    if not matches:
        raise FileNotFoundError("Audio file not found after yt-dlp download.")

    return matches[0]


def transcribe(audio_path: Path, model_name: str = "base") -> dict[str, Any]:
    """
    Transcribe audio with Whisper.

    The important part is that we keep the full Whisper result, not only
    result["text"]. The result["segments"] field contains timestamped pieces
    of transcript, which we can convert into citation-friendly Documents.
    """
    model = whisper.load_model(model_name)
    return model.transcribe(str(audio_path))


def format_timestamp(seconds: float | int | None) -> str:
    """
    Convert seconds into a human-readable timestamp.

    Examples:
        30.0  -> 00:30
        149.0 -> 02:29
        3700  -> 01:01:40
    """
    if seconds is None:
        return "-"

    total = int(seconds)
    hours = total // 3600
    minutes = (total % 3600) // 60
    secs = total % 60

    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    return f"{minutes:02d}:{secs:02d}"


def timestamp_url(webpage_url: str, start_seconds: float | int | None) -> str:
    """
    Build a YouTube timestamp URL that opens the video at the chunk start.
    """
    if start_seconds is None:
        return webpage_url

    start = int(start_seconds)
    separator = "&" if "?" in webpage_url else "?"
    return f"{webpage_url}{separator}t={start}s"


def base_video_metadata(info: dict[str, Any], url: str) -> dict[str, Any]:
    """
    Build metadata shared by all transcript chunks.
    """
    webpage_url = info.get("webpage_url") or url

    return {
        "source": url,
        "webpage_url": webpage_url,
        "video_id": info.get("id"),
        "title": info.get("title"),
        "author": info.get("uploader") or info.get("channel"),
        "channel_id": info.get("channel_id"),
        "length": info.get("duration"),
        "publish_date": info.get("upload_date"),
        "view_count": info.get("view_count"),
    }


def whisper_segments_to_documents(
    *,
    segments: list[dict[str, Any]],
    base_metadata: dict[str, Any],
    chunk_size_seconds: int = 120,
) -> list[Document]:
    """
    Convert Whisper segments into larger timestamped Document chunks.

    Important behaviour:
    - The first chunk starts at the first non-empty Whisper segment.
    - It does not create an artificial empty chunk from 00:00.
    - This is intentional because citations should point to the moment where
      the indexed text actually begins.

    Example:
        If the video has 30 seconds of music before the first transcribed words,
        the first chunk starts at 30.0 seconds, not at 0.0.
    """
    docs: list[Document] = []

    current_texts: list[str] = []
    current_start: float | None = None
    current_end: float | None = None
    current_segment_ids: list[int] = []

    def flush() -> None:
        nonlocal current_texts, current_start, current_end, current_segment_ids

        text = " ".join(t.strip() for t in current_texts if t.strip()).strip()

        if not text:
            current_texts = []
            current_start = None
            current_end = None
            current_segment_ids = []
            return

        chunk_index = len(docs)
        webpage_url = str(base_metadata.get("webpage_url") or base_metadata.get("source"))

        metadata = {
            **base_metadata,
            "chunk_index": chunk_index,
            "start_seconds": current_start,
            "end_seconds": current_end,
            "start_timestamp": format_timestamp(current_start),
            "end_timestamp": format_timestamp(current_end),
            "timestamp_url": timestamp_url(webpage_url, current_start),
            "whisper_segment_ids": current_segment_ids,
        }

        docs.append(Document(page_content=text, metadata=metadata))

        current_texts = []
        current_start = None
        current_end = None
        current_segment_ids = []

    for segment in segments:
        text = (segment.get("text") or "").strip()

        if not text:
            continue

        start = float(segment.get("start", 0.0))
        end = float(segment.get("end", start))
        segment_id = int(segment.get("id", len(current_segment_ids)))

        if current_start is None:
            current_start = start
            current_end = end

        if current_texts:
            would_exceed = (end - current_start) > chunk_size_seconds

            if would_exceed:
                flush()
                current_start = start
                current_end = end

        current_texts.append(text)
        current_end = end
        current_segment_ids.append(segment_id)

    flush()

    return docs


def load_youtube_whisper_documents(
    url: str,
    *,
    model_name: str = "base",
    chunk_size_seconds: int = 120,
) -> list[Document]:
    """
    Download a YouTube video's audio, transcribe it with Whisper, and return
    timestamped LangChain Documents.

    Returns:
        list[Document]

    Each Document contains:
        - page_content: transcript text for that time span
        - metadata: video metadata, chunk timing, timestamp URL, and segment IDs
    """
    info = yt_dlp_json(url)

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        audio = download_audio(url, td_path)
        result = transcribe(audio, model_name=model_name)

    base_metadata = base_video_metadata(info, url)

    segments = result.get("segments") or []

    if not segments:
        text = (result.get("text") or "").strip()

        if not text:
            return []

        metadata = {
            **base_metadata,
            "chunk_index": 0,
            "start_seconds": None,
            "end_seconds": None,
            "start_timestamp": "-",
            "end_timestamp": "-",
            "timestamp_url": base_metadata.get("webpage_url") or url,
            "whisper_segment_ids": [],
        }

        return [Document(page_content=text, metadata=metadata)]

    return whisper_segments_to_documents(
        segments=segments,
        base_metadata=base_metadata,
        chunk_size_seconds=chunk_size_seconds,
    )


def print_documents_preview(docs: list[Document], *, max_docs: int = 5) -> None:
    """
    Print a useful preview of the generated transcript chunks.
    """
    print(f"Loaded {len(docs)} transcript chunk(s)")
    print()

    if not docs:
        print("No transcript text was produced.")
        return

    first_start = (docs[0].metadata or {}).get("start_seconds")

    if isinstance(first_start, (int, float)) and first_start > 0:
        print(
            "Note: the first chunk starts after 00:00 because Whisper did not "
            "return a non-empty transcript segment before that point."
        )
        print(
            "This is usually caused by intro music, silence, or audio that was "
            "not transcribed as speech."
        )
        print()

    for i, doc in enumerate(docs[:max_docs], start=1):
        md = doc.metadata or {}

        print(f"--- Chunk {i} ---")
        print("Metadata keys:", sorted(md.keys()))
        print("Title:", md.get("title"))
        print("Author:", md.get("author"))
        print("Start seconds:", md.get("start_seconds"))
        print("End seconds:", md.get("end_seconds"))
        print("Start timestamp:", md.get("start_timestamp"))
        print("End timestamp:", md.get("end_timestamp"))
        print("Timestamp URL:", md.get("timestamp_url"))

        text = (doc.page_content or "").strip()
        print("Content length:", len(text))
        print("Preview:")
        print(text[:500] if text else "<EMPTY page_content>")
        print()

    remaining = len(docs) - max_docs
    if remaining > 0:
        print(f"... {remaining} more chunk(s)")


if __name__ == "__main__":
    url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

    docs = load_youtube_whisper_documents(
        url,
        model_name="base",
        chunk_size_seconds=120,
    )

    print_documents_preview(docs)