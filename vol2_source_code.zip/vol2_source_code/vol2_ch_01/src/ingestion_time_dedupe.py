from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Dict, List

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.indexing import InMemoryRecordManager
from langchain_core.indexing.api import index
from langchain_core.vectorstores import InMemoryVectorStore


# -----------------------------
# Deterministic embeddings
# -----------------------------
class DeterministicEmbeddings(Embeddings):
    """
    Deterministic embeddings for an offline indexing demo.

    These vectors are NOT semantically meaningful. They only allow the example
    to run without calling an external embedding model.

    Because the vectors are hash-based, retrieval results should be treated as
    a smoke test that records exist in the vector store, not as meaningful
    semantic rankings.
    """

    def __init__(self, dim: int = 32):
        self.dim = dim

    def _vec(self, text: str) -> List[float]:
        digest = hashlib.sha256((text or "").encode("utf-8")).digest()
        raw = (digest * ((self.dim // len(digest)) + 1))[: self.dim]
        return [(b / 255.0) for b in raw]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._vec(text) for text in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._vec(text)


# -----------------------------
# Demo corpora: three ingestion runs
# -----------------------------
def kb_docs_run_1() -> List[Document]:
    return [
        Document(
            page_content=(
                "Reset your password:\n"
                "1) Click 'Forgot password'\n"
                "2) Check your email for the reset link\n"
                "Disclaimer: Password resets may take up to 5 minutes."
            ),
            metadata={"source_id": "kb/reset-password", "title": "Reset your password"},
        ),
        Document(
            page_content="Returns policy: you can return items within 30 days of delivery.",
            metadata={"source_id": "kb/returns-policy", "title": "Returns policy"},
        ),
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={"source_id": "kb/refunds", "title": "Refund timing"},
        ),
        Document(
            page_content=(
                "Shipping: express options vary by region. "
                "Standard shipping is 3–7 business days in the EU."
            ),
            metadata={"source_id": "kb/shipping", "title": "Shipping options"},
        ),
        Document(
            page_content="Warranty: 24 months for EU customers for manufacturing defects.",
            metadata={"source_id": "kb/warranty", "title": "Warranty"},
        ),
        Document(
            page_content="Account email change: go to Settings → Profile → Email, then confirm via link.",
            metadata={"source_id": "kb/change-email", "title": "Change your email"},
        ),
        Document(
            page_content="Order tracking: use the tracking link in the order confirmation email.",
            metadata={"source_id": "kb/order-tracking", "title": "Order tracking"},
        ),
        Document(
            page_content=(
                "Damaged on arrival: request photos of the outer box, label, "
                "and damaged item for verification."
            ),
            metadata={"source_id": "kb/damage-on-arrival", "title": "Damage on arrival"},
        ),
    ]


def kb_docs_run_2() -> List[Document]:
    """
    Changes vs run #1:
    - kb/reset-password updated
    - kb/returns-policy removed
    - kb/shipping updated
    - kb/chargebacks added
    - kb/address-correction added
    - kb/refunds-duplicate added with the same content as kb/refunds
    """
    return [
        Document(
            page_content=(
                "Reset your password:\n"
                "1) Click 'Forgot password'\n"
                "2) Check your email for the reset link\n"
                "Disclaimer: Password resets may take up to 10 minutes during peak hours."
            ),
            metadata={"source_id": "kb/reset-password", "title": "Reset your password"},
        ),
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={"source_id": "kb/refunds", "title": "Refund timing"},
        ),
        Document(
            page_content=(
                "Shipping: express options vary by region. "
                "Standard shipping is 3–7 business days in the EU "
                "and 5–12 business days internationally."
            ),
            metadata={"source_id": "kb/shipping", "title": "Shipping options"},
        ),
        Document(
            page_content="Warranty: 24 months for EU customers for manufacturing defects.",
            metadata={"source_id": "kb/warranty", "title": "Warranty"},
        ),
        Document(
            page_content="Account email change: go to Settings → Profile → Email, then confirm via link.",
            metadata={"source_id": "kb/change-email", "title": "Change your email"},
        ),
        Document(
            page_content="Order tracking: use the tracking link in the order confirmation email.",
            metadata={"source_id": "kb/order-tracking", "title": "Order tracking"},
        ),
        Document(
            page_content=(
                "Damaged on arrival: request photos of the outer box, label, "
                "and damaged item for verification."
            ),
            metadata={"source_id": "kb/damage-on-arrival", "title": "Damage on arrival"},
        ),
        Document(
            page_content="Chargebacks: if a chargeback is initiated, pause refunds until the dispute is resolved.",
            metadata={"source_id": "kb/chargebacks", "title": "Chargebacks"},
        ),
        Document(
            page_content="Address correction: contact support within 1 hour of placing the order.",
            metadata={"source_id": "kb/address-correction", "title": "Address correction"},
        ),
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={"source_id": "kb/refunds-duplicate", "title": "Refund timing duplicate"},
        ),
    ]


def kb_docs_run_3() -> List[Document]:
    return kb_docs_run_2()


# -----------------------------
# Source-level diffing
# -----------------------------
def content_hash(doc: Document) -> str:
    """
    Returns a stable hash of the document content.

    In this example, an update means:
    same source_id, different page_content hash.
    """
    return hashlib.sha256((doc.page_content or "").encode("utf-8")).hexdigest()


def snapshot(docs: List[Document]) -> Dict[str, str]:
    """
    Builds a source-level snapshot for the current ingestion run.

    The snapshot maps:
      source_id -> content_hash

    This gives us a stable, source-level view of what changed between runs,
    independently of the raw LangChain index() return fields.
    """
    out: Dict[str, str] = {}

    for doc in docs:
        source_id = (doc.metadata or {}).get("source_id")

        if not source_id:
            raise ValueError("All documents must have metadata['source_id'].")

        out[source_id] = content_hash(doc)

    return out


@dataclass(frozen=True)
class Delta:
    added: List[str]
    removed: List[str]
    updated: List[str]
    unchanged: List[str]
    duplicates_by_content: Dict[str, List[str]]


def compute_delta(prev: Dict[str, str], curr: Dict[str, str]) -> Delta:
    """
    Computes the logical source-level delta between two ingestion runs.
    """
    prev_ids = set(prev.keys())
    curr_ids = set(curr.keys())

    added = sorted(curr_ids - prev_ids)
    removed = sorted(prev_ids - curr_ids)

    updated: List[str] = []
    unchanged: List[str] = []

    for source_id in sorted(prev_ids & curr_ids):
        if prev[source_id] != curr[source_id]:
            updated.append(source_id)
        else:
            unchanged.append(source_id)

    by_hash: Dict[str, List[str]] = {}

    for source_id, hash_value in curr.items():
        by_hash.setdefault(hash_value, []).append(source_id)

    duplicates_by_content = {
        hash_value: sorted(source_ids)
        for hash_value, source_ids in by_hash.items()
        if len(source_ids) > 1
    }

    return Delta(
        added=added,
        removed=removed,
        updated=updated,
        unchanged=unchanged,
        duplicates_by_content=duplicates_by_content,
    )


# -----------------------------
# Reporting
# -----------------------------
def print_current_run_classification(delta: Delta) -> None:
    """
    Prints the current-run classification.

    These three categories must add up to the number of documents in the
    current run:

      added + updated + unchanged

    Removed documents are reported separately because they are not present in
    the current run.
    """
    current_total = len(delta.added) + len(delta.updated) + len(delta.unchanged)

    print("Current-run document classification:")
    print(f"  Added     ({len(delta.added)}): {delta.added or '-'}")
    print(f"  Updated   ({len(delta.updated)}): {delta.updated or '-'}")
    print(f"  Unchanged ({len(delta.unchanged)}): {delta.unchanged or '-'}")
    print(f"  Current docs accounted for: {current_total}")

    print("\nPrevious-run documents no longer present:")
    print(f"  Removed   ({len(delta.removed)}): {delta.removed or '-'}")


def print_source_level_indexing_summary(delta: Delta) -> None:
    """
    Prints the summary that readers should use as the conceptual model.

    This is the source-level view:
      - added means new source_id
      - updated means same source_id, changed content
      - skipped means same source_id, same content
      - removed means previously indexed source_id absent from this run
    """
    print("\nSource-level indexing summary:")
    print(f"  added:    {len(delta.added)}")
    print(f"  updated:  {len(delta.updated)}")
    print(f"  skipped:  {len(delta.unchanged)}")
    print(f"  removed:  {len(delta.removed)}")


def print_duplicates(delta: Delta) -> None:
    if delta.duplicates_by_content:
        print("\nCross-ID duplicates detected:")
        print("  Same content exists under different source_id values.")
        for _, source_ids in delta.duplicates_by_content.items():
            print("  -", source_ids)
    else:
        print("\nCross-ID duplicates detected: -")


def print_langchain_result(result: Any, delta: Delta) -> None:
    """
    Prints LangChain's raw result separately from the source-level summary.

    Important:
    LangChain's raw index() result is a physical/hash-level operation summary.
    It is not necessarily the same as the source-level business summary.

    In this demo, updated source documents can appear as:
      delete old hash + add new hash

    Therefore, a run with:
      3 source-level additions
      2 source-level updates
      5 unchanged documents
      1 source-level removal

    may produce raw LangChain output such as:
      num_added: 5
      num_deleted: 3
      num_skipped: 5
      num_updated: 0
    """
    if not isinstance(result, dict):
        print("\nRaw LangChain index() result:")
        print(result)
        return

    print("\nRaw LangChain hash-level operation summary:")
    for key in sorted(result.keys()):
        print(f"  {key}: {result[key]}")

    expected_hash_level_added = len(delta.added) + len(delta.updated)
    expected_hash_level_deleted = len(delta.removed) + len(delta.updated)
    expected_hash_level_skipped = len(delta.unchanged)

    print("\nHow the raw LangChain numbers relate to the source-level summary:")
    print(
        f"  num_added   ≈ source-level added + source-level updated "
        f"= {len(delta.added)} + {len(delta.updated)} = {expected_hash_level_added}"
    )
    print(
        f"  num_deleted ≈ source-level removed + old versions of updated documents "
        f"= {len(delta.removed)} + {len(delta.updated)} = {expected_hash_level_deleted}"
    )
    print(
        f"  num_skipped ≈ unchanged source documents "
        f"= {expected_hash_level_skipped}"
    )
    print(
        "  num_updated may remain 0 because changed documents are handled as "
        "delete old hash + add new hash rather than as in-place updates."
    )


def print_interpretation(delta: Delta) -> None:
    print("\nInterpretation:")
    print(
        "- At source level, an added document is a source_id that appears in the "
        "current run but did not exist in the previous run."
    )
    print(
        "- At source level, an updated document is a source_id that exists in both "
        "runs but has different content."
    )
    print(
        "- At source level, a skipped document is a source_id that exists in both "
        "runs with the same content."
    )
    print(
        "- At source level, a removed document is a source_id that existed before "
        "but is absent from the current run."
    )

    if delta.updated:
        print(
            "- In the raw LangChain result, updates may appear as physical add/delete "
            "operations because the changed document receives a new content-derived "
            "identity."
        )

    if delta.duplicates_by_content:
        print(
            "- Cross-ID duplicates are not automatically merged here. The duplicate "
            "documents have the same content but different source_id values."
        )


# -----------------------------
# Retrieval smoke checks
# -----------------------------
def retrieval_checks(vector_store: Any) -> None:
    queries = [
        "reset password",
        "refund processing time",
        "express shipping",
        "chargeback",
        "damage on arrival",
    ]

    print("\nRetrieval smoke checks:")
    print(
        "  These checks only show that records are searchable. "
        "Because this demo uses hash-based deterministic embeddings, "
        "the ranking is not semantically meaningful."
    )

    for query in queries:
        hits = vector_store.similarity_search(query, k=5)

        source_ids = []
        for hit in hits:
            metadata = hit.metadata or {}
            source_ids.append(metadata.get("source_id") or metadata.get("source") or "-")

        print(f"  - {query!r} -> {source_ids}")


# -----------------------------
# Indexing run
# -----------------------------
def run_indexing(
    run_name: str,
    docs: List[Document],
    record_manager: Any,
    vector_store: Any,
    prev_snap: Dict[str, str],
) -> Dict[str, str]:
    curr_snap = snapshot(docs)
    delta = compute_delta(prev_snap, curr_snap)

    print(f"\n=== {run_name} ===")
    print("Docs in this run:", len(docs))

    print_current_run_classification(delta)
    print_source_level_indexing_summary(delta)
    print_duplicates(delta)

    result = index(
        docs_source=docs,
        record_manager=record_manager,
        vector_store=vector_store,
        source_id_key="source_id",
        cleanup="full",
        key_encoder="sha256",
        batch_size=50,
    )

    print_langchain_result(result, delta)
    retrieval_checks(vector_store)
    print_interpretation(delta)

    return curr_snap


if __name__ == "__main__":
    embeddings = DeterministicEmbeddings(dim=32)
    vector_store = InMemoryVectorStore(embedding=embeddings)
    record_manager = InMemoryRecordManager(namespace="support_kb")

    prev: Dict[str, str] = {}

    prev = run_indexing(
        run_name="RUN #1 (initial ingest)",
        docs=kb_docs_run_1(),
        record_manager=record_manager,
        vector_store=vector_store,
        prev_snap=prev,
    )

    prev = run_indexing(
        run_name="RUN #2 (updated + removed + added + duplicate)",
        docs=kb_docs_run_2(),
        record_manager=record_manager,
        vector_store=vector_store,
        prev_snap=prev,
    )

    prev = run_indexing(
        run_name="RUN #3 (no changes)",
        docs=kb_docs_run_3(),
        record_manager=record_manager,
        vector_store=vector_store,
        prev_snap=prev,
    )