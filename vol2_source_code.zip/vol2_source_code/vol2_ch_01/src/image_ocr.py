from __future__ import annotations

from pathlib import Path
from langchain_community.document_loaders.image import UnstructuredImageLoader

def extract_text_from_image(image_path: str):
    """
    Returns Documents where:
      - page_content = extracted text (OCR/layout-aware extraction)
      - metadata includes the image path
    """
    loader = UnstructuredImageLoader(image_path)
    return loader.load()

if __name__ == "__main__":
    image_path = "./data/support_images/chat_image.png"

    if not Path(image_path).exists():
        raise FileNotFoundError(f"Missing image: {image_path}")

    docs = extract_text_from_image(image_path)

    print(f"Loaded {len(docs)} document(s)")
    for i, d in enumerate(docs, start=1):
        print(f"\n[{i}] image:", d.metadata.get("source") or d.metadata.get("file_path") or "-")
        preview = (d.page_content or "").strip().replace("\n", " ")
        print("extracted text preview:", preview[:400] or "<EMPTY page_content>")