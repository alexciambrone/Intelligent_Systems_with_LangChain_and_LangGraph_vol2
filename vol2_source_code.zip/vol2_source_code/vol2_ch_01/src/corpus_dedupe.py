"""
Simple, working sample: corpus-level redundancy removal BEFORE indexing.

Goal:
- Start with a set of Documents that includes near-duplicates
- Use EmbeddingsRedundantFilter to drop "same meaning" repeats
- Optionally use EmbeddingsClusteringFilter to keep a diverse set

Install:
  pip install -U langchain-community langchain-core langchain-openai

Env:
  export OPENAI_API_KEY="..."
"""

from __future__ import annotations

from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_community.document_transformers import (
    EmbeddingsRedundantFilter,
    EmbeddingsClusteringFilter,
)
from .config import OPENAI_API_KEY


def build_demo_corpus() -> list[Document]:
    # E-commerce support/KB style content with intentional near-duplicates.
    return [
        Document(
            page_content=(
                "Returns Policy (EU): You can return items within 30 days. "
                "Items must be unused and in original packaging. Refunds are issued to the original payment method."
            ),
            metadata={"source": "kb/eu_returns"},
        ),
        Document(
            page_content=(
                "Returns Policy (UK): You can return products within 30 days. "
                "Items must be unused and in original packaging. Refunds go back to the original payment method."
            ),
            metadata={"source": "kb/uk_returns"},
        ),
        Document(
            page_content=(
                "Shipping: Standard delivery takes 3–5 business days. "
                "Warranty: All products include a 24-month warranty."
            ),
            metadata={"source": "catalog/common_shipping_warranty"},
        ),
        Document(
            page_content=(
                "Warranty & Shipping: Every item includes a 24 month warranty. "
                "Standard shipping is 3 to 5 business days."
            ),
            metadata={"source": "catalog/warranty_shipping_copy"},
        ),
        Document(
            page_content=(
                "Password reset: If you forgot your password, use the 'Forgot password' link on the login page. "
                "We will email you a reset link that expires after 15 minutes."
            ),
            metadata={"source": "kb/password_reset"},
        ),
    ]


def remove_near_duplicates(docs: list[Document]) -> list[Document]:
    embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

    # 1) Drop semantically redundant items.
    # similarity_threshold: higher = stricter (keeps more), lower = more aggressive (drops more).
    redundant_filter = EmbeddingsRedundantFilter(
        embeddings=embeddings,
        similarity_threshold=0.95,
    )
    docs = list(redundant_filter.transform_documents(docs))

    # 2) Optional: keep a diverse set by clustering.
    # This is useful when you have lots of content and want “representative coverage”.
    cluster_filter = EmbeddingsClusteringFilter(
        embeddings=embeddings,
        num_clusters=min(3, len(docs)),  # keep it small for the demo
        num_closest=1,                   # pick one representative per cluster
        remove_duplicates=False,
        sorted=False,
    )
    docs = list(cluster_filter.transform_documents(docs))

    return docs


def main() -> None:
    docs = build_demo_corpus()
    print(f"Before: {len(docs)} documents")
    for d in docs:
        print(" -", d.metadata["source"])

    filtered = remove_near_duplicates(docs)
    print(f"\nAfter: {len(filtered)} documents")
    for d in filtered:
        print(" -", d.metadata["source"])
        print("   ", d.page_content[:120], "...")


if __name__ == "__main__":
    main()


