from __future__ import annotations
import os
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path("./data/support.sqlite")

def ensure_parent_dir(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)

def connect(db_path: Path) -> sqlite3.Connection:
    # isolation_level=None enables autocommit if you want it; we keep explicit commits anyway.
    return sqlite3.connect(str(db_path))

def create_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tickets (
            id         INTEGER PRIMARY KEY,
            subject    TEXT NOT NULL,
            body       TEXT NOT NULL,
            status     TEXT NOT NULL,
            customer_email TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_updated_at ON tickets(updated_at)")
    conn.commit()

def clear_existing(conn: sqlite3.Connection) -> None:
    conn.execute("DELETE FROM tickets")
    conn.commit()

def seed_data(conn: sqlite3.Connection) -> None:
    now = datetime.utcnow()

    # Small, realistic set of tickets. Keep "body" written like humans actually write.
    rows = [
        (
            1001,
            "Refund not received",
            "I returned my order last week and got the confirmation email, but I still haven't received the refund. "
            "Can you check the status and expected timeline?",
            "open",
            "maria.rossi@example.com",
            (now - timedelta(days=2)).isoformat(timespec="seconds"),
        ),
        (
            1002,
            "Wrong item delivered",
            "Order #A123 arrived today but it's the wrong size (I ordered M, received S). "
            "What is the fastest way to get the correct item?",
            "open",
            "luca.bianchi@example.com",
            (now - timedelta(days=1, hours=3)).isoformat(timespec="seconds"),
        ),
        (
            1003,
            "Shipping delay - tracking stuck",
            "Tracking has been stuck on 'Label created' for 5 days. "
            "Is this normal or should I assume the package is lost?",
            "open",
            "sara.conti@example.com",
            (now - timedelta(days=4)).isoformat(timespec="seconds"),
        ),
        (
            1004,
            "Cancel order request",
            "I placed an order 10 minutes ago and need to cancel it because I used the wrong address. "
            "Can you cancel before it ships?",
            "open",
            "gianni.ferrari@example.com",
            (now - timedelta(hours=6)).isoformat(timespec="seconds"),
        ),
        (
            1005,
            "Damaged on arrival",
            "My package arrived damaged and the item is broken. "
            "I can send photos if needed. How do I request a replacement?",
            "open",
            "anna.greco@example.com",
            (now - timedelta(days=3, hours=8)).isoformat(timespec="seconds"),
        ),
        (
            1006,
            "Invoice / VAT number missing",
            "I need an invoice with my company VAT number. "
            "I couldn't add it at checkout. Can you re-issue the invoice?",
            "open",
            "finance@acme.example",
            (now - timedelta(days=7)).isoformat(timespec="seconds"),
        ),
        (
            1007,
            "Refund policy clarification",
            "I bought an item as a gift and it was opened. "
            "Can it still be returned within 30 days? Are there exceptions?",
            "open",
            "paolo.nera@example.com",
            (now - timedelta(days=12)).isoformat(timespec="seconds"),
        ),
        (
            1008,
            "Promo code not applied",
            "The promo code WINTER10 shows as valid but the discount is not applied at checkout. "
            "Is there a minimum spend or specific category restriction?",
            "open",
            "chiara.russo@example.com",
            (now - timedelta(days=9)).isoformat(timespec="seconds"),
        ),
        (
            1009,
            "Return label request",
            "I want to return my order but I can't find the return label in my account. "
            "Can you resend it?",
            "resolved",
            "marco.lombardi@example.com",
            (now - timedelta(days=15)).isoformat(timespec="seconds"),
        ),
        (
            1010,
            "Address change after shipping",
            "My order shipped but I realized the address is wrong. "
            "Can you redirect the package or update delivery instructions?",
            "open",
            "elena.mancini@example.com",
            (now - timedelta(days=5, hours=10)).isoformat(timespec="seconds"),
        ),
        (
            1011,
            "Partial refund question",
            "I returned two items from the same order but only one shows as received in your portal. "
            "Will the refund be processed separately?",
            "open",
            "davide.moretti@example.com",
            (now - timedelta(days=6)).isoformat(timespec="seconds"),
        ),
        (
            1012,
            "Warranty coverage",
            "My item stopped working after 2 months. "
            "Is this covered by warranty and what do you need from me to start the process?",
            "open",
            "francesca.galli@example.com",
            (now - timedelta(days=20)).isoformat(timespec="seconds"),
        ),
    ]

    conn.executemany(
        """
        INSERT INTO tickets (id, subject, body, status, customer_email, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        rows,
    )
    conn.commit()

def main() -> None:
    ensure_parent_dir(DB_PATH)

    conn = connect(DB_PATH)
    try:
        create_schema(conn)
        clear_existing(conn)
        seed_data(conn)
    finally:
        conn.close()

    print(f"SQLite DB created and seeded: {DB_PATH.resolve()}")


if __name__ == "__main__":
    main()