from __future__ import annotations

# IMPORTANT: set env vars BEFORE importing LangChain community modules
import os

UA = "vol2_ch_01 multi_loader/1.0 (contact: you@example.com)"
os.environ.setdefault("USER_AGENT", UA)

# Some LangChain utilities check this one instead (depends on version)
os.environ.setdefault("LANGCHAIN_USER_AGENT", UA)

from itertools import islice
from typing import Iterable, Iterator, TypeVar
import re

from langchain_core.documents import Document

T = TypeVar("T")


def batched(it: Iterable[T], size: int) -> Iterator[list[T]]:
    """Yield items from an iterator in fixed-size batches."""
    it = iter(it)
    while batch := list(islice(it, size)):
        yield batch


def iter_documents(loader) -> Iterator[Document]:
    """Prefer streaming if supported; fall back to eager loading."""
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()


def load_support_policies_from_pdf(pdf_path: str) -> Iterator[Document]:
    """Load one PDF into Documents (one per page for PyPDFLoader)."""
    from langchain_community.document_loaders import PyPDFLoader
    yield from iter_documents(PyPDFLoader(pdf_path))


def load_support_articles_from_web(urls: list[str]) -> Iterator[Document]:
    """
    Load web pages into Documents.

    Fixes:
    - Explicitly sets User-Agent header for the HTTP request.
    - Falls back if your installed WebBaseLoader doesn't accept requests_kwargs.
    """
    from langchain_community.document_loaders import WebBaseLoader

    try:
        loader = WebBaseLoader(
            web_path=urls,
            requests_kwargs={"headers": {"User-Agent": UA}},
        )
    except TypeError:
        # Older/newer variants may not accept requests_kwargs; still rely on env vars.
        loader = WebBaseLoader(web_path=urls)

    yield from iter_documents(loader)


def load_tickets_from_sqlite(*, sqlite_path: str, query: str) -> Iterator[Document]:
    """Each SQL row becomes one Document (query defines what is 'one document')."""
    from langchain_community.document_loaders import SQLDatabaseLoader
    from langchain_community.utilities import SQLDatabase

    db = SQLDatabase.from_uri(f"sqlite:///{sqlite_path}")
    yield from iter_documents(SQLDatabaseLoader(query=query, db=db))


_boilerplate_patterns = [
    r"\bskip to main content\b",
    r"\bskip to footer\b",
    r"\blog in\b",
    r"\bstart free\b",
]
_boilerplate_re = re.compile("|".join(_boilerplate_patterns), re.IGNORECASE)


def clean_preview(text: str, limit: int = 120) -> str:
    """
    Make web-extracted text previews less ugly:
    - collapse whitespace
    - remove a few common nav boilerplate phrases
    """
    t = (text or "").replace("\n", " ").strip()
    t = re.sub(r"\s+", " ", t)
    t = _boilerplate_re.sub("", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t[:limit] + ("…" if len(t) > limit else "")


def demo() -> None:
    pdf_path = "./data/A_Brief_Introduction_To_AI.pdf"
    urls = [
        "https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents",
        "https://platform.claude.com/cookbook/tool-use-memory-cookbook",
    ]
    sqlite_path = "./data/support.sqlite"

    query = """
    SELECT id, subject, body, updated_at
    FROM tickets
    WHERE updated_at >= date('now', '-30 day')
    ORDER BY updated_at DESC
    """

    # Validate one source at a time while hardening ingestion.
    # doc_stream = load_support_policies_from_pdf(pdf_path)
    # doc_stream = load_support_articles_from_web(urls)
    doc_stream = load_tickets_from_sqlite(sqlite_path=sqlite_path, query=query)

    for i, batch in enumerate(batched(doc_stream, 8), start=1):
        print(f"\nBatch {i} ({len(batch)} docs)")
        for d in batch:
            md = d.metadata or {}
            title = (md.get("title") or "").strip() or "(no title)"
            source = (md.get("source") or "").strip() or "(no source)"
            snippet = clean_preview(d.page_content, limit=120)

            print(f"- Title : {title}")
            print(f"  Source: {source}")
            print(f"  Snip  : {snippet}")
            print(f"  Meta  : {sorted(md.keys())}")


if __name__ == "__main__":
    demo()
9999999