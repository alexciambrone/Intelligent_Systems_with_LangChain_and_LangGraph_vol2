from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Iterator, List, Optional, Sequence, Tuple

from langchain_core.documents import Document
from langchain_community.document_loaders import CSVLoader, PyPDFLoader, TextLoader

# -----------------------------
# Normalization utilities
# -----------------------------

_WS = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    # Collapse whitespace and trim.
    return _WS.sub(" ", text).strip()


def strip_repeated_lines(text: str, *, max_line_len: int = 120) -> str:
    """
    A simple (imperfect) helper for PDFs: remove lines that repeat a lot across pages,
    which often correspond to headers/footers.
    For a production system, you typically do this with corpus-level statistics.
    Here we keep it per-page and conservative.
    """
    lines = [ln.strip() for ln in text.splitlines()]
    # Drop empty and very long lines (often layout artifacts)
    lines = [ln for ln in lines if ln and len(ln) <= max_line_len]
    # If the first/last line looks like a page header/footer (short, repeated patterns), drop them.
    if len(lines) >= 3:
        # Heuristic: drop first and last if they are "small and banner-ish"
        if len(lines[0]) < 80:
            lines = lines[1:]
        if lines and len(lines[-1]) < 80:
            lines = lines[:-1]
    return "\n".join(lines)


# -----------------------------
# Pipeline helpers (sync)
# -----------------------------


def iter_documents(loader) -> Iterator[Document]:
    # Prefer streaming if supported; fall back to eager loading.
    if hasattr(loader, "lazy_load"):
        yield from loader.lazy_load()
    else:
        yield from loader.load()


def stamp_provenance(
    doc: Document, *, source_type: str, source: str, doc_id: Optional[str]
) -> Document:
    md = dict(doc.metadata or {})
    md.setdefault("source_type", source_type)
    md.setdefault("source", source)
    if doc_id:
        md.setdefault("doc_id", doc_id)
    md.setdefault("loaded_at", datetime.now(timezone.utc).isoformat())
    return Document(page_content=doc.page_content, metadata=md, id=doc.id)


def quality_gate(doc: Document) -> Optional[Document]:
    if not doc.page_content or not doc.page_content.strip():
        return None
    return doc


# -----------------------------
# Loader dispatch
# -----------------------------

LoaderFactory = Callable[[Path], object]


@dataclass(frozen=True)
class FileLoaderRegistry:
    """
    Extension-based dispatch. Keep this small and explicit.
    It is the safest default for “upload documents” and mixed folders.
    """

    factories: Dict[str, LoaderFactory]

    def get_loader(self, path: Path):
        ext = path.suffix.lower()
        if ext not in self.factories:
            raise ValueError(f"Unsupported file type: {ext} ({path.name})")
        return self.factories[ext](path)


def default_registry(
    *,
    text_encoding: str = "utf-8",
    text_autodetect: bool = True,
    csv_encoding: Optional[str] = "utf-8",
    csv_autodetect: bool = True,
    csv_content_columns: Sequence[str] = (),
    csv_metadata_columns: Sequence[str] = (),
    csv_source_column: Optional[str] = None,
    csv_args: Optional[dict] = None,
    pdf_mode: str = "page",  # "page" (default) or "single"
) -> FileLoaderRegistry:
    def mk_text(p: Path):
        return TextLoader(str(p), encoding=text_encoding, autodetect_encoding=text_autodetect)

    def mk_pdf(p: Path):
        # PyPDFLoader supports mode="single" to emit one Document for the whole PDF.
        # Default behavior is page-level Documents.
        if pdf_mode == "single":
            return PyPDFLoader(str(p), mode="single")
        return PyPDFLoader(str(p))

    def mk_csv(p: Path):
        return CSVLoader(
            file_path=str(p),
            encoding=csv_encoding,
            autodetect_encoding=csv_autodetect,
            content_columns=tuple(csv_content_columns),
            metadata_columns=tuple(csv_metadata_columns),
            source_column=csv_source_column,
            csv_args=csv_args,
        )

    return FileLoaderRegistry(
        factories={
            ".txt": mk_text,
            ".pdf": mk_pdf,
            ".csv": mk_csv,
        }
    )


# -----------------------------
# Public API: load one file / load many files
# -----------------------------


def load_file(
    path: str | Path,
    *,
    registry: FileLoaderRegistry,
    source_type: str = "file",
) -> List[Document]:
    p = Path(path)
    loader = registry.get_loader(p)

    docs: List[Document] = []
    for d in iter_documents(loader):
        # Format-specific cleanup hook
        text = d.page_content
        if p.suffix.lower() == ".pdf":
            text = strip_repeated_lines(text)
        text = normalize_text(text)

        stamped = stamp_provenance(
            Document(page_content=text, metadata=d.metadata, id=d.id),
            source_type=source_type,
            source=str(p),
            doc_id=None,  # optionally set a stable id here (hash, canonical id, etc.)
        )
        kept = quality_gate(stamped)
        if kept:
            docs.append(kept)

    return docs


def ingest_directory(
    root_dir: str | Path,
    *,
    registry: FileLoaderRegistry,
    include_exts: Tuple[str, ...] = (".txt", ".pdf", ".csv"),
) -> Iterator[Document]:
    root = Path(root_dir)
    files = sorted([p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in include_exts])
    for p in files:
        for d in load_file(p, registry=registry, source_type="file"):
            yield d


# -----------------------------
# Demo (support assistant corpus)
# -----------------------------


def main() -> None:
    registry = default_registry(
        csv_content_columns=("title", "body"),
        csv_metadata_columns=("ticket_id", "category", "priority"),
        csv_source_column="ticket_id",  # useful if each row maps to a stable record id
        csv_args={"delimiter": ",", "quotechar": '"'},
        pdf_mode="page",
    )

    # Example folder: policies.pdf, notes.txt, tickets.csv
    corpus_dir = "./data/support_corpus"

    for i, doc in enumerate(ingest_directory(corpus_dir, registry=registry), start=1):
        md = doc.metadata or {}
        print("=" * 100)
        print(f"[{i}] source={md.get('source')!r}  source_type={md.get('source_type')!r}  id={doc.id!r}")
        print("metadata:\n" + json.dumps(md, indent=2, sort_keys=True, ensure_ascii=False))
        print("text:\n" + (doc.page_content or "")[:400])


if __name__ == "__main__":
    main()
