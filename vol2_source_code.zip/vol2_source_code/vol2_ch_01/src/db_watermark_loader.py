from __future__ import annotations

import sqlite3
from typing import List, TypedDict

from langchain_core.documents import Document
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph


# ---------------------------------------
# State: watermark + current batch
# ---------------------------------------
class IngestState(TypedDict, total=False):
    last_updated_at: str
    last_id: int
    batch: List[Document]


# ---------------------------------------
# DB setup
# ---------------------------------------
def ensure_tables(sqlite_path: str) -> None:
    con = sqlite3.connect(sqlite_path)
    try:
        cur = con.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS tickets (
              id INTEGER PRIMARY KEY,
              subject TEXT NOT NULL,
              body TEXT NOT NULL,
              status TEXT NOT NULL,
              customer_email TEXT,
              updated_at TEXT NOT NULL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS indexed_tickets (
              ticket_id INTEGER PRIMARY KEY,
              doc_text TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )
        con.commit()
    finally:
        con.close()


# ---------------------------------------
# Node 1: read a small batch since watermark
# (robust: use sqlite3.Row)
# ---------------------------------------
def read_new_tickets(state: IngestState, *, sqlite_path: str, batch_size: int = 50) -> IngestState:
    last_ts = state.get("last_updated_at", "0000-01-01T00:00:00")
    last_id = int(state.get("last_id", 0))

    query = """
    SELECT id, subject, body, status, customer_email, updated_at
    FROM tickets
    WHERE (updated_at > ?)
       OR (updated_at = ? AND id > ?)
    ORDER BY updated_at ASC, id ASC
    LIMIT ?
    """

    con = sqlite3.connect(sqlite_path)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute(query, (last_ts, last_ts, last_id, batch_size)).fetchall()
    finally:
        con.close()

    print(f"[read] watermark=({last_ts}, {last_id}) -> fetched {len(rows)} row(s)")

    batch: list[Document] = []
    for r in rows:
        ticket_id = int(r["id"])
        subject = r["subject"] or ""
        body = r["body"] or ""
        status = r["status"] or ""
        email = r["customer_email"]
        updated_at = r["updated_at"]

        text = f"Subject: {subject}\nStatus: {status}\n\n{body}".strip()
        if not text:
            continue

        batch.append(
            Document(
                page_content=text,
                metadata={
                    "ticket_id": ticket_id,
                    "updated_at": updated_at,
                    "status": status,
                    "customer_email": email,
                    "source": f"sqlite:///{sqlite_path}#tickets",
                    "source_type": "db",
                },
            )
        )

    return {**state, "batch": batch}


# ---------------------------------------
# Node 2: idempotent write + watermark commit
# ---------------------------------------
def upsert_and_commit(state: IngestState, *, sqlite_path: str) -> IngestState:
    batch = state.get("batch", [])
    if not batch:
        return state

    con = sqlite3.connect(sqlite_path)
    try:
        cur = con.cursor()
        for d in batch:
            ticket_id = int(d.metadata["ticket_id"])
            updated_at = str(d.metadata["updated_at"])
            doc_text = d.page_content

            cur.execute(
                """
                INSERT INTO indexed_tickets(ticket_id, doc_text, updated_at)
                VALUES(?, ?, ?)
                ON CONFLICT(ticket_id) DO UPDATE SET
                  doc_text = excluded.doc_text,
                  updated_at = excluded.updated_at
                """,
                (ticket_id, doc_text, updated_at),
            )
        con.commit()
    finally:
        con.close()

    last = batch[-1]  # newest in this batch (ASC order)
    new_ts = str(last.metadata["updated_at"])
    new_id = int(last.metadata["ticket_id"])

    print(f"[write] upserted {len(batch)} doc(s) -> new watermark=({new_ts}, {new_id})")

    return {
        **state,
        "last_updated_at": new_ts,
        "last_id": new_id,
        "batch": [],
    }


def route(state: IngestState) -> str:
    has_batch = bool(state.get("batch"))
    if not has_batch:
        print("[route] batch empty -> STOP")
        return "stop"
    print("[route] batch non-empty -> CONTINUE")
    return "continue"


def build_graph(sqlite_path: str):
    g = StateGraph(IngestState)
    g.add_node("read", lambda s: read_new_tickets(s, sqlite_path=sqlite_path, batch_size=2))
    g.add_node("write", lambda s: upsert_and_commit(s, sqlite_path=sqlite_path))

    g.add_edge(START, "read")
    g.add_conditional_edges("read", route, {"continue": "write", "stop": END})
    g.add_edge("write", "read")
    return g


def show_checkpoint_state(graph, config) -> None:
    # LangGraph exposes get_state(); if not available in your version, just skip gracefully.
    try:
        snap = graph.get_state(config)
    except Exception:
        print("[checkpoint] (get_state not available in this version)")
        return

    values = getattr(snap, "values", None) or {}
    ts = values.get("last_updated_at")
    _id = values.get("last_id")
    if ts is None and _id is None:
        print("[checkpoint] no saved watermark (fresh run)")
    else:
        print(f"[checkpoint] resume watermark=({ts}, {_id})")


def main() -> None:
    sqlite_path = "./data/support.sqlite"
    ensure_tables(sqlite_path)

    with SqliteSaver.from_conn_string("./data/ingest_checkpoints.sqlite") as checkpointer:
        compiled = build_graph(sqlite_path).compile(checkpointer=checkpointer)
        config = {"configurable": {"thread_id": "support-ticket-ingest"}}

        # Show whether we’re resuming or starting fresh
        show_checkpoint_state(compiled, config)

        # Invoke with empty input; state comes from checkpoint (if present)
        result = compiled.invoke({}, config=config)

    print("\nFinal watermark:", result.get("last_updated_at"), result.get("last_id"))

    # Show sink preview
    con = sqlite3.connect(sqlite_path)
    try:
        cur = con.cursor()
        cur.execute(
            "SELECT ticket_id, updated_at, substr(doc_text, 1, 120) "
            "FROM indexed_tickets ORDER BY updated_at DESC LIMIT 5"
        )
        rows = cur.fetchall()
    finally:
        con.close()

    if rows:
        print("\nLatest indexed rows:")
        for r in rows:
            print(f"  ticket_id={r[0]} | updated_at={r[1]} | text='{r[2]}...'")
    else:
        print("\nSink table is empty (no tickets ingested yet).")


if __name__ == "__main__":
    main()
