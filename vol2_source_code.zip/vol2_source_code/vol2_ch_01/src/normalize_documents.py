from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Optional

from langchain_core.documents import Document


@dataclass(frozen=True)
class Provenance:
    source_type: str
    source: str
    doc_id: str
    loaded_at_iso: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize_documents(
    docs: Iterable[Document],
    *,
    source_type: str,
    source: str,
    doc_id: Optional[str] = None,
    loaded_at_iso: Optional[str] = None,
) -> list[Document]:
    """
    Apply a minimal provenance envelope to loader-produced Documents.

    The function:
    - preserves existing metadata;
    - adds consistent provenance keys;
    - removes empty Documents;
    - returns new Document objects instead of mutating the originals.
    """
    out: list[Document] = []
    ingested_at = loaded_at_iso or _now_iso()

    for d in docs:
        content = (d.page_content or "").strip()

        if not content:
            continue

        metadata = dict(d.metadata or {})

        derived_id = (
            doc_id
            or metadata.get("doc_id")
            or metadata.get("id")
            or source
        )

        provenance = Provenance(
            source_type=source_type,
            source=source,
            doc_id=str(derived_id),
            loaded_at_iso=ingested_at,
        )

        metadata.update(
            {
                "source_type": provenance.source_type,
                "source": provenance.source,
                "doc_id": provenance.doc_id,
                "loaded_at": provenance.loaded_at_iso,
            }
        )

        out.append(Document(page_content=content, metadata=metadata))

    return out


def main() -> None:
    raw_docs = [
        Document(
            page_content="Refund policy: refunds are approved within 48 hours.",
            metadata={
                "id": "kb-001",
                "title": "Refund policy",
                "locale": "en",
            },
        ),
        Document(
            page_content="  Shipping policy: delivery normally takes 2–5 business days.  ",
            metadata={
                "doc_id": "kb-002",
                "title": "Shipping policy",
                "locale": "en",
            },
        ),
        Document(
            page_content="   ",
            metadata={
                "id": "kb-empty",
                "title": "Broken extraction",
            },
        ),
        Document(
            page_content="Return window: customers have 30 days from delivery.",
            metadata={
                "title": "Return window",
                "locale": "en",
            },
        ),
    ]

    normalized_docs = normalize_documents(
        raw_docs,
        source_type="file",
        source="support_kb.md",
        loaded_at_iso="2026-05-19T10:00:00+00:00",
    )

    print(f"Loaded documents: {len(raw_docs)}")
    print(f"Normalized documents: {len(normalized_docs)}")
    print(f"Dropped documents: {len(raw_docs) - len(normalized_docs)}")

    print("\nNormalized output:")
    for i, doc in enumerate(normalized_docs, start=1):
        print(f"\nDocument {i}")
        print(
            json.dumps(
                {
                    "page_content": doc.page_content,
                    "metadata": {
                        "doc_id": doc.metadata["doc_id"],
                        "source_type": doc.metadata["source_type"],
                        "source": doc.metadata["source"],
                        "loaded_at": doc.metadata["loaded_at"],
                        "title": doc.metadata.get("title"),
                        "locale": doc.metadata.get("locale"),
                    },
                },
                indent=2,
            )
        )


if __name__ == "__main__":
    main()