from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from langchain_chroma import Chroma  # pip install -U langchain-chroma
from .config import OPENAI_API_KEY


# ============================================================
# Option A: encode list metadata as JSON strings
# ============================================================
LIST_KEYS = ("allowed_roles", "departments", "allowed_users")


def encode_acl_metadata(md: dict) -> dict:
    """Convert list-valued ACL metadata into JSON strings so Chroma accepts it."""
    md = dict(md)
    for k in LIST_KEYS:
        v = md.get(k)
        if isinstance(v, list):
            md[k] = json.dumps(v, ensure_ascii=False)
    return md


def decode_json_list(value: object) -> list[str]:
    """Decode a JSON-encoded list; fall back to CSV-ish parsing if needed."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value]
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return []
        try:
            obj = json.loads(s)
            if isinstance(obj, list):
                return [str(x) for x in obj]
        except Exception:
            # fallback: "a,b,c"
            return [x.strip() for x in s.split(",") if x.strip()]
    return []


# ============================================================
# ACL model + enforcement
# ============================================================
@dataclass(frozen=True)
class Principal:
    tenant_id: str
    user_id: str
    roles: List[str]
    departments: List[str]
    max_sensitivity: str  # e.g. "public" < "internal" < "confidential"


_SENS_ORDER = {"public": 0, "internal": 1, "confidential": 2}


def sensitivity_ok(doc_sensitivity: str, principal_max: str) -> bool:
    return _SENS_ORDER.get(doc_sensitivity, 0) <= _SENS_ORDER.get(principal_max, 0)


def acl_allows(doc: Document, principal: Principal) -> bool:
    """Post-filter safety net: enforce tenant + roles/users/departments + sensitivity."""
    md = doc.metadata or {}

    # tenant is mandatory
    if md.get("tenant_id") != principal.tenant_id:
        return False

    # sensitivity (scalar, safe for DB filter too)
    doc_sens = md.get("sensitivity", "public")
    if not sensitivity_ok(doc_sens, principal.max_sensitivity):
        return False

    allowed_roles = set(decode_json_list(md.get("allowed_roles")))
    allowed_users = set(decode_json_list(md.get("allowed_users")))
    allowed_depts = set(decode_json_list(md.get("departments")))

    # if present, enforce membership
    if allowed_users and principal.user_id not in allowed_users:
        return False

    if allowed_roles and not (allowed_roles & set(principal.roles)):
        return False

    if allowed_depts and not (allowed_depts & set(principal.departments)):
        return False

    return True


# ============================================================
# Demo docs
# ============================================================
def build_docs() -> List[Document]:
    raw = [
        # Tenant A: general returns
        Document(
            page_content="Return window: 30 days from delivery date.",
            metadata={
                "tenant_id": "tenant_a",
                "source": "policies.md",
                "sensitivity": "public",
                "allowed_roles": ["customer", "support_agent"],
                "departments": ["returns"],
            },
        ),
        # Tenant A: internal playbook (only support agents)
        Document(
            page_content="Damage-on-arrival: collect photos of outer box, label, and damaged item.",
            metadata={
                "tenant_id": "tenant_a",
                "source": "support_playbook.md",
                "sensitivity": "internal",
                "allowed_roles": ["support_agent"],
                "departments": ["returns", "support"],
            },
        ),
        # Tenant A: billing-only internal note
        Document(
            page_content="Refunds: allow 5–10 business days for processing once approved.",
            metadata={
                "tenant_id": "tenant_a",
                "source": "faq.md",
                "sensitivity": "internal",
                "allowed_roles": ["billing_agent", "support_agent"],
                "departments": ["billing"],
            },
        ),
        # Tenant B: same topic, different tenant
        Document(
            page_content="Return window: 14 days from delivery date.",
            metadata={
                "tenant_id": "tenant_b",
                "source": "policies.md",
                "sensitivity": "public",
                "allowed_roles": ["customer", "support_agent"],
                "departments": ["returns"],
            },
        ),
        # Tenant A: per-user exception
        Document(
            page_content="VIP exception: allow out-of-window refund if escalation approves.",
            metadata={
                "tenant_id": "tenant_a",
                "source": "vip_notes.md",
                "sensitivity": "confidential",
                "allowed_users": ["user:42"],  # only this user
            },
        ),
    ]

    # IMPORTANT: encode list metadata as JSON strings for Chroma
    encoded: List[Document] = []
    for d in raw:
        encoded.append(
            Document(
                page_content=d.page_content,
                metadata=encode_acl_metadata(d.metadata or {}),
            )
        )
    return encoded


# ============================================================
# Store + retrieval
# ============================================================
def build_store(persist_dir: str = "./.cache/chroma_acl_demo") -> Chroma:
    Path(persist_dir).mkdir(parents=True, exist_ok=True)

    # Requires OPENAI_API_KEY in env or pass api_key=...
    embeddings = OpenAIEmbeddings()

    store = Chroma(
        collection_name="support_kb",
        embedding_function=embeddings,
        persist_directory=persist_dir,
    )
    store.add_documents(build_docs())
    return store


def similarity_search_tenant_first(
    store: Chroma,
    query: str,
    *,
    tenant_id: str,
    k: int,
) -> List[Document]:
    """Fast path: pre-filter by tenant (and optionally other scalar fields)."""
    return store.similarity_search(query, k=k, filter={"tenant_id": tenant_id})

def retrieve_acl_enforced(
    store: Chroma,
    query: str,
    principal: Principal,
    *,
    k: int = 8,
) -> List[Document]:
    """
    Two-step enforcement:
      1) Pre-filter in vector search (tenant only, because lists are JSON strings)
      2) Post-filter as safety net (roles/users/departments + sensitivity)
    """
    candidates = similarity_search_tenant_first(store, query, tenant_id=principal.tenant_id, k=k)
    allowed = [d for d in candidates if acl_allows(d, principal)]
    return allowed


def print_results(title: str, docs: List[Document]) -> None:
    print(f"\n=== {title} ===")
    print(f"Docs returned: {len(docs)}")
    for i, d in enumerate(docs, start=1):
        md = d.metadata or {}
        print(f"\n[{i}] source={md.get('source')} tenant={md.get('tenant_id')} sens={md.get('sensitivity')}")
        print(f"allowed_roles={decode_json_list(md.get('allowed_roles'))}")
        print(f"departments={decode_json_list(md.get('departments'))}")
        print(f"allowed_users={decode_json_list(md.get('allowed_users'))}")
        print(d.page_content.strip())


if __name__ == "__main__":
    # Make sure OPENAI_API_KEY is set:
    #   set OPENAI_API_KEY=...   (cmd)
    #   $env:OPENAI_API_KEY="..." (powershell)

    store = build_store()

    query = "How long do refunds take once approved?"

    customer = Principal(
        tenant_id="tenant_a",
        user_id="user:100",
        roles=["customer"],
        departments=["returns"],
        max_sensitivity="public",
    )

    support_agent = Principal(
        tenant_id="tenant_a",
        user_id="user:200",
        roles=["support_agent"],
        departments=["support", "returns"],
        max_sensitivity="internal",
    )

    billing_agent = Principal(
        tenant_id="tenant_a",
        user_id="user:300",
        roles=["billing_agent"],
        departments=["billing"],
        max_sensitivity="internal",
    )

    vip_user = Principal(
        tenant_id="tenant_a",
        user_id="user:42",
        roles=["customer"],
        departments=["returns"],
        max_sensitivity="confidential",
    )

    # Show what each principal can see for the same query
    print_results("Customer (tenant_a, public only)", retrieve_acl_enforced(store, query, customer))
    print_results("Support agent (tenant_a, internal)", retrieve_acl_enforced(store, query, support_agent))
    print_results("Billing agent (tenant_a, internal + billing dept)", retrieve_acl_enforced(store, query, billing_agent))
    print_results("VIP user (tenant_a, confidential allowed_users)", retrieve_acl_enforced(store, query, vip_user))
