from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from typing import List
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from .config import OPENAI_API_KEY

@dataclass(frozen=True)
class PolicyDoc:
    """A small helper to keep policy metadata explicit and consistent."""
    doc_id: str
    family: str               # e.g., "refunds", "returns", "gifts"
    title: str
    locator: str              # e.g., URL, filename, or internal KB key
    effective_date: date
    text: str


def _seed_policy_docs() -> List[PolicyDoc]:
    # Intentionally include an older refunds policy to demonstrate "prefer the current version".
    return [
        PolicyDoc(
            doc_id="refunds_v1",
            family="refunds",
            title="Refunds policy (archived)",
            locator="kb://policies/refunds_v1",
            effective_date=date(2024, 6, 1),
            text=(
                "Refunds: You can request a refund within 14 days of delivery. "
                "Refunds are issued to the original payment method within 7 business days "
                "after the returned item is received and inspected."
            ),
        ),
        PolicyDoc(
            doc_id="refunds_v2",
            family="refunds",
            title="Refunds policy",
            locator="kb://policies/refunds_v2",
            effective_date=date(2026, 1, 1),
            text=(
                "Refunds: You can request a refund within 30 days of delivery. "
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
        ),
        PolicyDoc(
            doc_id="returns_v1",
            family="returns",
            title="Returns policy",
            locator="kb://policies/returns_v1",
            effective_date=date(2026, 1, 1),
            text=(
                "Returns: Items must be returned in original condition. "
                "Return shipping is free for defective items. "
                "For non-defective returns, return shipping is paid by the customer."
            ),
        ),
        PolicyDoc(
            doc_id="gifts_v1",
            family="gifts",
            title="Gift purchases policy",
            locator="kb://policies/gifts_v1",
            effective_date=date(2026, 1, 1),
            text=(
                "Gift purchases: If an item was purchased as a gift, refunds are issued as store credit "
                "unless the original purchaser requests a refund to the original payment method."
            ),
        ),
    ]


def build_policy_retriever(k: int = 3):
    """
    Build a retriever over a small policy set.

    Uses OpenAIEmbeddings + an in-memory vector store to keep the example compact.
    """
    embeddings = OpenAIEmbeddings()

    docs: List[Document] = []
    for p in _seed_policy_docs():
        docs.append(
            Document(
                id=p.doc_id,
                page_content=p.text,
                metadata={
                    "family": p.family,
                    "title": p.title,
                    "locator": p.locator,
                    "effective_date": p.effective_date.isoformat(),
                },
            )
        )

    store = InMemoryVectorStore.from_documents(docs, embedding=embeddings)
    return store.as_retriever(search_kwargs={"k": k})
