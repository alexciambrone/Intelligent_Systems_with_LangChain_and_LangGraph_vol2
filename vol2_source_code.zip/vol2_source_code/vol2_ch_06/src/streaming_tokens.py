from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage
from .support_backend import build_support_graph

def to_lc_messages(chat: list[dict[str, str]]):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out

def main():
    graph = build_support_graph()

    policy_text = (
        "Refunds: You can request a refund within 30 days of delivery. "
        "Refunds are issued to the original payment method within 5 business days "
        "after the returned item is received and inspected."
    )

    chat: list[dict[str, str]] = [
        {"role": "assistant", "content": "Support assistant ready. Type /exit to quit."}
    ]
    print(chat[0]["content"])

    while True:
        user = input("user> ").strip()
        if user == "/exit":
            break
        if not user:
            continue

        chat.append({"role": "user", "content": user})
        state_in = {"messages": to_lc_messages(chat), "kb_text": policy_text}

        print("assistant> ", end="", flush=True)

        answer_parts: list[str] = []
        final_state = None

        for mode, chunk in graph.stream(state_in, stream_mode=["messages", "values"]):
            if mode == "messages":
                msg_chunk, _meta = chunk  # (token_chunk, metadata)
                if msg_chunk.content:
                    answer_parts.append(msg_chunk.content)
                    print(msg_chunk.content, end="", flush=True)
            elif mode == "values":
                final_state = chunk

        print("\n")

        if final_state and final_state.get("messages"):
            assistant_text = final_state["messages"][-1].content
        else:
            assistant_text = "".join(answer_parts)

        chat.append({"role": "assistant", "content": assistant_text})

if __name__ == "__main__":
    main()
