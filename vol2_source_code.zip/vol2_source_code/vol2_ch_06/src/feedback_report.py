from __future__ import annotations
from src.feedback_store_pg import FeedbackStore

def print_helpful_rate(store: FeedbackStore) -> None:
    up, down = store.helpful_rate()
    total = up + down
    rate = (up / total) if total else 0.0

    print(f"Helpful rate: {up}/{total} = {rate:.2%}")
    print("Note: this counts feedback events, not deduplicated turns.")

def top_downvote_reasons(store: FeedbackStore, limit: int = 10) -> list[tuple[str, int]]:
    with store._connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT reason, COUNT(*)::int AS n
                FROM feedback_events f
                CROSS JOIN LATERAL unnest(COALESCE(f.reasons, ARRAY[]::text[])) AS reason
                WHERE f.rating < 0
                GROUP BY reason
                ORDER BY n DESC, reason ASC
                LIMIT %s
                """,
                (limit,),
            )
            return [(row[0], int(row[1])) for row in cur.fetchall()]

def recent_downvote_review_queue(
    store: FeedbackStore,
    limit: int = 10,
) -> list[tuple[str, str, str, str, list[str], str, str, str]]:
    """
    Return the latest negative feedback event for each turn, ordered by
    feedback timestamp descending.

    Columns:
      turn_id, thread_id, user_text, assistant_text, reasons, comment,
      correction, feedback_at
    """
    with store._connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    q.turn_id,
                    q.thread_id,
                    q.user_text,
                    q.assistant_text,
                    q.reasons,
                    q.comment,
                    q.correction,
                    q.feedback_at::text
                FROM (
                    SELECT DISTINCT ON (t.turn_id)
                        t.turn_id,
                        t.thread_id,
                        t.user_text,
                        t.assistant_text,
                        COALESCE(f.reasons, ARRAY[]::text[]) AS reasons,
                        COALESCE(f.comment, '') AS comment,
                        COALESCE(f.correction, '') AS correction,
                        f.created_at AS feedback_at
                    FROM feedback_events f
                    JOIN turns t ON t.turn_id = f.turn_id
                    WHERE f.rating < 0
                    ORDER BY t.turn_id, f.created_at DESC
                ) AS q
                ORDER BY q.feedback_at DESC
                LIMIT %s
                """,
                (limit,),
            )
            return list(cur.fetchall())

def main() -> None:
    # Reads DATABASE_URL from the environment unless you pass a DSN explicitly.
    store = FeedbackStore(dsn="postgresql://postgres:root@localhost:5432/feedback")
    
    print_helpful_rate(store)

    print("\nTop downvote reason tags:")
    reason_rows = top_downvote_reasons(store, limit=10)
    if not reason_rows:
        print("  (none)")
    else:
        for reason, count in reason_rows:
            print(f"  - {reason}: {count}")

    print("\nRecent downvoted turns (review queue):")
    queue = recent_downvote_review_queue(store, limit=10)
    if not queue:
        print("  (none)")
        return

    for (
        turn_id,
        thread_id,
        user_text,
        assistant_text,
        reasons,
        comment,
        correction,
        feedback_at,
    ) in queue:
        print(f"\n- turn_id={turn_id}")
        print(f"  thread_id: {thread_id}")
        print(f"  feedback_at: {feedback_at}")
        print(f"  reasons: {', '.join(reasons) if reasons else '(none)'}")
        print(f"  user: {user_text}")
        print(f"  assistant: {assistant_text}")
        if comment:
            print(f"  comment: {comment}")
        if correction:
            print(f"  correction: {correction}")

if __name__ == "__main__":
    main()
