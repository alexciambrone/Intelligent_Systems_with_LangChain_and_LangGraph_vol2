from __future__ import annotations
import os
from typing import Annotated, List, TypedDict
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, BaseMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
#from .config import OPENAI_API_KEY  

class SupportState(TypedDict):
    # The UI owns persistence of this history. The backend just consumes it.
    messages: Annotated[List[BaseMessage], add_messages]

    # Optional per-session context the UI might manage (e.g., uploaded policy text).
    kb_text: str


def build_support_graph():
    model_name = os.getenv("CHAT_MODEL", "gpt-4o-mini")
    model = init_chat_model(model_name, model_provider="openai")

    def answer(state: SupportState):
        kb = (state.get("kb_text") or "").strip()
        system = (
            "You are a customer support assistant. Answer using the policy text provided. "
            "If the policy text does not contain the answer, say you don't know."
        )
        if kb:
            system = f"{system}\n\nPOLICY:\n{kb}"

        # We prepend the system message each turn; the UI provides the chat history.
        messages = [SystemMessage(content=system)] + state["messages"]
        ai = model.invoke(messages)
        return {"messages": [AIMessage(content=ai.content)]}

    g = StateGraph(SupportState)
    g.add_node("answer", answer)
    g.add_edge(START, "answer")
    g.add_edge("answer", END)
    return g.compile()


