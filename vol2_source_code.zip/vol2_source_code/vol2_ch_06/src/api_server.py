# api_server.py
from __future__ import annotations

from typing import Dict, List

from fastapi import FastAPI
from pydantic import BaseModel
from langchain_core.messages import AIMessage, HumanMessage

from .support_backend import build_support_graph
from .config import OPENAI_API_KEY

app = FastAPI(title="Support Policy Assistant API")
graph = build_support_graph()

# Demo-only: per-session transcript in memory.
_SESSIONS: Dict[str, List[Dict[str, str]]] = {}


class ChatRequest(BaseModel):
    session_id: str
    message: str
    kb_text: str | None = None  # Python 3.10+


class ChatResponse(BaseModel):
    session_id: str
    answer: str


def to_lc_messages(chat: List[Dict[str, str]]):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    transcript = _SESSIONS.setdefault(req.session_id, [])
    transcript.append({"role": "user", "content": req.message})

    state_in = {
        "messages": to_lc_messages(transcript),
        "kb_text": req.kb_text or "",
    }
    state_out = graph.invoke(state_in)
    answer = state_out["messages"][-1].content

    transcript.append({"role": "assistant", "content": answer})
    return ChatResponse(session_id=req.session_id, answer=answer)

