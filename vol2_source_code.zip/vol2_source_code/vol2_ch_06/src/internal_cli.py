# internal_cli.py
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from langchain_core.messages import AIMessage, HumanMessage

from .support_backend import build_support_graph


def to_lc_messages(chat):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out


def append_audit(log_path: Path, event: dict):
    record = dict(event)
    record["ts"] = datetime.now(timezone.utc).isoformat()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def main():
    graph = build_support_graph()
    audit_path = Path("runs") / "internal_cli_audit.jsonl"

    policy_text = "Refunds: You can request a refund within 30 days of delivery. Refunds are issued to the original payment method within 5 business days after the returned item is received and inspected."
    chat = [{"role": "assistant", "content": "Internal support tool ready. Type /exit to quit."}]
    print(chat[0]["content"])

    while True:
        user = input("user> ").strip()
        if user == "/exit":
            break
        if not user:
            continue

        chat.append({"role": "user", "content": user})
        out = graph.invoke({"messages": to_lc_messages(chat), "kb_text": policy_text})
        answer = out["messages"][-1].content
        chat.append({"role": "assistant", "content": answer})

        print(f"assistant> {answer}\n")
        append_audit(audit_path, {"type": "turn", "user": user, "answer": answer})


if __name__ == "__main__":
    main()


