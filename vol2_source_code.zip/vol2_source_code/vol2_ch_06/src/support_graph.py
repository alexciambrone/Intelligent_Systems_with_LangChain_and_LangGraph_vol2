from __future__ import annotations
import os
from typing import Annotated
from typing_extensions import TypedDict
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

SYSTEM_POLICY = (
    "You are a customer support assistant for an e-commerce store.\n"
    "Use the policy below as the source of truth.\n\n"
    "Policy:\n"
    "- Refunds can be requested within 30 days of delivery.\n"
    "- Refunds are issued to the original payment method within 5 business days\n"
    "  after the returned item is received and inspected.\n"
    "- If the user asks about an order, ask for the order number.\n"
)


class SupportState(TypedDict):
    # add_messages appends new messages rather than overwriting the list
    messages: Annotated[list, add_messages]


def build_support_graph():
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    llm = ChatOpenAI(model=model, temperature=0)

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_POLICY),
            MessagesPlaceholder("messages"),
        ]
    )

    chain = prompt | llm

    def answer_node(state: SupportState) -> dict:
        ai_msg = chain.invoke({"messages": state["messages"]})
        return {"messages": [ai_msg]}

    builder = StateGraph(SupportState)
    builder.add_node("answer", answer_node)
    builder.add_edge(START, "answer")
    builder.add_edge("answer", END)

    return builder.compile()