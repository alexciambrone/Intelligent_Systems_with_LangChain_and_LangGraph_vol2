# src/api_sse_server.py
from __future__ import annotations

import json
from typing import Dict, List

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse

from langchain_core.messages import AIMessage, HumanMessage
from .support_backend import build_support_graph

app = FastAPI(title="Support Assistant (SSE streaming)")
graph = build_support_graph()

# Demo-only in-memory transcript store. In production, persist by session_id.
_SESSIONS: Dict[str, List[Dict[str, str]]] = {}

# Demo-only policy text. In production, load from your KB and apply tenant/ACL boundaries.
POLICY_TEXT = (
    "Refunds: You can request a refund within 30 days of delivery. "
    "Refunds are issued to the original payment method within 5 business days "
    "after the returned item is received and inspected."
)


def to_lc_messages(chat: List[Dict[str, str]]):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out


@app.get("/chat/stream")
async def chat_stream(session_id: str, message: str):
    transcript = _SESSIONS.setdefault(session_id, [])
    transcript.append({"role": "user", "content": message})

    state_in = {"messages": to_lc_messages(transcript), "kb_text": POLICY_TEXT}

    async def sse():
        answer_parts: list[str] = []
        final_state = None

        # Tracks what we have already emitted to the client.
        # Some streaming backends send partial deltas AND then a final full message.
        emitted_text = ""

        async for mode, chunk in graph.astream(state_in, stream_mode=["messages", "values"]):
            if mode == "messages":
                msg_chunk, _meta = chunk
                text = msg_chunk.content or ""
                if not text:
                    continue

                # If the chunk is a full accumulated string, emit only the suffix we haven't sent yet.
                if text.startswith(emitted_text):
                    delta = text[len(emitted_text) :]
                else:
                    # Otherwise treat it as a delta chunk.
                    delta = text

                if delta:
                    emitted_text += delta
                    answer_parts.append(delta)
                    payload = json.dumps({"type": "token", "text": delta})
                    yield f"data: {payload}\n\n"

            elif mode == "values":
                final_state = chunk

        # Update transcript with the final assembled message.
        if final_state and final_state.get("messages"):
            assistant_text = final_state["messages"][-1].content
        else:
            assistant_text = "".join(answer_parts)

        transcript.append({"role": "assistant", "content": assistant_text})
        yield 'data: {"type":"done"}\n\n'

    return StreamingResponse(
        sse(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@app.get("/ui", response_class=HTMLResponse)
def ui():
    return HTMLResponse(
        """
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Support Assistant (SSE)</title>
    <style>
      body { font-family: sans-serif; max-width: 820px; margin: 2rem auto; }
      #log { border: 1px solid #ddd; padding: 1rem; min-height: 240px; white-space: pre-wrap; }
      .row { display: flex; gap: 0.5rem; margin-top: 1rem; }
      input { flex: 1; padding: 0.5rem; }
      button { padding: 0.5rem 1rem; }
    </style>
  </head>
  <body>
    <h1>Support Policy Assistant</h1>
    <div id="log"></div>

    <div class="row">
      <input id="msg" placeholder="Ask about refunds…" />
      <button id="send">Send</button>
    </div>

    <script>
      const log = document.getElementById("log");
      const msg = document.getElementById("msg");
      const send = document.getElementById("send");

      const sessionId = crypto.randomUUID();

      function append(text) {
        log.textContent += text;
        log.scrollTop = log.scrollHeight;
      }

      function startStream(userText) {
        append(`user> ${userText}\\nassistant> `);

        const url =
          `/chat/stream?session_id=${encodeURIComponent(sessionId)}&message=${encodeURIComponent(userText)}`;

        const es = new EventSource(url);

        es.onmessage = (event) => {
          const data = JSON.parse(event.data);

          if (data.type === "token") {
            append(data.text);
            return;
          }

          if (data.type === "done") {
            append("\\n\\n");
            es.close();
          }
        };

        es.onerror = () => {
          append("\\n[stream error]\\n\\n");
          es.close();
        };
      }

      send.onclick = () => {
        const userText = msg.value.trim();
        if (!userText) return;
        msg.value = "";
        startStream(userText);
      };

      msg.addEventListener("keydown", (e) => {
        if (e.key === "Enter") send.click();
      });
    </script>
  </body>
</html>
        """.strip()
    )