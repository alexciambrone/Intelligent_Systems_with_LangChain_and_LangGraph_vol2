from __future__ import annotations
import uuid
import requests
import streamlit as st

API_BASE = "http://127.0.0.1:8000"

REASON_TAGS = [
    "Factually incorrect",
    "Didn’t follow instructions",
    "Missing important details",
    "Too verbose / hard to scan",
    "Off-topic",
    "Other",
]

st.set_page_config(page_title="Support Assistant (Feedback Demo)")

if "thread_id" not in st.session_state:
    st.session_state.thread_id = f"thread-{uuid.uuid4()}"
if "chat" not in st.session_state:
    st.session_state.chat = [
        {"role": "assistant", "content": "Hi! Ask about refunds or returns.", "turn_id": None}
    ]
if "feedback_sent" not in st.session_state:
    st.session_state.feedback_sent = set()

st.title("Support Assistant")

# Render transcript + per-message feedback controls.
for msg in st.session_state.chat:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

    if msg["role"] == "assistant" and msg.get("turn_id"):
        turn_id = msg["turn_id"]
        block_key = f"fb_{turn_id}"

        if turn_id in st.session_state.feedback_sent:
            st.caption("Feedback received. Thanks.")
            continue

        rating = st.radio(
            "Was this helpful?",
            options=["—", "Yes", "No"],
            horizontal=True,
            key=f"{block_key}_rating",
        )

        reasons = []
        comment = ""
        correction = ""

        if rating == "No":
            reasons = st.multiselect(
                "What was wrong?",
                options=REASON_TAGS,
                key=f"{block_key}_reasons",
            )
            comment = st.text_area(
                "Optional: add context (one sentence is enough)",
                key=f"{block_key}_comment",
            )
            correction = st.text_area(
                "Optional: suggest an edit (replace the answer with your corrected version)",
                key=f"{block_key}_correction",
            )

        if st.button("Submit feedback", key=f"{block_key}_submit") and rating != "—":
            payload = {
                "turn_id": turn_id,
                "rating": 1 if rating == "Yes" else -1,
                "reasons": reasons if reasons else None,
                "comment": comment.strip() or None,
                "correction": correction.strip() or None,
            }
            resp = requests.post(f"{API_BASE}/feedback", json=payload, timeout=10)
            resp.raise_for_status()
            st.session_state.feedback_sent.add(turn_id)
            st.rerun()

# Input box
user_text = st.chat_input("Ask a question...")
if user_text:
    st.session_state.chat.append({"role": "user", "content": user_text, "turn_id": None})

    req = {
        "thread_id": st.session_state.thread_id,
        "messages": [{"role": m["role"], "content": m["content"]} for m in st.session_state.chat],
    }

    resp = requests.post(f"{API_BASE}/chat", json=req, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    st.session_state.chat.append(
        {"role": "assistant", "content": data["assistant"], "turn_id": data["turn_id"]}
    )
    st.rerun()
