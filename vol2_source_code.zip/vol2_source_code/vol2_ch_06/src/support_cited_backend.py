from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Annotated, Dict, List, TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.documents import Document
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

from .support_policy_kb import build_policy_retriever
from .config import OPENAI_API_KEY

@dataclass
class EvidenceItem:
    n: int
    doc_id: str
    title: str
    locator: str
    effective_date: str
    snippet: str
    full_text: str


class SupportCitedState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]

    # Internal working fields
    question: str
    raw_docs: List[Document]
    evidence: List[EvidenceItem]

    # Outputs that the UI can render
    answer_text: str
    citations: List[Dict[str, str]]          # n -> (title, locator, effective_date, doc_id)
    citation_spans: List[Dict[str, int]]     # optional: where [n] appears in answer


_CITATION_RE = re.compile(r"\[(\d+)\]")


def _pick_most_recent_per_family(docs: List[Document]) -> List[Document]:
    """
    When retrieval returns multiple versions of the same policy family,
    keep the most recent effective_date.

    This is a minimal example of metadata-driven source validation.
    """
    best_by_family: Dict[str, Document] = {}

    def parse_eff(d: Document) -> date:
        s = str(d.metadata.get("effective_date") or "1900-01-01")
        return date.fromisoformat(s)

    for d in docs:
        family = str(d.metadata.get("family") or "unknown")
        cur = best_by_family.get(family)
        if cur is None or parse_eff(d) > parse_eff(cur):
            best_by_family[family] = d

    return list(best_by_family.values())


def _to_evidence_items(docs: List[Document], snippet_chars: int = 220) -> List[EvidenceItem]:
    items: List[EvidenceItem] = []
    for i, d in enumerate(docs, start=1):
        title = str(d.metadata.get("title") or "Untitled")
        locator = str(d.metadata.get("locator") or "unknown")
        effective_date = str(d.metadata.get("effective_date") or "unknown")
        doc_id = str(d.id or d.metadata.get("doc_id") or f"doc_{i}")

        text = d.page_content or ""
        snippet = (text[:snippet_chars] + "…") if len(text) > snippet_chars else text

        items.append(
            EvidenceItem(
                n=i,
                doc_id=doc_id,
                title=title,
                locator=locator,
                effective_date=effective_date,
                snippet=snippet,
                full_text=text,
            )
        )
    return items


def _build_evidence_block(evidence: List[EvidenceItem]) -> str:
    lines: List[str] = []
    for e in evidence:
        lines.append(
            f"[{e.n}] {e.title} | {e.locator} | effective={e.effective_date}\n"
            f"    {e.snippet}"
        )
    return "\n".join(lines)


def _extract_citation_spans(answer: str) -> List[Dict[str, int]]:
    spans: List[Dict[str, int]] = []
    for m in _CITATION_RE.finditer(answer):
        n = int(m.group(1))
        spans.append({"n": n, "start": m.start(), "end": m.end()})
    return spans


def build_support_cited_graph(k: int = 3):
    model = init_chat_model("gpt-4o-mini", model_provider="openai", temperature=0)
    retriever = build_policy_retriever(k=k)

    def extract_question(state: SupportCitedState):
        last = state["messages"][-1]
        if not isinstance(last, HumanMessage):
            raise ValueError("Expected last message to be a HumanMessage")
        return {"question": last.content}

    def retrieve(state: SupportCitedState):
        docs = retriever.invoke(state["question"])
        return {"raw_docs": docs}

    def validate_and_format(state: SupportCitedState):
        # Prefer current versions when multiple policy revisions exist.
        validated = _pick_most_recent_per_family(state.get("raw_docs", []))
        evidence = _to_evidence_items(validated)

        citations = [
            {
                "n": str(e.n),
                "doc_id": e.doc_id,
                "title": e.title,
                "locator": e.locator,
                "effective_date": e.effective_date,
            }
            for e in evidence
        ]
        return {"evidence": evidence, "citations": citations}

    def answer(state: SupportCitedState):
        evidence: List[EvidenceItem] = state.get("evidence", [])
        if not evidence:
            # No evidence means we do not generate a confident answer.
            answer_text = "I don’t know based on the available policy text."
            return {
                "answer_text": answer_text,
                "citation_spans": [],
                "messages": [AIMessage(content=answer_text)],
            }

        system = (
            "You are a customer support assistant. Answer using ONLY the EVIDENCE below.\n"
            "If the evidence does not contain the answer, say you don't know.\n"
            "For each non-trivial claim, add an inline citation like [1] that refers to an evidence item.\n"
            "Do not invent policies, and do not cite evidence that does not support the claim."
        )

        evidence_block = _build_evidence_block(evidence)
        user = f"QUESTION:\n{state['question']}\n\nEVIDENCE:\n{evidence_block}"

        msg = [SystemMessage(content=system), HumanMessage(content=user)]
        ai = model.invoke(msg)

        answer_text = ai.content
        spans = _extract_citation_spans(answer_text)
        valid_ns = {e.n for e in evidence}
        spans = [s for s in spans if s["n"] in valid_ns]
        
        return {
            "answer_text": answer_text,
            "citation_spans": spans,
            "messages": [AIMessage(content=answer_text)],
        }

    g = StateGraph(SupportCitedState)
    g.add_node("extract_question", extract_question)
    g.add_node("retrieve", retrieve)
    g.add_node("validate_and_format", validate_and_format)
    g.add_node("answer", answer)

    g.add_edge(START, "extract_question")
    g.add_edge("extract_question", "retrieve")
    g.add_edge("retrieve", "validate_and_format")
    g.add_edge("validate_and_format", "answer")
    g.add_edge("answer", END)

    return g.compile()
