# streamlit_app.py
from __future__ import annotations

import streamlit as st
from langchain_core.messages import AIMessage, HumanMessage
from support_backend import build_support_graph


@st.cache_resource
def get_graph():
    return build_support_graph()


def render_transcript():
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.write(m["content"])


def to_lc_messages(chat):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out


st.set_page_config(page_title="Support Policy Assistant", page_icon="💬")

if "chat" not in st.session_state:
    st.session_state.chat = [
        {"role": "assistant", "content": "Hi! Ask me about refunds, returns, or shipping."}
    ]

if "kb_text" not in st.session_state:
    st.session_state.kb_text = ""

graph = get_graph()

st.title("Support Policy Assistant")

left, right = st.columns([2, 1])

with right:
    st.subheader("Policy text")
    uploaded = st.file_uploader("Upload a .txt policy file", type=["txt"])
    if uploaded is not None:
        st.session_state.kb_text = uploaded.read().decode("utf-8", errors="replace")

    if st.session_state.kb_text:
        st.caption("Policy loaded (first 400 chars):")
        st.code(st.session_state.kb_text[:400])

with left:
    render_transcript()

    user_text = st.chat_input("Ask a question…")
    if user_text:
        st.session_state.chat.append({"role": "user", "content": user_text})
        with st.chat_message("user"):
            st.write(user_text)

        state_in = {
            "messages": to_lc_messages(st.session_state.chat),
            "kb_text": st.session_state.kb_text,
        }
        state_out = graph.invoke(state_in)
        assistant_text = state_out["messages"][-1].content

        st.session_state.chat.append({"role": "assistant", "content": assistant_text})
        with st.chat_message("assistant"):
            st.write(assistant_text)


