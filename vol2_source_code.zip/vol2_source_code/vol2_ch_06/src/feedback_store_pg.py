from __future__ import annotations
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
import psycopg

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class TurnRecord:
    turn_id: str
    thread_id: str
    user_text: str
    assistant_text: str
    created_at: str

@dataclass(frozen=True)
class FeedbackEvent:
    turn_id: str
    rating: Optional[int] = None            # +1 / -1 or 1..5
    reasons: Optional[list[str]] = None     # reason tags (controlled vocabulary)
    comment: Optional[str] = None
    correction: Optional[str] = None        # edited answer text
    created_at: str = utc_now_iso()

class FeedbackStore:
    def __init__(self, dsn: Optional[str] = None):
        self.dsn = dsn or os.environ.get("DATABASE_URL")
        if not self.dsn:
            raise ValueError("DATABASE_URL is required (PostgreSQL DSN).")
        self._init_db()

    def _connect(self):
        # Simple and robust for examples: open a connection per call.
        # (For high-throughput services you would typically use a pool.)
        return psycopg.connect(self.dsn, autocommit=True)

    def _init_db(self) -> None:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS turns (
                        turn_id TEXT PRIMARY KEY,
                        thread_id TEXT NOT NULL,
                        user_text TEXT NOT NULL,
                        assistant_text TEXT NOT NULL,
                        created_at TIMESTAMPTZ NOT NULL
                    );
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS feedback_events (
                        id BIGSERIAL PRIMARY KEY,
                        turn_id TEXT NOT NULL REFERENCES turns(turn_id) ON DELETE CASCADE,
                        rating INTEGER,
                        reasons TEXT[] NULL,
                        comment TEXT,
                        correction TEXT,
                        created_at TIMESTAMPTZ NOT NULL
                    );
                    """
                )
                cur.execute("CREATE INDEX IF NOT EXISTS idx_turns_thread_id ON turns(thread_id);")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_feedback_turn_id ON feedback_events(turn_id);")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_feedback_created_at ON feedback_events(created_at);")

    def save_turn(self, record: TurnRecord) -> None:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO turns (turn_id, thread_id, user_text, assistant_text, created_at)
                    VALUES (%s, %s, %s, %s, %s::timestamptz)
                    """,
                    (
                        record.turn_id,
                        record.thread_id,
                        record.user_text,
                        record.assistant_text,
                        record.created_at,
                    ),
                )

    def add_feedback(self, event: FeedbackEvent) -> None:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO feedback_events (turn_id, rating, reasons, comment, correction, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s::timestamptz)
                    """,
                    (
                        event.turn_id,
                        event.rating,
                        event.reasons,
                        event.comment,
                        event.correction,
                        event.created_at,
                    ),
                )

    def helpful_rate(self) -> tuple[int, int]:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COALESCE(SUM(CASE WHEN rating > 0 THEN 1 ELSE 0 END), 0) AS up,
                        COALESCE(SUM(CASE WHEN rating < 0 THEN 1 ELSE 0 END), 0) AS down
                    FROM feedback_events
                    WHERE rating IS NOT NULL
                    """
                )
                up, down = cur.fetchone()
                return int(up), int(down)

    def recent_downvotes(self, limit: int = 20) -> list[tuple[str, str, str, str]]:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT t.turn_id, t.user_text, t.assistant_text, t.created_at::text
                    FROM turns t
                    WHERE EXISTS (
                        SELECT 1
                        FROM feedback_events f
                        WHERE f.turn_id = t.turn_id AND f.rating < 0
                    )
                    ORDER BY t.created_at DESC
                    LIMIT %s
                    """,
                    (limit,),
                )
                return list(cur.fetchall())
