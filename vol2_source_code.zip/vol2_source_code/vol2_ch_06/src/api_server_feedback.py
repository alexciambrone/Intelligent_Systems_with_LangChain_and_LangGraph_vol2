from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .support_graph import build_support_graph
from .feedback_store_pg import FeedbackStore, TurnRecord, FeedbackEvent


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


app = FastAPI()
graph = build_support_graph()

store = FeedbackStore(dsn="postgresql://postgres:root@localhost:5432/feedback")


class ChatMsg(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    thread_id: str = Field(..., description="Conversation/session id")
    messages: list[ChatMsg]


class ChatResponse(BaseModel):
    turn_id: str
    assistant: str


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    if not req.messages or req.messages[-1].role != "user":
        raise HTTPException(status_code=400, detail="Last message must be from the user.")

    turn_id = str(uuid.uuid4())
    user_text = req.messages[-1].content

    # LangGraph accepts message-like dicts; add_messages will merge into state.
    state_in = {"messages": [{"role": m.role, "content": m.content} for m in req.messages]}
    state_out = graph.invoke(state_in)

    last = state_out["messages"][-1]
    assistant_text = getattr(last, "content", None)
    if assistant_text is None and isinstance(last, dict):
        assistant_text = last.get("content")
    if not assistant_text:
        assistant_text = str(last)

    store.save_turn(
        TurnRecord(
            turn_id=turn_id,
            thread_id=req.thread_id,
            user_text=user_text,
            assistant_text=assistant_text,
            created_at=utc_now_iso(),
        )
    )

    return ChatResponse(turn_id=turn_id, assistant=assistant_text)


REASON_TAGS = [
    "Factually incorrect",
    "Didn’t follow instructions",
    "Missing important details",
    "Too verbose / hard to scan",
    "Off-topic",
    "Other",
]


class FeedbackRequest(BaseModel):
    turn_id: str
    rating: Optional[int] = Field(None, description="+1/-1 or 1..5")
    reasons: Optional[list[str]] = None
    comment: Optional[str] = None
    correction: Optional[str] = None


@app.post("/feedback")
def feedback(req: FeedbackRequest):
    if req.reasons:
        unknown = [r for r in req.reasons if r not in REASON_TAGS]
        if unknown:
            raise HTTPException(status_code=400, detail=f"Unknown reason tag(s): {unknown}")

    store.add_feedback(
        FeedbackEvent(
            turn_id=req.turn_id,
            rating=req.rating,
            reasons=req.reasons,
            comment=req.comment,
            correction=req.correction,
        )
    )
    return {"ok": True}
