from __future__ import annotations

from typing import List

from langchain_core.messages import HumanMessage

from .support_cited_backend import EvidenceItem, build_support_cited_graph


def _print_sources(evidence: List[EvidenceItem], show_excerpts: bool) -> None:
    if not evidence:
        print("(no sources)\n")
        return

    print("\n--- SOURCES ---")
    for e in evidence:
        print(f"[{e.n}] {e.title} ({e.locator}, effective={e.effective_date})")
        if show_excerpts:
            print(f"    {e.full_text}")
    print("---------------\n")


def main():
    graph = build_support_cited_graph(k=3)

    print("Support assistant ready. Type /sources, /excerpts, or /exit.")
    last_evidence: List[EvidenceItem] = []
    last_cited_ns: set[int] = set()

    while True:
        user = input("user> ").strip()
        if not user:
            continue
        if user == "/exit":
            break
            
        if user == "/sources":
            ev = [e for e in last_evidence if e.n in last_cited_ns] if last_cited_ns else last_evidence
            _print_sources(ev, show_excerpts=False)
            continue
        if user == "/excerpts":
            ev = [e for e in last_evidence if e.n in last_cited_ns] if last_cited_ns else last_evidence
            _print_sources(ev, show_excerpts=True)
            continue    
            
        out = graph.invoke({"messages": [HumanMessage(content=user)]})

        answer = out["answer_text"]
        last_evidence = out.get("evidence", [])
        last_cited_ns = {span["n"] for span in out.get("citation_spans", [])}
        print(f"assistant> {answer}\n")


if __name__ == "__main__":
    main()
