from __future__ import annotations

import streamlit as st
from langchain_core.messages import AIMessage, HumanMessage
from support_backend import build_support_graph


def to_lc_messages(chat: list[dict[str, str]]):
    out = []
    for m in chat:
        if m["role"] == "user":
            out.append(HumanMessage(content=m["content"]))
        else:
            out.append(AIMessage(content=m["content"]))
    return out


@st.cache_resource
def get_graph():
    # Build once per Streamlit process (keeps the UI adapter thin and fast).
    return build_support_graph()


def token_stream(graph, state_in, buffer: list[str]):
    # Stream only text tokens. Also accumulate them so we can persist the final message.
    for msg_chunk, _meta in graph.stream(state_in, stream_mode="messages"):
        if msg_chunk.content:
            buffer.append(msg_chunk.content)
            yield msg_chunk.content


def main():
    st.set_page_config(page_title="Support Assistant (Streaming)", layout="centered")
    st.title("Support Assistant")

    graph = get_graph()

    # Demo policy KB text. In your real app this comes from your KB layer.
    policy_text = (
        "Refunds: You can request a refund within 30 days of delivery. "
        "Refunds are issued to the original payment method within 5 business days "
        "after the returned item is received and inspected."
    )

    # Session state transcript (UI-level chat history).
    if "chat" not in st.session_state:
        st.session_state.chat = [
            {"role": "assistant", "content": "Support assistant ready. Ask about refunds or returns."}
        ]

    with st.sidebar:
        if st.button("Clear chat"):
            st.session_state.chat = [
                {"role": "assistant", "content": "Support assistant ready. Ask about refunds or returns."}
            ]
            st.rerun()

    # Render transcript so far.
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.write(m["content"])

    # User input.
    user_text = st.chat_input("Type your question…")
    if not user_text:
        return

    # Append user message and render it immediately.
    st.session_state.chat.append({"role": "user", "content": user_text})
    with st.chat_message("user"):
        st.write(user_text)

    # Build backend input state from transcript.
    state_in = {
        "messages": to_lc_messages(st.session_state.chat),
        "kb_text": policy_text,
    }

    # Stream assistant tokens into the UI, and persist the final assembled text.
    with st.chat_message("assistant"):
        buffer: list[str] = []
        # st.write_stream renders incrementally; it may or may not return the final string depending on version.
        returned = st.write_stream(token_stream(graph, state_in, buffer))
        assistant_text = returned if isinstance(returned, str) and returned else "".join(buffer)

    st.session_state.chat.append({"role": "assistant", "content": assistant_text})


if __name__ == "__main__":
    main()


