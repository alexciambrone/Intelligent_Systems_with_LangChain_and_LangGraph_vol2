from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Callable, Dict, List


# -----------------------------
# 1) Metrics + evaluation loop
# -----------------------------

@dataclass(frozen=True)
class Result:
    config: Dict[str, int]
    recall_at_k: float
    p95_ms: float


def p95(values: List[float]) -> float:
    """Simple p95 for small samples."""
    xs = sorted(values)
    idx = int(0.95 * (len(xs) - 1))
    return xs[idx]


def evaluate(
    *,
    run_query: Callable[[str, Dict[str, int]], List[str]],
    queries: List[str],
    ground_truth: Dict[str, List[str]],
    config: Dict[str, int],
    k: int,
) -> Result:
    """
    Measure:
      - Recall@k: overlap between top-k results and top-k ground truth
      - p95 latency: 95th percentile latency across queries
    """
    latencies_ms: List[float] = []
    hits = 0
    total = 0

    for q in queries:
        start = time.perf_counter()
        got = run_query(q, config)[:k]
        latencies_ms.append((time.perf_counter() - start) * 1000)

        truth_topk = set(ground_truth[q][:k])
        hits += sum(1 for doc_id in got if doc_id in truth_topk)
        total += k

    recall = hits / total if total else 0.0
    return Result(config=config, recall_at_k=recall, p95_ms=p95(latencies_ms))


# -----------------------------------------
# 2) Fake backend (runs offline, deterministic)
# -----------------------------------------

def fake_run_query(query: str, cfg: Dict[str, int]) -> List[str]:
    """
    Simulates an ANN-style backend:
      - Higher efSearch costs more time (sleep)
      - Higher efSearch returns results closer to the "true" ranking

    Replace this function with a real vector DB query, e.g.:
      results = collection.search(query_vector, limit=50, params={"efSearch": cfg["efSearch"]})
      return [r.id for r in results]
    """
    ef = cfg["efSearch"]

    # Latency grows with efSearch (simulating more candidate exploration)
    time.sleep(ef / 4000.0)  # adjust divisor to make output snappy

    # "True" ranking for this query (deterministic)
    random.seed(hash(query))
    truth = [f"doc_{random.randint(1, 200)}" for _ in range(50)]

    # Our ANN approximation: with higher efSearch, we keep more of the truth at the top.
    keep = min(50, max(1, ef // 8))  # ef=16 => 2, ef=256 => 32
    approx_top = truth[:keep]

    # Fill the rest with distractors (still deterministic per query+ef)
    random.seed(hash(query) + ef)
    distractors = [f"doc_{random.randint(1, 200)}" for _ in range(50 - keep)]

    # Return "top 50" results
    return approx_top + distractors


# -----------------------------
# 3) Run the sweep + pick best
# -----------------------------

def main() -> None:
    # Support/e-commerce flavored queries (small, realistic set)
    queries = ["refund status", "track order", "cancel order", "invoice missing"]

    # Ground truth baseline (in a real system: exact search or trusted reranked set)
    # Here we reuse the deterministic "truth" generation logic.
    ground_truth: Dict[str, List[str]] = {}
    for q in queries:
        random.seed(hash(q))
        ground_truth[q] = [f"doc_{random.randint(1, 200)}" for _ in range(50)]

    # Sweep a query-time ANN knob (efSearch is a common one)
    candidates = [{"efSearch": v} for v in [16, 32, 64, 128, 256]]

    results = [
        evaluate(
            run_query=fake_run_query,
            queries=queries,
            ground_truth=ground_truth,
            config=cfg,
            k=10,
        )
        for cfg in candidates
    ]

    # Pick the lowest p95 latency that still meets recall target
    target_recall = 0.90
    ok = [r for r in results if r.recall_at_k >= target_recall]
    best = min(ok, key=lambda r: r.p95_ms) if ok else None

    print("Sweep results:")
    for r in results:
        print(f"  {r.config} -> recall@10={r.recall_at_k:.2f}, p95_ms={r.p95_ms:.1f}")

    print("\nChosen configuration:")
    print(f"  target_recall={target_recall:.2f}")
    print(f"  best={best}")


if __name__ == "__main__":
    main()
