import uuid
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from langchain_core.stores import InMemoryStore
from langchain_classic.retrievers.multi_vector import MultiVectorRetriever, SearchType
from .config import OPENAI_API_KEY

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Stores:
vectorstore = InMemoryVectorStore(embeddings)   # stores multiple “views” as separate vectors
docstore = InMemoryStore()                      # stores the parent documents (by id)

# Create parent docs (what we want to return)
parent_docs = [
    Document(
        page_content=(
            "Macro note: If CPI surprises to the upside, expect rate-cut odds to drop; "
            "duration-heavy equities may underperform short-term."
        ),
        metadata={"domain": "trading", "type": "macro_note"},
    ),
    Document(
        page_content=(
            "Company note: ACME earnings showed margin compression; guidance lowered. "
            "Watch for inventory drawdown next quarter."
        ),
        metadata={"domain": "trading", "type": "equity_note"},
    ),
]

# Assign stable ids
parent_ids = [str(uuid.uuid4()) for _ in parent_docs]

# Store parents
docstore.mset(list(zip(parent_ids, parent_docs)))

# Create multi-vector “views” (these are what we actually embed and search)
child_docs = [
    # Parent 0: title + summary
    Document(page_content="CPI surprise impacts rate cuts", metadata={"doc_id": parent_ids[0], "view": "title"}),
    Document(page_content="Inflation surprise reduces rate-cut probability; impacts duration assets.", metadata={"doc_id": parent_ids[0], "view": "summary"}),

    # Parent 1: title + summary
    Document(page_content="ACME earnings: margins down", metadata={"doc_id": parent_ids[1], "view": "title"}),
    Document(page_content="Earnings miss with margin compression and lowered guidance; monitor inventory.", metadata={"doc_id": parent_ids[1], "view": "summary"}),
]

vectorstore.add_documents(child_docs)

retriever = MultiVectorRetriever(
    vectorstore=vectorstore,
    docstore=docstore,
    id_key="doc_id",
    search_type=SearchType.similarity,
    search_kwargs={"k": 2},
)

query = "What happens if inflation surprises higher?"
hits = retriever.invoke(query)

for d in hits:
    print(d.metadata, "->", d.page_content)


