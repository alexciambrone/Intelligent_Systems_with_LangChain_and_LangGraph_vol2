from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Iterable, List

from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from langchain_classic.storage import InMemoryStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_classic.retrievers.parent_document_retriever import ParentDocumentRetriever
from langchain_classic.retrievers.multi_vector import SearchType

from .config import OPENAI_API_KEY


ID_KEY = "doc_id"


def print_section(title: str) -> None:
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def indent(text: str, prefix: str) -> str:
    return "\n".join(prefix + line for line in text.splitlines())


def compact(text: str, max_chars: int = 220) -> str:
    text = " ".join((text or "").split())
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3] + "..."


def extract_child_records(vectorstore: InMemoryVectorStore) -> List[Dict[str, Any]]:
    """
    Diagnostic helper for the demo.

    ParentDocumentRetriever stores child chunks in the vector store. The public
    retriever API normally hides this detail, but inspecting the in-memory store
    makes the parent/child mechanism visible for teaching purposes.

    This function is intentionally diagnostic-only. Production code should treat
    the vector store as an abstraction.
    """
    records: List[Dict[str, Any]] = []

    raw_store = getattr(vectorstore, "store", {})

    for fallback_id, item in raw_store.items():
        if not isinstance(item, dict):
            continue

        vector_id = item.get("id") or fallback_id
        text = item.get("text") or item.get("page_content") or ""
        metadata = item.get("metadata") or {}

        records.append(
            {
                "vector_id": vector_id,
                "parent_id": metadata.get(ID_KEY),
                "text": text,
                "metadata": metadata,
            }
        )

    return records


def print_parent_documents(parents: List[Document]) -> None:
    print_section("1) Parent documents supplied to the retriever")

    for i, parent in enumerate(parents, start=1):
        parent_id = parent.metadata[ID_KEY]

        print(f"\nPARENT {i}")
        print(f"  parent doc_id: {parent_id}")
        print(f"  metadata: {parent.metadata}")
        print("  content:")
        print(indent(parent.page_content, "    "))


def print_indexed_children(vectorstore: InMemoryVectorStore) -> None:
    print_section("2) Child chunks stored in the vector store")

    child_records = extract_child_records(vectorstore)

    if not child_records:
        print(
            "No child records were found by the diagnostic inspector. "
            "The retriever may still work, but this LangChain version may expose "
            "the in-memory vector store internals differently."
        )
        return

    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for record in child_records:
        grouped[record["parent_id"]].append(record)

    print(
        "The vector store stores small child chunks, not the parent documents. "
        "Each child chunk carries a doc_id that points back to its parent."
    )

    for parent_id, children in grouped.items():
        print(f"\nParent doc_id: {parent_id}")
        print(f"Child chunks indexed for this parent: {len(children)}")

        for i, child in enumerate(children, start=1):
            print(f"  CHILD {i}")
            print(f"    vector id: {child['vector_id']}")
            print(f"    child metadata doc_id: {child['metadata'].get(ID_KEY)}")
            print(f"    child text: {compact(child['text'])}")


def print_child_vector_hits(
    vectorstore: InMemoryVectorStore,
    query: str,
    k: int = 1,
) -> List[Document]:
    print_section("3) Direct vector search over child chunks")

    print(f"Query: {query!r}")
    print(f"Child search k: {k}")
    print(
        "\nThis search is run directly against the vector store. "
        "Therefore the result below is a child chunk, not a parent document."
    )

    child_hits = vectorstore.similarity_search(query, k=k)

    for i, child in enumerate(child_hits, start=1):
        print(f"\nCHILD HIT {i}")
        print(f"  parent doc_id from child metadata: {child.metadata.get(ID_KEY)}")
        print(f"  child metadata: {child.metadata}")
        print(f"  child text: {compact(child.page_content)}")

    return child_hits


def unique_parent_ids_from_child_hits(child_hits: Iterable[Document]) -> List[str]:
    parent_ids: List[str] = []
    seen = set()

    for child in child_hits:
        parent_id = child.metadata.get(ID_KEY)

        if parent_id and parent_id not in seen:
            parent_ids.append(parent_id)
            seen.add(parent_id)

    return parent_ids


def print_manual_parent_hydration(
    docstore: InMemoryStore,
    child_hits: List[Document],
) -> None:
    print_section("4) Manual parent lookup using child metadata")

    parent_ids = unique_parent_ids_from_child_hits(child_hits)

    print("Parent IDs collected from child hits:")

    if not parent_ids:
        print("  - none")
        return

    for parent_id in parent_ids:
        print(f"  - {parent_id}")

    print(
        "\nThe retriever uses these IDs to fetch the larger parent documents "
        "from the docstore."
    )

    parents = docstore.mget(parent_ids)

    for parent_id, parent in zip(parent_ids, parents):
        print(f"\nLOOKUP parent_id: {parent_id}")

        if parent is None:
            print("  No parent document found.")
            continue

        print(f"  returned parent metadata: {parent.metadata}")
        print(f"  returned parent content preview: {compact(parent.page_content)}")


def print_retriever_results(
    retriever: ParentDocumentRetriever,
    query: str,
) -> None:
    print_section("5) ParentDocumentRetriever final result")

    print(f"Query: {query!r}")
    print(
        "\nNow we call retriever.invoke(query). "
        "The retriever searches child chunks first, then returns parent documents."
    )

    parent_hits = retriever.invoke(query)

    print(f"\nNumber of parent documents returned: {len(parent_hits)}")

    for i, parent in enumerate(parent_hits, start=1):
        print(f"\nRETURNED PARENT {i}")
        print(f"  parent doc_id: {parent.metadata.get(ID_KEY)}")
        print(f"  metadata: {parent.metadata}")
        print("  full parent content:")
        print(indent(parent.page_content, "    "))


def main() -> None:
    embeddings = OpenAIEmbeddings(
        model="text-embedding-3-small",
        api_key=OPENAI_API_KEY,
    )

    # The vector store indexes child chunks.
    vectorstore = InMemoryVectorStore(embeddings)

    # The docstore holds parent documents.
    docstore = InMemoryStore()

    # Parent documents, as they might appear after ingestion and cleaning.
    parents = [
        Document(
            page_content=(
                "Refund Policy (v3)\n\n"
                "1) Approval: refunds are approved within 48 hours.\n"
                "2) Payout: once approved, payout completes within 5 business days.\n"
                "3) Exceptions: bank processing can add delays.\n"
            ),
            metadata={
                "doc_id": "policy:refunds:v3",
                "tenant_id": "tenant_a",
                "locale": "en",
                "document_type": "policy",
            },
        ),
        Document(
            page_content=(
                "Returns Policy (v2)\n\n"
                "Return window is 30 days from delivery date.\n"
                "Items must be unused and include proof of purchase.\n"
            ),
            metadata={
                "doc_id": "policy:returns:v2",
                "tenant_id": "tenant_a",
                "locale": "en",
                "document_type": "policy",
            },
        ),
    ]

    child_splitter = RecursiveCharacterTextSplitter(
        chunk_size=120,
        chunk_overlap=20,
    )

    retriever = ParentDocumentRetriever(
        vectorstore=vectorstore,
        docstore=docstore,
        child_splitter=child_splitter,
        id_key=ID_KEY,
        search_type=SearchType.similarity,
        search_kwargs={"k": 1},
    )

    # Pass stable parent IDs explicitly.
    #
    # These IDs are used in two places:
    # 1. as keys in the docstore
    # 2. as child_chunk.metadata[ID_KEY] in the vector store
    #
    # This is the link that allows a matching child chunk to retrieve its parent.
    parent_ids = [parent.metadata[ID_KEY] for parent in parents]

    print_parent_documents(parents)

    retriever.add_documents(
        documents=parents,
        ids=parent_ids,
    )

    print_indexed_children(vectorstore)

    query = "After a refund is approved, how long until payout?"

    child_hits = print_child_vector_hits(
        vectorstore=vectorstore,
        query=query,
        k=1,
    )

    print_manual_parent_hydration(
        docstore=docstore,
        child_hits=child_hits,
    )

    print_retriever_results(
        retriever=retriever,
        query=query,
    )


if __name__ == "__main__":
    main()