from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple

from langchain_openai import OpenAIEmbeddings
from .config import OPENAI_API_KEY

def cosine_similarity(a: List[float], b: List[float]) -> float:
    dot = 0.0
    na = 0.0
    nb = 0.0
    for x, y in zip(a, b):
        dot += x * y
        na += x * x
        nb += y * y
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / ((na ** 0.5) * (nb ** 0.5))


@dataclass
class CacheEntry:
    tenant_id: str
    locale: str
    question: str
    q_vec: List[float]
    answer: str
    created_at: float


class SemanticCache:
    """
    Semantic cache:
    - Stores (question embedding -> answer)
    - On lookup, returns cached answer if similarity >= threshold
    - Enforces tenant_id + locale boundaries
    - Optional TTL
    """

    def __init__(
        self,
        *,
        embeddings: OpenAIEmbeddings,
        threshold: float = 0.88,
        ttl_seconds: Optional[int] = 300,
    ) -> None:
        self.embeddings = embeddings
        self.threshold = threshold
        self.ttl_seconds = ttl_seconds
        self._entries: List[CacheEntry] = []

    def _is_fresh(self, entry: CacheEntry) -> bool:
        if self.ttl_seconds is None:
            return True
        return (time.time() - entry.created_at) <= self.ttl_seconds

    def get(
        self,
        *,
        tenant_id: str,
        locale: str,
        question: str,
        debug_top_n: int = 3,
    ) -> Tuple[Optional[str], float]:
        q_vec = self.embeddings.embed_query(question)

        scored: List[Tuple[float, CacheEntry]] = []
        for e in self._entries:
            if e.tenant_id != tenant_id or e.locale != locale:
                continue
            if not self._is_fresh(e):
                continue
            score = cosine_similarity(q_vec, e.q_vec)
            scored.append((score, e))

        scored.sort(key=lambda t: t[0], reverse=True)
        best_score = scored[0][0] if scored else 0.0
        best_answer = scored[0][1].answer if scored else None

        # Optional debug: show nearest neighbors so you can *see* semantic behavior
        if debug_top_n > 0 and scored:
            print("  nearest in-cache questions:")
            for s, e in scored[:debug_top_n]:
                print(f"   - score={s:.3f}  {e.question!r}")

        if best_answer is not None and best_score >= self.threshold:
            return best_answer, best_score

        return None, best_score

    def put(
        self,
        *,
        tenant_id: str,
        locale: str,
        question: str,
        answer: str,
    ) -> None:
        self._entries.append(
            CacheEntry(
                tenant_id=tenant_id,
                locale=locale,
                question=question,
                q_vec=self.embeddings.embed_query(question),
                answer=answer,
                created_at=time.time(),
            )
        )


def generate_answer(question: str) -> str:
    # Stand-in for "expensive pipeline" (retrieve + LLM).
    q = question.lower()
    if any(w in q for w in ["track", "shipment", "package", "order", "delivery"]):
        return "You can track your order in the Orders page under 'Track shipment'."
    return "I can help—can you share your order number?"


if __name__ == "__main__":
    # Real semantic embeddings
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

    cache = SemanticCache(
        embeddings=embeddings,
        threshold=0.88,   # start here; adjust with real traffic
        ttl_seconds=120,
    )

    ctx_en = {"tenant_id": "shop_123", "locale": "en-GB"}

    questions_en = [
        "Where is my package?",
        "Track my order please",
        "I want to track my shipment",
        "Where is my package?",  # exact repeat
    ]

    for q in questions_en:
        cached, score = cache.get(**ctx_en, question=q, debug_top_n=3)
        if cached is not None:
            print(f"[CACHE HIT score={score:.3f}] Q={q!r}\n  A={cached}\n")
            continue

        a = generate_answer(q)
        cache.put(**ctx_en, question=q, answer=a)
        print(f"[CACHE MISS best_score={score:.3f}] Q={q!r}\n  A={a}\n")

    # Locale gating example: semantically similar, but different locale => expected miss
    ctx_it = {"tenant_id": "shop_123", "locale": "it-IT"}
    q_it = "Dove è il mio pacco?"
    cached, score = cache.get(**ctx_it, question=q_it, debug_top_n=3)
    print(f"[IT LOOKUP] cached={cached is not None}, best_score={score:.3f} (expected: miss due to locale)\n")
