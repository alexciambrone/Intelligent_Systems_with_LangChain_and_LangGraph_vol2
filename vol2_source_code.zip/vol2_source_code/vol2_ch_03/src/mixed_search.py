from __future__ import annotations

import re
from typing import List

from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from langchain_community.retrievers import BM25Retriever
from langchain_classic.retrievers import EnsembleRetriever

from .config import OPENAI_API_KEY


# -----------------------------
# Example corpus: support KB
# -----------------------------
docs: List[Document] = [
    Document(
        page_content=(
            "Refund policy: refunds are approved within 48 hours, then paid within "
            "5 business days. For Premium plans, refunds are paid within 2 business days."
        ),
        metadata={"doc_id": "kb:refunds", "locale": "en"},
    ),
    Document(
        page_content=(
            "Error E42: Payment authorization failed. Causes: expired card, "
            "3DS challenge not completed, or bank decline. Resolution: retry payment, "
            "verify 3DS, or use a different card."
        ),
        metadata={"doc_id": "kb:error_e42", "locale": "en"},
    ),
    Document(
        page_content=(
            "Shipping policy: delivery in 2–5 business days depending on destination. "
            "Express shipping is available for select regions."
        ),
        metadata={"doc_id": "kb:shipping", "locale": "en"},
    ),
]


# -----------------------------
# Dense retriever: vector search
# -----------------------------
embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key=OPENAI_API_KEY,
)

vectorstore = InMemoryVectorStore.from_documents(
    documents=docs,
    embedding=embeddings,
)

vector_retriever = vectorstore.as_retriever(
    search_kwargs={"k": 4}
)


# -----------------------------
# Sparse retriever: BM25 lexical search
# -----------------------------
bm25_retriever = BM25Retriever.from_documents(
    documents=docs,
    bm25_params={"k1": 1.5, "b": 0.75},
)

bm25_retriever.k = 4


# -----------------------------
# Static hybrid retriever
# -----------------------------
static_hybrid_retriever = EnsembleRetriever(
    retrievers=[vector_retriever, bm25_retriever],
    weights=[0.7, 0.3],
)


# -----------------------------
# Query-dependent hybrid retriever
# -----------------------------
CODELIKE = re.compile(
    r"([A-Z]{1,5}-\d{2,}|0x[0-9A-Fa-f]+|E\d{2,}|\bSKU\b)",
    re.IGNORECASE,
)


def hybrid_with_query_dependent_weights(query: str) -> EnsembleRetriever:
    """
    Returns a hybrid retriever with weights adjusted to the query shape.

    Natural-language questions usually benefit from stronger vector weighting.
    Identifier/code-like queries usually benefit from stronger lexical weighting.
    """
    if CODELIKE.search(query):
        # More lexical weight when the query contains identifiers, error codes, or SKUs.
        weights = [0.5, 0.5]
    else:
        # More semantic weight for ordinary natural-language questions.
        weights = [0.8, 0.2]

    return EnsembleRetriever(
        retrievers=[vector_retriever, bm25_retriever],
        weights=weights,
    )


def print_hits(title: str, query: str, hits: List[Document]) -> None:
    print(f"\n{title}")
    print(f"QUERY: {query}")

    for i, doc in enumerate(hits, start=1):
        doc_id = doc.metadata.get("doc_id", "-")
        preview = " ".join(doc.page_content.split())[:100]
        print(f"  {i}. {doc_id} -> {preview}...")


def main() -> None:
    queries = [
        "How long does a refund take?",
        "E42 payment error",
    ]

    for query in queries:
        static_hits = static_hybrid_retriever.invoke(query)
        print_hits(
            title="STATIC HYBRID RETRIEVER",
            query=query,
            hits=static_hits,
        )

        dynamic_retriever = hybrid_with_query_dependent_weights(query)
        dynamic_hits = dynamic_retriever.invoke(query)
        print_hits(
            title="QUERY-DEPENDENT HYBRID RETRIEVER",
            query=query,
            hits=dynamic_hits,
        )


if __name__ == "__main__":
    main()