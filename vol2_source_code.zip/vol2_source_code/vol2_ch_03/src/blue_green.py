from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from langchain_core.documents import Document
from langchain_core.embeddings.fake import DeterministicFakeEmbedding
from langchain_core.indexing.api import index
from langchain_core.indexing.base import InMemoryRecordManager
from langchain_core.vectorstores import InMemoryVectorStore


# -----------------------------
# Helpers
# -----------------------------
def chunked(it: Iterable[Document], size: int) -> Iterator[List[Document]]:
    batch: List[Document] = []
    for d in it:
        batch.append(d)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch


def _stats(res: Any) -> Dict[str, int]:
    """Extract IndexingResult counters across LangChain Core versions."""
    keys = ("num_added", "num_updated", "num_deleted", "num_skipped")

    # 1) attribute-style (dataclass-like)
    if all(hasattr(res, k) for k in keys):
        return {k: int(getattr(res, k, 0)) for k in keys}

    # 2) pydantic-like
    if hasattr(res, "dict"):
        d = res.dict()
        return {k: int(d.get(k, 0)) for k in keys}

    # 3) mapping/dict-like
    if isinstance(res, Mapping):
        return {k: int(res.get(k, 0)) for k in keys}

    # 4) last resort
    try:
        d = dict(res)
        return {k: int(d.get(k, 0)) for k in keys}
    except Exception:
        return {k: 0 for k in keys}


def dual_write_index_stream(
    docs: Iterable[Document],
    *,
    blue: Tuple[InMemoryRecordManager, InMemoryVectorStore],
    green: Tuple[InMemoryRecordManager, InMemoryVectorStore],
    cleanup: str,
    source_id_key: str = "source_id",
    key_encoder: str = "sha256",
    batch_size: int = 100,
) -> Tuple[dict, dict]:
    """
    Dual-write the same document stream into two targets (blue/green).

    cleanup="incremental" requires a stable per-document identifier (source_id_key)
    so stale chunks for “seen” source_ids can be removed safely.
    """
    blue_rm, blue_vs = blue
    green_rm, green_vs = green

    blue_totals = {"num_added": 0, "num_updated": 0, "num_deleted": 0, "num_skipped": 0}
    green_totals = {"num_added": 0, "num_updated": 0, "num_deleted": 0, "num_skipped": 0}

    for batch in chunked(docs, batch_size):
        blue_res = index(
            batch,
            blue_rm,
            blue_vs,
            cleanup=cleanup,
            source_id_key=source_id_key,
            key_encoder=key_encoder,
        )
        green_res = index(
            batch,
            green_rm,
            green_vs,
            cleanup=cleanup,
            source_id_key=source_id_key,
            key_encoder=key_encoder,
        )

        b = _stats(blue_res)
        g = _stats(green_res)
        for k in blue_totals:
            blue_totals[k] += b[k]
            green_totals[k] += g[k]

    return blue_totals, green_totals


# -----------------------------
# Read path + cutover simulation
# -----------------------------
@dataclass
class TrafficRouter:
    """A tiny 'feature flag' style router: reads go to the active color."""
    active: str  # "blue" or "green"

    def set_active(self, color: str) -> None:
        if color not in ("blue", "green"):
            raise ValueError("color must be 'blue' or 'green'")
        self.active = color

    def route(self, blue_vs: InMemoryVectorStore, green_vs: InMemoryVectorStore) -> InMemoryVectorStore:
        return blue_vs if self.active == "blue" else green_vs


def top_hit(vs: InMemoryVectorStore, query: str) -> Document | None:
    hits = vs.similarity_search(query, k=1)
    return hits[0] if hits else None


def print_answer(color: str, doc: Document | None) -> None:
    if doc is None:
        print(f"[READ {color.upper()}] no results")
        return
    sid = doc.metadata.get("source_id", "?")
    print(f"[READ {color.upper()}] source_id={sid} | content={doc.page_content}")


def main() -> None:
    # Two independent targets: separate record managers, separate vector stores.
    embed = DeterministicFakeEmbedding(size=16)

    blue_rm = InMemoryRecordManager(namespace="support_kb_blue")
    green_rm = InMemoryRecordManager(namespace="support_kb_green")

    blue_vs = InMemoryVectorStore(embed)
    green_vs = InMemoryVectorStore(embed)

    # Base corpus (same docs go to both)
    docs = [
        Document(
            page_content="Refunds are processed within 5 business days.",
            metadata={"source_id": "policy_refunds"},
        ),
        Document(
            page_content="E42 error means the payment provider timed out.",
            metadata={"source_id": "kb_errors"},
        ),
        Document(
            page_content="To change delivery address, contact support within 1 hour.",
            metadata={"source_id": "kb_delivery"},
        ),
    ]

    print("== Phase 1: dual-write initial corpus (BLUE + GREEN) ==")
    blue_stats, green_stats = dual_write_index_stream(
        docs,
        blue=(blue_rm, blue_vs),
        green=(green_rm, green_vs),
        cleanup="incremental",
        source_id_key="source_id",
        key_encoder="sha256",
        batch_size=2,
    )
    print("blue:", blue_stats)
    print("green:", green_stats)

    # Show that reads are identical right now (because content is identical)
    router = TrafficRouter(active="blue")
    query = "How long do refunds take?"

    print("\n== Phase 2: reads before cutover ==")
    vs_active = router.route(blue_vs, green_vs)
    print(f"active_route={router.active.upper()} | query={query}")
    print_answer(router.active, top_hit(vs_active, query))

    # Now simulate a GREEN-only update (e.g., new policy version) while BLUE stays untouched.
    # This is the typical blue/green story: keep writing to green, validate, then switch traffic.
    print("\n== Phase 3: GREEN-only update (candidate index differs) ==")
    updated_green_doc = Document(
        page_content="Refunds are processed within 7 business days (updated policy).",
        metadata={"source_id": "policy_refunds"},  # same source_id => updates the record for this source
    )
    green_update_res = index(
        [updated_green_doc],
        green_rm,
        green_vs,
        cleanup="incremental",
        source_id_key="source_id",
        key_encoder="sha256",
    )
    print("green_update:", _stats(green_update_res))

    # Show the difference explicitly
    print("\n== Phase 4: compare BLUE vs GREEN answers (still routed to BLUE) ==")
    print_answer("blue", top_hit(blue_vs, query))
    print_answer("green", top_hit(green_vs, query))

    # Cutover: switch read traffic from BLUE to GREEN
    print("\n== Phase 5: CUTOVER (shift traffic from BLUE -> GREEN) ==")
    router.set_active("green")
    vs_active = router.route(blue_vs, green_vs)
    print(f"active_route={router.active.upper()} | query={query}")
    print_answer(router.active, top_hit(vs_active, query))

    # Optional: roll-back is just another flip (kept here to show the symmetry)
    print("\n== Phase 6: optional rollback (GREEN -> BLUE) ==")
    router.set_active("blue")
    vs_active = router.route(blue_vs, green_vs)
    print(f"active_route={router.active.upper()} | query={query}")
    print_answer(router.active, top_hit(vs_active, query))


if __name__ == "__main__":
    main()
