from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from .config import OPENAI_API_KEY

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Imagine an e-commerce support KB with overlapping articles
docs = [
    Document(page_content="Refunds: approved within 48h, paid within 5 business days.", metadata={"doc_id": "kb:refunds:1"}),
    Document(page_content="Refund timeline: approval in 2 days, payout in up to 5 business days.", metadata={"doc_id": "kb:refunds:2"}),
    Document(page_content="Chargebacks are handled by your bank and can take 2–8 weeks.", metadata={"doc_id": "kb:chargebacks"}),
    Document(page_content="Returns: 30-day return window; refunds after item inspection.", metadata={"doc_id": "kb:returns"}),
    Document(page_content="Billing: how to update payment methods and invoices.", metadata={"doc_id": "kb:billing"}),
]

store = InMemoryVectorStore(embeddings)
store.add_documents(docs)

query = "How long does it take to get my money back?"

sim = store.as_retriever(search_type="similarity", search_kwargs={"k": 3})
mmr = store.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 3,          # final results returned
        "fetch_k": 10,   # candidates considered for diversification
        "lambda_mult": 0.3,
    },
)

print("=== similarity ===")
for d in sim.invoke(query):
    print(d.metadata["doc_id"], "->", d.page_content)

print("\n=== mmr ===")
for d in mmr.invoke(query):
    print(d.metadata["doc_id"], "->", d.page_content)


