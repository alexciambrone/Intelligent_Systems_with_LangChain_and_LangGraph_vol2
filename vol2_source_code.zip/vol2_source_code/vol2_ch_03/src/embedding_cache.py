from __future__ import annotations

import hashlib
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Union, Callable

from langchain_core.embeddings import Embeddings
from langchain_core.embeddings.fake import DeterministicFakeEmbedding
from langchain_classic.embeddings import CacheBackedEmbeddings
from langchain_classic.storage import LocalFileStore


# -----------------------------
# Counting wrapper to prove calls
# -----------------------------
class CountingEmbeddings(Embeddings):
    """
    Counts:
      - how many times we call the backend
      - how many texts we asked it to embed
    """

    def __init__(self, inner: Embeddings):
        self.inner = inner
        self.doc_backend_calls = 0
        self.doc_texts = 0
        self.query_backend_calls = 0
        self.query_texts = 0

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        self.doc_backend_calls += 1
        self.doc_texts += len(texts)
        return self.inner.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        self.query_backend_calls += 1
        self.query_texts += 1
        return self.inner.embed_query(text)


# -----------------------------
# Helpers: SHA-256 + namespacing
# -----------------------------
def sha256_hex(data: Union[str, bytes]) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def make_namespaced_encoder(prefix: str) -> Callable[[Union[str, bytes]], str]:
    """
    langchain_classic constraint:
      - if you provide key_encoder, you must NOT provide namespace.
    So we implement namespacing by encoding (prefix + payload) ourselves.
    """

    def enc(key: Union[str, bytes]) -> str:
        if isinstance(key, bytes):
            key_str = key.decode("utf-8", errors="replace")
        else:
            key_str = key
        # Prefix is part of the hashed input => separate cache domains safely.
        return sha256_hex(f"{prefix}::{key_str}")

    return enc


# -----------------------------
# Manual query cache (version-proof)
# -----------------------------
class QueryCacheWrapper(Embeddings):
    """
    Wraps an embedder and caches ONLY embed_query() results in the given store.
    This avoids version-dependent behavior around query caching.
    """

    def __init__(
        self,
        inner: Embeddings,
        store: LocalFileStore,
        query_prefix: str,
    ):
        self.inner = inner
        self.store = store
        self.query_prefix = query_prefix

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return self.inner.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        key = sha256_hex(f"{self.query_prefix}::query::{text}")

        cached_bytes: Optional[bytes] = self.store.mget([key])[0]
        if cached_bytes is not None:
            s = cached_bytes.decode("utf-8")
            return [float(x) for x in s.split(",")] if s else []

        vec = self.inner.embed_query(text)
        payload = ",".join(f"{x:.10g}" for x in vec).encode("utf-8")
        self.store.mset([(key, payload)])
        return vec


# -----------------------------
# Run accounting (effective calls + cache hits)
# -----------------------------
@dataclass(frozen=True)
class CounterSnap:
    doc_backend_calls: int
    doc_texts: int
    query_backend_calls: int
    query_texts: int


def snap(c: CountingEmbeddings) -> CounterSnap:
    return CounterSnap(
        doc_backend_calls=c.doc_backend_calls,
        doc_texts=c.doc_texts,
        query_backend_calls=c.query_backend_calls,
        query_texts=c.query_texts,
    )


def diff(a: CounterSnap, b: CounterSnap) -> CounterSnap:
    return CounterSnap(
        doc_backend_calls=b.doc_backend_calls - a.doc_backend_calls,
        doc_texts=b.doc_texts - a.doc_texts,
        query_backend_calls=b.query_backend_calls - a.query_backend_calls,
        query_texts=b.query_texts - a.query_texts,
    )


def print_effective(
    title: str,
    *,
    requested_doc_texts: int,
    requested_query_texts: int,
    delta: CounterSnap,
) -> None:
    doc_hits = max(0, requested_doc_texts - delta.doc_texts)
    query_hits = max(0, requested_query_texts - delta.query_texts)

    print(title)
    print("  requested doc texts:        ", requested_doc_texts)
    print("  effective backend doc calls:", delta.doc_backend_calls)
    print("  effective backend doc texts:", delta.doc_texts)
    print("  effective doc cache hits:   ", doc_hits)

    print("  requested query texts:      ", requested_query_texts)
    print("  effective backend query calls:", delta.query_backend_calls)
    print("  effective backend query texts:", delta.query_texts)
    print("  effective query cache hits: ", query_hits)

# -----------------------------
# Diagnostics / assertions
# -----------------------------
def max_abs_diff(a: List[float], b: List[float]) -> float:
    if len(a) != len(b):
        raise AssertionError(f"Vector lengths differ: {len(a)} vs {len(b)}")
    if not a:
        return 0.0
    m = 0.0
    for x, y in zip(a, b):
        d = abs(x - y)
        if d > m:
            m = d
    return m


def assert_vec_close(a: List[float], b: List[float], tol: float = 1e-8) -> None:
    d = max_abs_diff(a, b)
    if d > tol:
        raise AssertionError(f"Vectors differ more than tol={tol}: max_abs_diff={d}")


if __name__ == "__main__":
    cache_dir = Path("./cache/embeddings_demo")
    shutil.rmtree(cache_dir, ignore_errors=True)
    cache_dir.mkdir(parents=True, exist_ok=True)

    store = LocalFileStore(str(cache_dir))

    underlying = CountingEmbeddings(DeterministicFakeEmbedding(size=64))
    identity = "deterministic_fake_v1_size64"

    doc_key_encoder = make_namespaced_encoder(f"{identity}::doc")

    doc_cached = CacheBackedEmbeddings.from_bytes_store(
        underlying_embeddings=underlying,
        document_embedding_cache=store,
        key_encoder=doc_key_encoder,
    )

    cached = QueryCacheWrapper(inner=doc_cached, store=store, query_prefix=f"{identity}")

    texts = ["refund policy", "track order", "refund policy"]
    query = "refund policy"

    # RUN 1 (cold cache)
    before = snap(underlying)
    doc_vecs_1 = cached.embed_documents(texts)
    q_vec_1 = cached.embed_query(query)
    after = snap(underlying)

    print_effective(
        "RUN 1 (cold cache)",
        requested_doc_texts=len(texts),
        requested_query_texts=1,
        delta=diff(before, after),
    )

    # RUN 2 (warm cache, same inputs)
    before = snap(underlying)
    doc_vecs_2 = cached.embed_documents(texts)
    q_vec_2 = cached.embed_query(query)
    after = snap(underlying)

    print()
    print_effective(
        "RUN 2 (warm cache, same inputs)",
        requested_doc_texts=len(texts),
        requested_query_texts=1,
        delta=diff(before, after),
    )

    assert doc_vecs_1 == doc_vecs_2
    assert_vec_close(q_vec_1, q_vec_2, tol=1e-8)

    # RUN 3 (partial miss)
    new_texts = ["refund policy", "track order", "cancel order"]
    new_query = "cancel order"

    before = snap(underlying)
    _ = cached.embed_documents(new_texts)
    _ = cached.embed_query(new_query)
    after = snap(underlying)

    print()
    print_effective(
        "RUN 3 (partial miss: new doc + new query)",
        requested_doc_texts=len(new_texts),
        requested_query_texts=1,
        delta=diff(before, after),
    )

    print("\nOK: effective backend calls and cache hits are measured per run.")
