from langchain_core.caches import InMemoryCache
from langchain_core.globals import set_llm_cache
from langchain_core.language_models.fake_chat_models import FakeListChatModel

# Enable a global in-memory cache for LLM calls.
# The cache key is based on:
# - the prompt
# - the model configuration string used by LangChain
set_llm_cache(InMemoryCache())

prompt = "Summarize the return policy in one sentence."

# This fake model has two possible responses.
# Without caching, the second call would move to the second response.
# With caching, the second call should return the cached first response.
deterministic_llm = FakeListChatModel(
    responses=[
        "DET call 1: Refunds are available within 30 days.",
        "DET call 2: This should not appear if the cache is used.",
    ]
)

print(deterministic_llm.invoke(prompt).content)  # computed, then cached
print(deterministic_llm.invoke(prompt).content)  # cache hit: returns call 1 again

# This is a different model configuration because the fake responses differ.
# Therefore it should use a different cache entry.
creative_llm = FakeListChatModel(
    responses=[
        "CREATIVE call 1: You have 30 days to ask for your money back.",
        "CREATIVE call 2: This should not appear if the cache is used.",
    ]
)

print(creative_llm.invoke(prompt).content)  # computed separately, then cached
print(creative_llm.invoke(prompt).content)  # cache hit: returns creative call 1 again


