from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Optional

from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore


# -----
# Control-plane records (small, explicit, stable)
# -----

@dataclass(frozen=True)
class CorpusVersion:
    version: str                # "v1", "v2", ...
    collection_name: str        # physical backing collection/index name
    embedding_model: str        # identifier you can audit later
    chunking_fingerprint: str   # stable hash of chunking config
    status: str                 # "building" | "ready" | "deprecated"


@dataclass(frozen=True)
class CorpusManifest:
    active_version: str
    versions: Dict[str, CorpusVersion]  # version -> details


def corpus_ns(assistant_name: str, tenant_id: str) -> tuple[str, ...]:
    # Namespaced by assistant + tenant so every component reads the same truth.
    return ("corpora", assistant_name, tenant_id)


def load_manifest(store: BaseStore, assistant_name: str, tenant_id: str) -> Optional[CorpusManifest]:
    item = store.get(corpus_ns(assistant_name, tenant_id), "manifest")
    if item is None:
        return None
    raw = item.value
    versions = {k: CorpusVersion(**v) for k, v in raw["versions"].items()}
    return CorpusManifest(active_version=raw["active_version"], versions=versions)


def save_manifest(store: BaseStore, assistant_name: str, tenant_id: str, manifest: CorpusManifest) -> None:
    raw = {
        "active_version": manifest.active_version,
        "versions": {k: asdict(v) for k, v in manifest.versions.items()},
    }
    store.put(corpus_ns(assistant_name, tenant_id), "manifest", raw)


def set_active_version(store: BaseStore, assistant_name: str, tenant_id: str, new_version: str) -> None:
    manifest = load_manifest(store, assistant_name, tenant_id)
    if manifest is None:
        raise ValueError("No manifest found; cannot switch versions.")
    if new_version not in manifest.versions:
        raise ValueError(f"Unknown version: {new_version}")

    target = manifest.versions[new_version]
    if target.status != "ready":
        raise ValueError(f"Version {new_version} is not ready (status={target.status}).")

    save_manifest(
        store,
        assistant_name,
        tenant_id,
        CorpusManifest(active_version=new_version, versions=manifest.versions),
    )


def active_collection_name(store: BaseStore, assistant_name: str, tenant_id: str) -> str:
    manifest = load_manifest(store, assistant_name, tenant_id)
    if manifest is None:
        raise ValueError("No manifest found; cannot resolve active corpus.")
    return manifest.versions[manifest.active_version].collection_name


# -----
# Demo: two versions, one pointer, safe cutover
# -----
if __name__ == "__main__":
    store = InMemoryStore()

    assistant = "support_assistant"
    tenant = "acme"

    v1 = CorpusVersion(
        version="v1",
        collection_name="support_kb_v1",
        embedding_model="text-embedding-3-small",
        chunking_fingerprint="chunk_v1_9f3c",
        status="ready",
    )
    v2 = CorpusVersion(
        version="v2",
        collection_name="support_kb_v2",
        embedding_model="text-embedding-3-small",
        chunking_fingerprint="chunk_v2_21ad",
        status="building",  # not cutover-safe yet
    )

    save_manifest(
        store,
        assistant,
        tenant,
        CorpusManifest(active_version="v1", versions={"v1": v1, "v2": v2}),
    )

    print("Active collection:", active_collection_name(store, assistant, tenant))

    # This will fail because v2 is not ready
    try:
        set_active_version(store, assistant, tenant, "v2")
    except ValueError as e:
        print("Cutover blocked:", e)

    # Mark v2 ready, then cut over
    manifest = load_manifest(store, assistant, tenant)
    assert manifest is not None
    v2_ready = CorpusVersion(**{**asdict(manifest.versions["v2"]), "status": "ready"})
    save_manifest(
        store,
        assistant,
        tenant,
        CorpusManifest(
            active_version=manifest.active_version,
            versions={**manifest.versions, "v2": v2_ready},
        ),
    )

    set_active_version(store, assistant, tenant, "v2")
    print("Active collection after cutover:", active_collection_name(store, assistant, tenant))


