from pathlib import Path
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from .config import OPENAI_API_KEY

persist_dir = "./.cache/chroma_filters_demo"
Path(persist_dir).mkdir(parents=True, exist_ok=True)

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

docs = [
    # Tenant A, English
    Document(
        page_content="Return window: 30 days from delivery date.",
        metadata={"tenant_id": "tenant_a", "locale": "en", "doc_id": "kb:returns:en"},
    ),
    Document(
        page_content="Refunds: approved within 48 hours, then paid within 5 business days.",
        metadata={"tenant_id": "tenant_a", "locale": "en", "doc_id": "kb:refunds:en"},
    ),
    # Tenant A, Italian
    Document(
        page_content="Politica resi: 30 giorni dalla consegna.",
        metadata={"tenant_id": "tenant_a", "locale": "it", "doc_id": "kb:returns:it"},
    ),
    # Tenant B, English (should never be visible to tenant A)
    Document(
        page_content="Tenant B refund policy: payout within 10 business days.",
        metadata={"tenant_id": "tenant_b", "locale": "en", "doc_id": "kb:refunds:tenant_b"},
    ),
]

store = Chroma(
    collection_name="support_kb",
    embedding_function=embeddings,
    persist_directory=persist_dir,
)

store.add_documents(docs)

# Hard boundary + product behavior slice (example: tenant + locale)
tenant_a_en = store.as_retriever(
    search_type="similarity",
    search_kwargs={
        "k": 3,
        "filter": {"$and": [{"tenant_id": "tenant_a"}, {"locale": "en"}]},
    },
)

query = "How long does a refund take?"
hits = tenant_a_en.invoke(query)

for d in hits:
    print(d.metadata["doc_id"], d.metadata["tenant_id"], d.metadata["locale"], "->", d.page_content)


