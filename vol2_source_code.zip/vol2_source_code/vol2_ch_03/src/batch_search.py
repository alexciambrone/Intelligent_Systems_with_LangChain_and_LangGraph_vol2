from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import List, Tuple, Optional

# A batch-friendly "backend" (replace with your real embedder/LLM batch call).
# This one is deterministic and runs locally.
from langchain_core.embeddings.fake import DeterministicFakeEmbedding


@dataclass
class Request:
    text: str
    fut: asyncio.Future


class MicroBatcher:
    """
    Collect requests for up to `max_wait_ms` or until `max_batch_size`,
    then send them to the backend in one batch call.
    """

    def __init__(
        self,
        *,
        backend: DeterministicFakeEmbedding,
        max_batch_size: int = 32,
        max_wait_ms: int = 10,
    ):
        self.backend = backend
        self.max_batch_size = max_batch_size
        self.max_wait_ms = max_wait_ms
        self.q: asyncio.Queue[Request] = asyncio.Queue()
        self._task: Optional[asyncio.Task] = None
        self._stopping = asyncio.Event()

    async def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stopping.set()
        if self._task is not None:
            await self._task

    async def submit(self, text: str) -> List[float]:
        """
        Called by your "edge" (HTTP handler / queue consumer / worker).
        Each call is single-request from the app's perspective.
        """
        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        await self.q.put(Request(text=text, fut=fut))
        return await fut

    async def _run(self) -> None:
        """
        Background loop that forms micro-batches.
        """
        while not self._stopping.is_set():
            try:
                # Wait for the first item (blocks until at least one arrives).
                first = await asyncio.wait_for(self.q.get(), timeout=0.05)
            except asyncio.TimeoutError:
                continue

            batch: List[Request] = [first]
            deadline = time.perf_counter() + (self.max_wait_ms / 1000.0)

            # Keep collecting until we hit max batch size or the wait window expires.
            while len(batch) < self.max_batch_size:
                remaining = deadline - time.perf_counter()
                if remaining <= 0:
                    break
                try:
                    req = await asyncio.wait_for(self.q.get(), timeout=remaining)
                    batch.append(req)
                except asyncio.TimeoutError:
                    break

            texts = [r.text for r in batch]

            # True batch call: one backend invocation for N requests.
            # Replace this with your real provider batch API if available.
            vectors = self.backend.embed_documents(texts)

            # Route results back to each caller.
            for r, v in zip(batch, vectors):
                if not r.fut.cancelled():
                    r.fut.set_result(v)


async def simulate_clients(batcher: MicroBatcher) -> None:
    """
    Simulates many user requests arriving close together, like real traffic.
    """
    texts = [
        "refund policy",
        "where is my order",
        "invoice missing",
        "cancel order",
        "track my package",
        "return label",
        "refund status",
        "change delivery address",
    ]

    async def one_request(i: int, t: str) -> Tuple[int, float]:
        start = time.perf_counter()
        _vec = await batcher.submit(t)
        return i, (time.perf_counter() - start) * 1000.0

    # Burst: many requests arrive within a few milliseconds.
    tasks = []
    for i in range(50):
        t = texts[i % len(texts)]
        tasks.append(asyncio.create_task(one_request(i, t)))
        await asyncio.sleep(0.001)  # 1ms between arrivals (tight burst)

    results = await asyncio.gather(*tasks)

    latencies = [ms for _, ms in results]
    latencies.sort()
    p50 = latencies[int(0.50 * (len(latencies) - 1))]
    p95 = latencies[int(0.95 * (len(latencies) - 1))]
    p99 = latencies[int(0.99 * (len(latencies) - 1))]

    print(f"Requests: {len(latencies)}")
    print(f"Latency ms: p50={p50:.2f}, p95={p95:.2f}, p99={p99:.2f}")
    print(
        "Note: with a real remote backend, batching reduces repeated per-request overhead "
        "(network + scheduling). Here we only demonstrate the control flow."
    )


async def main() -> None:
    backend = DeterministicFakeEmbedding(size=256)

    # Micro-batching knobs:
    # - max_wait_ms caps the delay added to any single request (latency safety).
    # - max_batch_size caps the batch size (memory + backend constraints).
    batcher = MicroBatcher(backend=backend, max_batch_size=16, max_wait_ms=8)

    await batcher.start()
    try:
        await simulate_clients(batcher)
    finally:
        await batcher.stop()


if __name__ == "__main__":
    asyncio.run(main())
