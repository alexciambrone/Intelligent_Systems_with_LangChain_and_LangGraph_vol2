from __future__ import annotations
import os
from pathlib import Path
from typing import List
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from .config import OPENAI_API_KEY

def ensure_sample_data(folder: Path) -> None:
    """Creates a tiny support-KB corpus so the script is runnable end-to-end."""
    folder.mkdir(parents=True, exist_ok=True)
    samples = {
        "refunds.txt": (
            "Refund policy:\n"
            "You can request a refund within 30 days of delivery.\n"
            "Refunds are issued to the original payment method within 5–10 business days.\n"
        ),
        "shipping.txt": (
            "Shipping and tracking:\n"
            "Orders ship within 24 hours on business days.\n"
            "Tracking links appear in your account under Orders.\n"
        ),
        "invoices.txt": (
            "Invoices:\n"
            "Invoices are available as PDFs in your account.\n"
            "If an invoice is missing, contact support with your order ID.\n"
        ),
    }

    for name, content in samples.items():
        p = folder / name
        if not p.exists():
            p.write_text(content, encoding="utf-8")


def ingest_stream_batch(
    *,
    source_folder: Path,
    persist_dir: Path,
    collection_name: str = "support_kb",
    chunk_size: int = 500,
    chunk_overlap: int = 80,
    upsert_batch_chunks: int = 64,
) -> Chroma:
    """
    Stream + batch ingestion:
    - Stream documents one-by-one (lazy_load).
    - Split immediately.
    - Accumulate only 'upsert_batch_chunks' chunks.
    - Embed + upsert that batch, then discard it.
    """

    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

    vector_store = Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=str(persist_dir),
    )

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    loader = DirectoryLoader(
        path=str(source_folder),
        glob="**/*.txt",
        loader_cls=TextLoader,
        show_progress=True,
        use_multithreading=True,
        max_concurrency=4,
    )

    pending: List = []

    for doc in loader.lazy_load():  # streams: never loads the whole corpus
        chunks = splitter.split_documents([doc])
        pending.extend(chunks)

        if len(pending) >= upsert_batch_chunks:
            vector_store.add_documents(pending)  # embed + upsert
            pending.clear()  # discard batch => predictable memory

    if pending:
        vector_store.add_documents(pending)
        pending.clear()

    return vector_store


if __name__ == "__main__":
    """
    Install deps (typical):
      pip install -U langchain langchain-community langchain-text-splitters langchain-openai langchain-chroma chromadb
    """

    data_dir = Path("data") / "support_kb"
    ensure_sample_data(data_dir)

    db_dir = Path("chroma_db")
    store = ingest_stream_batch(source_folder=data_dir, persist_dir=db_dir)

    # Quick sanity check: query the persisted vector store
    hits = store.similarity_search("How do I get a refund?", k=3)
    for i, d in enumerate(hits, 1):
        print(f"\n--- hit {i} ---")
        print("source:", d.metadata.get("source"))
        print(d.page_content.strip())
