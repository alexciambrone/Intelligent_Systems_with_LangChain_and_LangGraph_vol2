from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from .config import OPENAI_API_KEY

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

docs = [
    Document(
        page_content="Refund policy: refunds are approved within 48 hours, then paid within 5 business days.",
        metadata={"doc_id": "kb:refunds", "locale": "en"},
    ),
    Document(
        page_content="Shipping policy: delivery in 2–5 business days depending on destination.",
        metadata={"doc_id": "kb:shipping", "locale": "en"},
    ),
    Document(
        page_content="Return window: 30 days from delivery date with proof of purchase.",
        metadata={"doc_id": "kb:returns", "locale": "en"},
    ),
]

store = InMemoryVectorStore(embeddings)
store.add_documents(docs)

retriever = store.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 2},
)

query = "How long does a refund take after approval?"
hits = retriever.invoke(query)

for d in hits:
    print(d.metadata["doc_id"], "->", d.page_content)
