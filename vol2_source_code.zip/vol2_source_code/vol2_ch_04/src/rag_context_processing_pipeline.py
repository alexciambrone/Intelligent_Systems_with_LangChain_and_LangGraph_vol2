from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Sequence
import hashlib
import math

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import InMemoryVectorStore

from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors import DocumentCompressorPipeline
from langchain_community.document_transformers import (
    EmbeddingsRedundantFilter,
    EmbeddingsClusteringFilter,
    LongContextReorder,
)
from langchain_classic.retrievers.document_compressors import EmbeddingsFilter
from .config import OPENAI_API_KEY

# ------------------------------------------------------------
# Deterministic embeddings for demos/tests (no external API)
# ------------------------------------------------------------
class DeterministicEmbeddings(Embeddings):
    """
    A tiny deterministic embeddings implementation for runnable examples.

    It is NOT a good embedding model. It exists so that:
      - retrieval code runs without network keys,
      - results are stable across runs.
    """

    def __init__(self, dim: int = 64) -> None:
        self.dim = dim

    def _hash_to_vec(self, text: str) -> List[float]:
        # Hash -> pseudo-random but stable vector.
        h = hashlib.sha256(text.encode("utf-8")).digest()
        # Expand hash bytes into dim floats in [-1, 1].
        out: List[float] = []
        for i in range(self.dim):
            b = h[i % len(h)]
            out.append((b / 255.0) * 2.0 - 1.0)
        # L2-normalize for cosine-like behavior.
        norm = math.sqrt(sum(x * x for x in out)) or 1.0
        return [x / norm for x in out]

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self._hash_to_vec(t) for t in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._hash_to_vec(text)


# ------------------------------------------------------------
# Demo corpus with deliberate duplicates/near-duplicates
# ------------------------------------------------------------
def build_support_docs() -> List[Document]:
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "source_id": "rp-1"},
        ),
        # Exact duplicate (different id): common in real corpora.
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "source_id": "rp-1-dup"},
        ),
        # Near-duplicate paraphrase: also common.
        Document(
            page_content=(
                "After we receive and inspect your return, we process the refund to the "
                "original payment method within 5 business days."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "source_id": "rp-1-paraphrase"},
        ),
        Document(
            page_content=(
                "Items can be returned within 30 days of delivery if they are unused and in "
                "their original packaging. Perishable goods are not returnable."
            ),
            metadata={"source": "refund_policy", "section": "eligibility", "source_id": "rp-2"},
        ),
        Document(
            page_content=(
                "If your order shows as delivered but you did not receive it, contact support "
                "within 7 days so we can open an investigation with the carrier."
            ),
            metadata={"source": "shipping_policy", "section": "delivery_issues", "source_id": "sp-1"},
        ),
        # Some topical noise that tends to be retrieved for “refund”-ish queries:
        Document(
            page_content=(
                "Shipping fees are not refundable unless the return is due to our error."
            ),
            metadata={"source": "refund_policy", "section": "fees", "source_id": "rp-3"},
        ),
    ]


# ------------------------------------------------------------
# Build base retriever (recall) + compression retriever (precision)
# ------------------------------------------------------------
def build_vectorstore(embeddings: Embeddings) -> InMemoryVectorStore:
    vs = InMemoryVectorStore(embedding=embeddings)
    vs.add_documents(build_support_docs())
    return vs


def build_compression_retriever(base_retriever: Any, embeddings: Embeddings) -> ContextualCompressionRetriever:
    # 1) Remove semantic duplicates among retrieved candidates.
    redundant = EmbeddingsRedundantFilter(
        embeddings=embeddings,
        similarity_threshold=0.95,
    )

    # 2) Keep only the top-N most relevant chunks to the query.
    relevant = EmbeddingsFilter(
        embeddings=embeddings,
        k=4,
        # Optional: similarity_threshold=0.6
    )

    # 3) Reorder survivors to reduce long-context attention issues.
    reorder = LongContextReorder()

    compressor = DocumentCompressorPipeline(
        transformers=[redundant, relevant, reorder]
    )

    return ContextualCompressionRetriever(
        base_retriever=base_retriever,
        base_compressor=compressor,
    )


def format_evidence_pack(docs: Sequence[Document]) -> str:
    # Minimal structured evidence: stable ids + short metadata + text.
    lines: List[str] = []
    for i, d in enumerate(docs, start=1):
        md = d.metadata or {}
        src = md.get("source", "unknown")
        sec = md.get("section", "unknown")
        sid = md.get("source_id", "-")
        lines.append(f"[{i}] ({src} / {sec} / {sid})\n{d.page_content}")
    return "\n\n".join(lines)


def main() -> None:
    embeddings = DeterministicEmbeddings(dim=64)
    vs = build_vectorstore(embeddings)

    # Base retriever: tuned for recall. Notice k is intentionally higher.
    base_retriever = vs.as_retriever(search_kwargs={"k": 8})

    compression_retriever = build_compression_retriever(base_retriever, embeddings)

    query = "How long do refunds take after you receive my return?"

    base_hits = base_retriever.invoke(query)
    refined_hits = compression_retriever.invoke(query)

    print("\n=== Base retrieval (higher recall; may include duplicates/noise) ===")
    print(format_evidence_pack(base_hits))

    print("\n=== After context processing (deduped + filtered + reordered) ===")
    print(format_evidence_pack(refined_hits))


if __name__ == "__main__":
    main()


