from __future__ import annotations
import os
from typing import List
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from .config import OPENAI_API_KEY

def build_support_kb() -> List[Document]:
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines"},
        ),
        Document(
            page_content=(
                "Items can be returned within 30 days of delivery if they are unused and in "
                "their original packaging. Perishable goods are not returnable."
            ),
            metadata={"source": "refund_policy", "section": "eligibility"},
        ),
        Document(
            page_content=(
                "Shipping fees are not refundable unless the return is due to our error."
            ),
            metadata={"source": "refund_policy", "section": "fees"},
        ),
    ]


def format_docs(docs: List[Document]) -> str:
    return "\n\n".join(d.page_content for d in docs)


def main() -> None:
    docs = build_support_kb()

    vectordb = Chroma.from_documents(
        documents=docs,
        embedding=OpenAIEmbeddings(),
        collection_name="support_kb_query_rewrite"
    )
    base_retriever = vectordb.as_retriever(search_kwargs={"k": 3})

    rewrite_prompt = ChatPromptTemplate.from_template(
        """Rewrite the user question into a short, retrieval-focused search query.
Keep the meaning identical. Do not answer the question.

User question: {question}
Search query:"""
    )
    llm = ChatOpenAI(temperature=0)

    rewrite_chain = rewrite_prompt | llm | StrOutputParser()

    def retrieve_with_rewrite(question: str) -> List[Document]:
        rewritten = rewrite_chain.invoke({"question": question})

        # --- Added prints (original + expanded/rewritten query) ---
        print(f"Original query: {question}")
        print(f"Expanded query: {rewritten}")
        # ---------------------------------------------------------

        return base_retriever.invoke(rewritten)

    prompt = ChatPromptTemplate.from_template(
        """You are a support assistant.
Answer using only the provided context.
If the context does not contain the answer, say "I don't know."

Context:
{context}

Question:
{question}
"""
    )

    rag_chain = (
        {
            "context": RunnableLambda(retrieve_with_rewrite) | format_docs,
            "question": RunnablePassthrough(),
        }
        | prompt
        | llm
        | StrOutputParser()
    )

    print(rag_chain.invoke("refund timeline after return"))


if __name__ == "__main__":
    main()