from __future__ import annotations
from typing import List
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors.listwise_rerank import LLMListwiseRerank
from .config import OPENAI_API_KEY

def build_policy_docs() -> List[Document]:
    return [
        Document(
            page_content="Refunds are issued within 5 business days after the returned item is received and inspected.",
            metadata={"id": "rp-1"},
        ),
        Document(
            page_content="Inspection may take up to 2 business days during peak season.",
            metadata={"id": "rp-5"},
        ),
        Document(
            page_content="Shipping fees are not refundable unless the return is due to our error.",
            metadata={"id": "rp-3"},
        ),
        Document(
            page_content="Items can be returned within 30 days if unused and in original packaging.",
            metadata={"id": "rp-2"},
        ),
    ]


def main() -> None:
    docs = build_policy_docs()

    vs = InMemoryVectorStore(embedding=OpenAIEmbeddings())
    vs.add_documents(docs)

    base_retriever = vs.as_retriever(search_kwargs={"k": 4})  # small k-in on purpose

    # A deterministic, structured-output-capable model is important here.
    llm = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0
    )

    # Keep top_n small: LLM reranking cost grows with (candidates × passage length).
    reranker = LLMListwiseRerank.from_llm(llm=llm, top_n=2)
    rerank_retriever = ContextualCompressionRetriever(
        base_retriever=base_retriever,
        base_compressor=reranker,
    )

    query = "My refund seems late. What timelines apply after you receive and inspect the return?"
    hits = rerank_retriever.invoke(query)

    print("\n=== After LLM listwise rerank ===")
    for i, d in enumerate(hits, start=1):
        print(f"[{i}] {d.metadata.get('id')}: {d.page_content}")


if __name__ == "__main__":
    main()
