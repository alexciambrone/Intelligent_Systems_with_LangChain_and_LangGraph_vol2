# src/text_trace.py
from __future__ import annotations

import json
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class TraceEvent:
    ts: str
    request_id: str
    step: str
    kind: str
    data: Dict[str, Any]
    duration_ms: Optional[float] = None


class JsonlTracer:
    """
    Fast JSONL tracer:
    - Opens the file once (line-buffered) instead of re-opening per event
    - Emits structured events compatible with your existing trace output
    """

    def __init__(self, trace_path: Path, request_id: Optional[str] = None) -> None:
        self.trace_path = trace_path
        self.trace_path.parent.mkdir(parents=True, exist_ok=True)
        self.request_id = request_id or str(uuid.uuid4())
        self._f = self.trace_path.open("a", encoding="utf-8", buffering=1)  # line-buffered

    def close(self) -> None:
        try:
            self._f.close()
        except Exception:
            pass

    def emit(self, step: str, kind: str, duration_ms: Optional[float] = None, **data: Any) -> None:
        ev = TraceEvent(
            ts=_now_iso(),
            request_id=self.request_id,
            step=step,
            kind=kind,
            data=data,
            duration_ms=duration_ms,
        )
        self._f.write(json.dumps(asdict(ev), ensure_ascii=False) + "\n")

    @contextmanager
    def span(self, step: str, **start_data: Any) -> Iterator[None]:
        t0 = time.perf_counter()
        self.emit(step, "start", **start_data)
        try:
            yield
        finally:
            dt_ms = (time.perf_counter() - t0) * 1000.0
            self.emit(step, "end", duration_ms=dt_ms)