from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal, Optional, Sequence, Tuple, TypedDict

from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY

# -----------------------------
# Support KB (small on purpose)
# -----------------------------
def build_support_docs() -> List[Document]:
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "id": "rp-1", "version": "2025-10"},
        ),
        Document(
            page_content=(
                "Refunds are issued within 10 business days after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "id": "rp-OLD", "version": "2024-02"},
        ),
        Document(
            page_content="Inspection may take up to 2 business days during peak season.",
            metadata={"source": "refund_policy", "section": "timelines", "id": "rp-5", "version": "2025-10"},
        ),
        Document(
            page_content=(
                "Items can be returned within 30 days of delivery if they are unused and in "
                "their original packaging. Perishable goods are not returnable."
            ),
            metadata={"source": "refund_policy", "section": "eligibility", "id": "rp-2", "version": "2025-10"},
        ),
        Document(
            page_content="Shipping fees are not refundable unless the return is due to our error.",
            metadata={"source": "refund_policy", "section": "fees", "id": "rp-3", "version": "2025-10"},
        ),
        Document(
            page_content=(
                "Price adjustments are available within 7 days of delivery if the item price drops on our store."
            ),
            metadata={"source": "pricing_policy", "section": "price_adjustments", "id": "pp-1", "version": "2025-08"},
        ),
        Document(
            page_content=(
                "This article discusses store locations and opening hours. It does not describe refunds or pricing."
            ),
            metadata={"source": "help_center", "section": "stores", "id": "hc-9", "version": "2025-01"},
        ),
    ]


def format_evidence(docs: Sequence[Document]) -> str:
    blocks: List[str] = []
    for i, d in enumerate(docs, start=1):
        md = d.metadata or {}
        blocks.append(
            f"[{i}] ({md.get('source')}/{md.get('section')}/{md.get('id')}; v={md.get('version')})\n{d.page_content}"
        )
    return "\n\n".join(blocks)


# -----------------------------
# Structured outputs for gates
# -----------------------------
class EvidenceDecision(TypedDict):
    action: Literal["proceed", "rewrite", "abstain"]
    rationale: str
    suggested_query: Optional[str]
    missing_parameters: Optional[List[str]]


class AnswerDecision(TypedDict):
    action: Literal["approve", "revise", "abstain"]
    rationale: str


# -----------------------------
# Graph state
# -----------------------------
class CRAGState(TypedDict):
    question: str
    query: str
    evidence: List[Document]

    evidence_action: Literal["proceed", "rewrite", "abstain"]
    answer_action: Literal["approve", "revise", "abstain"]

    evidence_decision: Optional[EvidenceDecision]
    answer_decision: Optional[AnswerDecision]
    trace: List[str]

    draft: str
    final: str

    retrieval_attempts: int
    revision_attempts: int


MAX_RETRIEVAL_REWRITES = 2
MAX_ANSWER_REVISIONS = 1


# -----------------------------
# Retrieval
# -----------------------------
def build_retriever() -> any:
    vectordb = Chroma.from_documents(
        documents=build_support_docs(),
        embedding=OpenAIEmbeddings(),
        collection_name="support_kb_corrective_v4",
    )
    return vectordb.as_retriever(search_kwargs={"k": 4})


retriever = build_retriever()

grader_llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0)
answer_llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0)


# -----------------------------
# Version + conflict resolution helpers
# -----------------------------
def parse_version(v: Optional[str]) -> Optional[Tuple[int, int]]:
    """
    Expect 'YYYY-MM'. Returns (YYYY, MM) or None if unparseable.
    """
    if not v:
        return None
    try:
        parts = v.split("-")
        if len(parts) != 2:
            return None
        y = int(parts[0])
        m = int(parts[1])
        if m < 1 or m > 12:
            return None
        return (y, m)
    except Exception:
        return None


def doc_key(doc: Document) -> Tuple[str, str, str]:
    md = doc.metadata or {}
    return (str(md.get("source", "")), str(md.get("section", "")), str(md.get("id", "")))


def resolve_policy_conflicts(docs: List[Document], trace: List[str]) -> List[Document]:
    """
    Strong opinionated rule:
    - If multiple docs belong to refund_policy/timelines AND contain conflicting 'Refunds are issued...' statements,
      keep only the newest version among those statements.
    - Keep other timeline docs (like inspection) even if same section.
    - If versions are missing/ambiguous, do NOT drop anything (leave conflict for the gate to handle).
    """
    refund_timeline_statements: List[Document] = []
    other_docs: List[Document] = []

    for d in docs:
        md = d.metadata or {}
        source = md.get("source")
        section = md.get("section")

        is_refund_timeline_statement = (
            source == "refund_policy"
            and section == "timelines"
            and isinstance(d.page_content, str)
            and d.page_content.strip().lower().startswith("refunds are issued")
        )

        if is_refund_timeline_statement:
            refund_timeline_statements.append(d)
        else:
            other_docs.append(d)

    if len(refund_timeline_statements) <= 1:
        return docs

    # Can we compare versions?
    parsed: List[Tuple[Tuple[int, int], Document]] = []
    for d in refund_timeline_statements:
        ver = parse_version((d.metadata or {}).get("version"))
        if ver is None:
            # Can't safely resolve; leave as-is.
            return docs
        parsed.append((ver, d))

    parsed.sort(key=lambda x: x[0])
    newest_ver, newest_doc = parsed[-1]
    dropped = [d for (_, d) in parsed[:-1]]

    kept_ids = [(d.metadata or {}).get("id") for d in [newest_doc]]
    dropped_ids = [(d.metadata or {}).get("id") for d in dropped]
    trace.append(
        "CONFLICT_RESOLUTION: refund timeline statements conflict detected; "
        f"kept newest v={newest_doc.metadata.get('version')} id={kept_ids[0]} ; "
        f"dropped older ids={dropped_ids}"
    )

    # Rebuild evidence: keep newest statement + all other docs
    return [newest_doc, *other_docs]


# -----------------------------
# Node: retrieve evidence
# -----------------------------
def retrieve_node(state: CRAGState) -> CRAGState:
    docs = retriever.invoke(state["query"])

    trace = list(state.get("trace", []))
    trace.append(f"RETRIEVE: query='{state['query']}' -> {len(docs)} docs")

    # Deterministic “conflict resolution” pass (before LLM gating)
    resolved = resolve_policy_conflicts(list(docs), trace)

    return {**state, "evidence": resolved, "trace": trace}


# -----------------------------
# Node: evidence gate
# -----------------------------
evidence_gate_prompt = ChatPromptTemplate.from_template(
    """You are grading whether the retrieved evidence is sufficient and safe to answer the user's question.

User question:
{question}

Retrieval query used:
{query}

Evidence:
{evidence}

Rules:
1) If the question needs user/system-specific data not present in evidence (e.g., order status, timestamps),
   choose action="abstain" and list missing_parameters.
2) If the evidence is insufficient but a better query could help, choose action="rewrite" and provide suggested_query.
3) If the evidence is sufficient, choose action="proceed".

Return JSON:
- action: "proceed" | "rewrite" | "abstain"
- rationale: short explanation
- suggested_query: if action="rewrite" else null
- missing_parameters: if action="abstain" due to missing inputs else null
"""
)

evidence_gate = grader_llm.with_structured_output(EvidenceDecision, method="json_schema", strict=True)


def grade_evidence_node(state: CRAGState) -> CRAGState:
    decision = evidence_gate.invoke(
        evidence_gate_prompt.format_messages(
            question=state["question"],
            query=state["query"],
            evidence=format_evidence(state["evidence"]),
        )
    )

    action = decision["action"]
    trace = list(state.get("trace", []))
    trace.append(
        "EVIDENCE_GATE: "
        f"action={action} | rationale={decision.get('rationale','')}"
        + (f" | suggested_query={decision.get('suggested_query')}" if decision.get("suggested_query") else "")
        + (f" | missing={decision.get('missing_parameters')}" if decision.get("missing_parameters") else "")
    )

    next_state: CRAGState = {
        **state,
        "evidence_action": action,
        "evidence_decision": decision,
        "trace": trace,
    }

    if action == "proceed":
        return next_state

    if action == "rewrite":
        # Budget enforcement (and TRACE made non-confusing)
        if state["retrieval_attempts"] >= MAX_RETRIEVAL_REWRITES:
            trace2 = list(next_state["trace"])
            trace2.append("REWRITE_BUDGET_EXHAUSTED: switching to abstain")
            abstain_decision: EvidenceDecision = {
                "action": "abstain",
                "rationale": "Rewrite budget exhausted; cannot retrieve sufficient/safe evidence.",
                "suggested_query": None,
                "missing_parameters": None,
            }
            return {
                **next_state,
                "evidence_action": "abstain",
                "evidence_decision": abstain_decision,
                "trace": trace2,
                "final": (
                    "I don't know based on the provided context. "
                    "The retrieved evidence was not sufficient or safe after retries."
                ),
            }

        suggested = decision.get("suggested_query") or state["query"]
        trace2 = list(next_state["trace"])
        trace2.append(f"RETRIEVAL_REWRITE: query='{state['query']}' -> '{suggested}'")

        return {
            **next_state,
            "query": suggested,
            "retrieval_attempts": state["retrieval_attempts"] + 1,
            "trace": trace2,
        }

    # action == "abstain"
    missing = decision.get("missing_parameters") or []
    if missing:
        return {
            **next_state,
            "final": (
                "I don't know based on the provided context. "
                f"To answer safely, I need: {', '.join(missing)}."
            ),
        }

    return {
        **next_state,
        "final": (
            "I don't know based on the provided context. "
            "The question is not answerable from the available evidence."
        ),
    }


def route_after_evidence_gate(state: CRAGState) -> Literal["retrieve", "generate", "end"]:
    if state.get("final"):
        return "end"
    if state["evidence_action"] == "rewrite":
        return "retrieve"
    return "generate"


# -----------------------------
# Node: generate grounded draft answer
# -----------------------------
answer_prompt = ChatPromptTemplate.from_template(
    """You are a support assistant.

Answer using ONLY the evidence below.
Cite the evidence for every factual claim using [1], [2], etc.
If you cannot answer from the evidence, output exactly:
"I don't know based on the provided context."

Evidence:
{evidence}

Question:
{question}
"""
)


def generate_node(state: CRAGState) -> CRAGState:
    trace = list(state.get("trace", []))
    trace.append("GENERATE: producing draft answer from current evidence pack")

    draft = (answer_prompt | answer_llm | StrOutputParser()).invoke(
        {"evidence": format_evidence(state["evidence"]), "question": state["question"]}
    )
    return {**state, "draft": draft, "trace": trace}


# -----------------------------
# Node: verify groundedness of draft
# -----------------------------
verify_prompt = ChatPromptTemplate.from_template(
    """You are verifying whether the draft answer is fully supported by the evidence.

Question:
{question}

Evidence:
{evidence}

Draft answer:
{draft}

Decide ONE action:
- approve: every factual claim is supported by evidence
- revise: the draft contains unsupported/overstated claims; it can be rewritten to only include supported claims
- abstain: evidence is insufficient to produce a grounded answer

Return JSON:
- action: "approve" | "revise" | "abstain"
- rationale: short explanation
"""
)

answer_gate = grader_llm.with_structured_output(AnswerDecision, method="json_schema", strict=True)


def verify_node(state: CRAGState) -> CRAGState:
    decision = answer_gate.invoke(
        verify_prompt.format_messages(
            question=state["question"],
            evidence=format_evidence(state["evidence"]),
            draft=state["draft"],
        )
    )

    action = decision["action"]
    trace = list(state.get("trace", []))
    trace.append(f"ANSWER_GATE: action={action} | rationale={decision.get('rationale','')}")

    next_state: CRAGState = {
        **state,
        "answer_action": action,
        "answer_decision": decision,
        "trace": trace,
    }

    if action == "approve":
        return {**next_state, "final": state["draft"]}

    if action == "abstain":
        return {
            **next_state,
            "final": (
                "I don't know based on the provided context. "
                "The evidence does not support a safe answer."
            ),
        }

    # action == "revise"
    if state["revision_attempts"] >= MAX_ANSWER_REVISIONS:
        trace2 = list(next_state["trace"])
        trace2.append("REVISION_BUDGET_EXHAUSTED: switching to abstain")
        return {
            **next_state,
            "trace": trace2,
            "final": (
                "I don't know based on the provided context. "
                "I could not produce a grounded answer within the revision budget."
            ),
        }

    trace2 = list(next_state["trace"])
    trace2.append(f"ANSWER_REVISION: attempt={state['revision_attempts'] + 1}/{MAX_ANSWER_REVISIONS}")

    return {
        **next_state,
        "revision_attempts": state["revision_attempts"] + 1,
        "trace": trace2,
    }


def route_after_verify(state: CRAGState) -> Literal["revise", "end"]:
    if state.get("final"):
        return "end"
    return "revise"


# -----------------------------
# Node: revise answer to only what is supported
# -----------------------------
revise_prompt = ChatPromptTemplate.from_template(
    """Rewrite the draft answer so it is fully supported by the evidence.

Rules:
- Use ONLY the evidence.
- Keep citations [1], [2], etc. for every factual claim.
- Remove any claim not explicitly supported.
- If you cannot produce a grounded answer, output exactly:
"I don't know based on the provided context."

Evidence:
{evidence}

Question:
{question}

Draft:
{draft}
"""
)


def revise_node(state: CRAGState) -> CRAGState:
    trace = list(state.get("trace", []))
    trace.append("REVISE: rewriting draft to remove unsupported claims")

    revised = (revise_prompt | answer_llm | StrOutputParser()).invoke(
        {
            "evidence": format_evidence(state["evidence"]),
            "question": state["question"],
            "draft": state["draft"],
        }
    )
    return {**state, "draft": revised, "trace": trace}


# -----------------------------
# Assemble graph
# -----------------------------
builder = StateGraph(CRAGState)
builder.add_node("retrieve", retrieve_node)
builder.add_node("grade_evidence", grade_evidence_node)
builder.add_node("generate", generate_node)
builder.add_node("verify", verify_node)
builder.add_node("revise", revise_node)

builder.add_edge(START, "retrieve")
builder.add_edge("retrieve", "grade_evidence")

builder.add_conditional_edges(
    "grade_evidence",
    route_after_evidence_gate,
    {"retrieve": "retrieve", "generate": "generate", "end": END},
)

builder.add_edge("generate", "verify")

builder.add_conditional_edges(
    "verify",
    route_after_verify,
    {"revise": "revise", "end": END},
)
builder.add_edge("revise", "verify")

graph = builder.compile()


def is_abstention(text: str) -> bool:
    t = (text or "").strip()
    return t.startswith("I don't know based on the provided context")


def run_question(question: str) -> None:
    state: CRAGState = {
        "question": question,
        "query": question,
        "evidence": [],
        "evidence_action": "proceed",
        "answer_action": "approve",
        "evidence_decision": None,
        "answer_decision": None,
        "trace": [],
        "draft": "",
        "final": "",
        "retrieval_attempts": 0,
        "revision_attempts": 0,
    }

    result = graph.invoke(state)

    print("\n" + "=" * 90)
    print("Q:", question)
    print("-" * 90)

    if result.get("trace"):
        print("TRACE:")
        for line in result["trace"]:
            print("  -", line)
        print("-" * 90)

    print(result["final"])

    if result.get("evidence"):
        print("\nEVIDENCE " + ("RETRIEVED (NOT USED TO ANSWER):" if is_abstention(result["final"]) else "USED:"))
        print(format_evidence(result["evidence"]))


if __name__ == "__main__":
    run_question("How long do refunds take after you receive my return?")
    run_question("Is my refund late? I returned it last week.")
    run_question("Do you offer price match after purchase?")