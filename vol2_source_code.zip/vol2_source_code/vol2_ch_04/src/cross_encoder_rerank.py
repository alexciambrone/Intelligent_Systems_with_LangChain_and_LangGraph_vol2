from __future__ import annotations

from typing import List

from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings

from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors.cross_encoder_rerank import CrossEncoderReranker

# Cross-encoder interface + a fake implementation for runnable demos
from langchain_community.cross_encoders import FakeCrossEncoder
# For real reranking, swap FakeCrossEncoder for HuggingFaceCrossEncoder:
# from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from .config import OPENAI_API_KEY


def build_support_policy_docs() -> List[Document]:
    # Intentionally includes close-but-not-answering chunks to show the reranker’s job.
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines", "id": "rp-1"},
        ),
        Document(
            page_content=(
                "Items can be returned within 30 days of delivery if unused and in original packaging. "
                "Perishable goods are not returnable."
            ),
            metadata={"source": "refund_policy", "section": "eligibility", "id": "rp-2"},
        ),
        Document(
            page_content=("Shipping fees are not refundable unless the return is due to our error."),
            metadata={"source": "refund_policy", "section": "fees", "id": "rp-3"},
        ),
        Document(
            page_content=(
                "A return is considered received when carrier tracking shows delivered to our returns center."
            ),
            metadata={"source": "refund_policy", "section": "definitions", "id": "rp-4"},
        ),
        Document(
            page_content=("Inspection may take up to 2 business days during peak season."),
            metadata={"source": "refund_policy", "section": "timelines", "id": "rp-5"},
        ),
    ]


def print_hits(title: str, hits: List[Document]) -> None:
    print(f"\n=== {title} (count={len(hits)}) ===")
    for i, d in enumerate(hits, start=1):
        md = d.metadata or {}
        print(f"[{i}] {md.get('id')} ({md.get('source')}/{md.get('section')})")
        print(d.page_content)


def main() -> None:
    docs = build_support_policy_docs()

    # Base retriever: tuned for recall.
    # We deliberately set k higher than what we plan to send to the answer prompt.
    embeddings = OpenAIEmbeddings()
    vs = InMemoryVectorStore(embedding=embeddings)
    vs.add_documents(docs)

    base_retriever = vs.as_retriever(search_kwargs={"k": 5})  # k-in

    # Cross-encoder reranker: tuned for precision, returns only top_n.
    # FakeCrossEncoder gives deterministic scores for demos/tests.
    cross_encoder = FakeCrossEncoder()
    reranker = CrossEncoderReranker(model=cross_encoder, top_n=2)  # n-out

    # For real reranking with a local model (downloads weights):
    # cross_encoder = HuggingFaceCrossEncoder(model_name="BAAI/bge-reranker-base")
    # reranker = CrossEncoderReranker(model=cross_encoder, top_n=2)

    rerank_retriever = ContextualCompressionRetriever(
        base_retriever=base_retriever,
        base_compressor=reranker,
    )

    query = "How long do refunds take after you receive my return?"
    base_hits = base_retriever.invoke(query)
    reranked_hits = rerank_retriever.invoke(query)

    print_hits("Base retrieval (k-in)", base_hits)
    print_hits("After cross-encoder rerank (n-out)", reranked_hits)


if __name__ == "__main__":
    main()


