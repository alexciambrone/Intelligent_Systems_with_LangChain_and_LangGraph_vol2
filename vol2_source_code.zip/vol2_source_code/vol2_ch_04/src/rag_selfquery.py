from __future__ import annotations

import os
from typing import List

from langchain_core.documents import Document
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_classic.retrievers.self_query.base import SelfQueryRetriever

from .config import OPENAI_API_KEY


def build_catalog_docs() -> List[Document]:
    return [
        Document(
            page_content="Acme SonicPods Pro: wireless noise-cancelling headphones with 30h battery.",
            metadata={
                "tenant_id": "shop_1",
                "category": "headphones",
                "brand": "Acme",
                "price_eur": 89.0,
            },
        ),
        Document(
            page_content="Acme StudioMax: wired over-ear headphones for studio monitoring.",
            metadata={
                "tenant_id": "shop_1",
                "category": "headphones",
                "brand": "Acme",
                "price_eur": 129.0,
            },
        ),
        Document(
            page_content="Borealis AirBeats: true wireless earbuds with charging case.",
            metadata={
                "tenant_id": "shop_1",
                "category": "earbuds",
                "brand": "Borealis",
                "price_eur": 79.0,
            },
        ),
        Document(
            page_content="OtherTenant QuietWave: wireless headphones (different tenant, should be filtered out).",
            metadata={
                "tenant_id": "shop_2",
                "category": "headphones",
                "brand": "OtherTenant",
                "price_eur": 49.0,
            },
        ),
    ]


def main() -> None:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("Set OPENAI_API_KEY to run this example.")

    docs = build_catalog_docs()

    vectordb = Chroma.from_documents(
        documents=docs,
        embedding=OpenAIEmbeddings(),
        collection_name="catalog_self_query",
    )

    document_content_description = "a product listing from an e-commerce catalog"

    # Replace AttributeInfo(...) with dicts (SelfQueryRetriever supports these)
    metadata_field_info = [
        {
            "name": "category",
            "description": "Product category such as headphones, earbuds, speakers",
            "type": "string",
        },
        {
            "name": "brand",
            "description": "Brand name",
            "type": "string",
        },
        {
            "name": "price_eur",
            "description": "Price in euros",
            "type": "float",
        },
        {
            "name": "tenant_id",
            "description": "Internal tenant boundary for the catalog",
            "type": "string",
        },
    ]

    llm = ChatOpenAI(temperature=0)

    # Hard boundary: enforce tenant_id at the system level.
    enforced_search_kwargs = {"filter": {"tenant_id": "shop_1"}, "k": 5}

    retriever = SelfQueryRetriever.from_llm(
        llm=llm,
        vectorstore=vectordb,
        document_contents=document_content_description,
        metadata_field_info=metadata_field_info,
        search_kwargs=enforced_search_kwargs,
        verbose=True,
    )

    query = "wireless headphones under 100 euros"
    hits = retriever.invoke(query)

    print(f"Query: {query}\nResults:")
    for i, d in enumerate(hits, start=1):
        print(f"\n[{i}] {d.metadata}\n{d.page_content}")


if __name__ == "__main__":
    main()