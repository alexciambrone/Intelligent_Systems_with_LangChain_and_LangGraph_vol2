from __future__ import annotations

from typing import List

from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

from .config import OPENAI_API_KEY


# -----------------------------
# 1) Tiny support KB (same idea as before)
# -----------------------------
docs: List[Document] = [
    Document(
        page_content=(
            "Refunds are issued to the original payment method within 5 business days "
            "after the returned item is received and inspected."
        ),
        metadata={"source": "refund_policy", "section": "timelines"},
    ),
    Document(
        page_content=(
            "Items can be returned within 30 days of delivery if they are unused and in "
            "their original packaging. Perishable goods are not returnable."
        ),
        metadata={"source": "refund_policy", "section": "eligibility"},
    ),
    Document(
        page_content=(
            "If your order shows as delivered but you did not receive it, contact support "
            "within 7 days so we can open an investigation with the carrier."
        ),
        metadata={"source": "shipping_policy", "section": "delivery_issues"},
    ),
]

# -----------------------------
# 2) Index + retriever
# -----------------------------
embeddings = OpenAIEmbeddings()
vectordb = Chroma.from_documents(
    documents=docs,
    embedding=embeddings,
    collection_name="support_kb_grounded",
)
retriever = vectordb.as_retriever(search_kwargs={"k": 3})

# -----------------------------
# 3) Context formatting with stable chunk IDs
# -----------------------------
def format_docs_with_citations(docs: List[Document]) -> str:
    """
    Produce a context pack that the model can cite mechanically.
    We keep it minimal: one numbered block per chunk, with lightweight metadata.
    """
    blocks: List[str] = []
    for i, d in enumerate(docs, start=1):
        src = d.metadata.get("source", "unknown")
        sec = d.metadata.get("section", "unknown")
        blocks.append(f"[{i}] ({src} / {sec})\n{d.page_content}")
    return "\n\n".join(blocks)


prompt = ChatPromptTemplate.from_template(
    """You are a support assistant.

Answer the question using only the provided context.

Cite the context for every factual claim using the bracketed chunk ids like [1] or [2].
Do not cite anything that is not in the context.
If the context does not contain enough information to answer, say "I don't know based on the provided context."

Context:
{context}

Question:
{question}
"""
)

# -----------------------------
# 4) Debug: print the prompt that is sent to the LLM
# -----------------------------
def print_prompt(prompt_value):
    print("\n----- PROMPT SENT TO LLM -----")
    try:
        # ChatPromptValue supports to_string() in most versions
        print(prompt_value.to_string())
    except Exception:
        # Fallback: print messages if available, else raw object
        try:
            for m in prompt_value.to_messages():
                print(f"{m.type.upper()}: {m.content}")
        except Exception:
            print(prompt_value)
    print("----- END PROMPT -----\n")
    return prompt_value


rag_chain = (
    {"context": retriever | format_docs_with_citations, "question": RunnablePassthrough()}
    | prompt
    | RunnableLambda(print_prompt)
    | ChatOpenAI(temperature=0)
    | StrOutputParser()
)

if __name__ == "__main__":
    print(rag_chain.invoke("How long do refunds take after you receive my return?"))
