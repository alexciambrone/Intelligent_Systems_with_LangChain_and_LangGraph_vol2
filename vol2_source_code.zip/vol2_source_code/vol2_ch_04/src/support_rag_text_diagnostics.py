# src/support_rag_text_diagnostics.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.documents import Document
from langchain_core.language_models.fake import FakeListLLM
from langchain_community.embeddings.fake import DeterministicFakeEmbedding
from langchain_community.vectorstores import Chroma

from .text_trace import JsonlTracer


# -----------------------------
# Data model
# -----------------------------
@dataclass(frozen=True)
class Candidate:
    chunk_id: str
    score: float
    doc: Document


# -----------------------------
# Version parsing + filtering
# -----------------------------
def parse_version(v: Optional[str]) -> Optional[Tuple[int, int]]:
    # Expect "YYYY-MM"
    if not v:
        return None
    try:
        y_s, m_s = v.split("-", 1)
        y = int(y_s)
        m = int(m_s)
        if m < 1 or m > 12:
            return None
        return (y, m)
    except Exception:
        return None


def version_gte(v: Optional[str], min_v: Optional[str]) -> bool:
    if not min_v:
        return True
    pv = parse_version(v)
    pm = parse_version(min_v)
    if pv is None or pm is None:
        return False
    return pv >= pm


# -----------------------------
# KB (tiny, deterministic)
# -----------------------------
def build_kb_docs() -> List[Document]:
    # Keep chunk_id in metadata so we can trace it.
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days after the returned item is "
                "received and inspected."
            ),
            metadata={
                "chunk_id": "rp-1",
                "doc_id": "refund_policy",
                "version": "2025-10",
                "tenant_id": "shop_1",
                "source": "kb/refunds.md",
                "section": "timelines",
            },
        ),
        Document(
            page_content="Inspection may take up to 2 business days during peak season.",
            metadata={
                "chunk_id": "rp-5",
                "doc_id": "refund_policy",
                "version": "2025-10",
                "tenant_id": "shop_1",
                "source": "kb/refunds.md",
                "section": "timelines",
            },
        ),
        Document(
            page_content="Items can be returned within 30 days of delivery if unused and in original packaging.",
            metadata={
                "chunk_id": "rp-2",
                "doc_id": "refund_policy",
                "version": "2025-10",
                "tenant_id": "shop_1",
                "source": "kb/refunds.md",
                "section": "eligibility",
            },
        ),
        # A legacy policy from a different tenant, to demonstrate filtering.
        Document(
            page_content="Refunds are issued within 10 business days after the returned item is received and inspected.",
            metadata={
                "chunk_id": "rp-old-1",
                "doc_id": "refund_policy_old",
                "version": "2024-01",
                "tenant_id": "shop_2",
                "source": "kb/legacy_refunds.md",
                "section": "timelines",
            },
        ),
    ]


def build_vectorstore() -> Chroma:
    # Deterministic fake embeddings so the example runs offline and is stable.
    embeddings = DeterministicFakeEmbedding(size=32)
    docs = build_kb_docs()
    return Chroma.from_documents(
        documents=docs,
        embedding=embeddings,
        collection_name="support_rag_text_diagnostics",
    )


# -----------------------------
# Query-aware packing
# -----------------------------
def _norm(s: str) -> str:
    return (s or "").strip().lower()


def is_essential_for_question(question: str, c: Candidate) -> bool:
    q = _norm(question)
    md = c.doc.metadata or {}
    section = _norm(str(md.get("section", "")))
    text = _norm(c.doc.page_content)

    # Refund timeline questions: prefer timeline chunks, especially the timeline statement.
    if "refund" in q and (("how long" in q) or ("take" in q) or ("time" in q) or ("timeline" in q)):
        if section == "timelines":
            return True
        if text.startswith("refunds are issued"):
            return True

    return False


def pack_context(
    question: str, candidates: List[Candidate], char_budget: int
) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Pack essentials first, then optional. Prevents non-essential chunks from pushing out the chunk that answers.
    """
    used = 0
    lines: List[str] = []
    decisions: List[Dict[str, Any]] = []

    essentials = [c for c in candidates if is_essential_for_question(question, c)]
    optional = [c for c in candidates if c not in essentials]

    # Preserve incoming order, but force essentials to the front.
    ordered = essentials + optional

    for c in ordered:
        text = c.doc.page_content.strip()
        entry = f"[{c.chunk_id}] {text}"
        need = len(entry) + 1

        if used + need > char_budget:
            decisions.append(
                {
                    "chunk_id": c.chunk_id,
                    "decision": "dropped",
                    "reason": f"budget_exceeded(used={used}, need={need}, budget={char_budget})",
                    "score": c.score,
                    "essential": c in essentials,
                }
            )
            continue

        lines.append(entry)
        used += need
        decisions.append(
            {
                "chunk_id": c.chunk_id,
                "decision": "included",
                "reason": "within_budget",
                "score": c.score,
                "essential": c in essentials,
            }
        )

    return "\n".join(lines), decisions


# -----------------------------
# Grounding guard (demo safety)
# -----------------------------
def is_answer_supported(answer: str, context: str) -> Tuple[bool, str]:
    """
    Cheap deterministic guard for the demo:
    If answer mentions key factual phrases that are not present in context, treat as ungrounded.
    """
    a = _norm(answer)
    c = _norm(context)

    checks = [
        ("5 business days", "5 business days"),
        ("10 business days", "10 business days"),
        ("7 days", "7 days"),
        ("2 business days", "2 business days"),
    ]
    for needle, label in checks:
        if needle in a and needle not in c:
            return False, f"missing_in_context('{label}')"

    return True, "ok"


# -----------------------------
# Prompting
# -----------------------------
def build_prompt(context_text: str, question: str) -> str:
    return (
        "Human: You are a support assistant.\n"
        'Answer the question using only the context. If context is insufficient, say: "I don\'t know based on the provided context."\n\n'
        f"Context:\n{context_text}\n\n"
        f"Question:\n{question}\n"
    )


# -----------------------------
# Pipeline pieces
# -----------------------------
def retrieve_candidates(vs: Chroma, query: str, k: int) -> List[Candidate]:
    # Chroma returns (Document, score). Score semantics can vary; we log raw scores.
    pairs = vs.similarity_search_with_score(query, k=k)

    out: List[Candidate] = []
    for doc, score in pairs:
        md = doc.metadata or {}
        out.append(
            Candidate(
                chunk_id=str(md.get("chunk_id", "unknown")),
                score=float(score),
                doc=doc,
            )
        )
    return out


def eligibility_filter(
    cands: List[Candidate], tenant_id: str, min_version: Optional[str]
) -> Tuple[List[Candidate], List[Dict[str, Any]]]:
    kept: List[Candidate] = []
    dropped: List[Dict[str, Any]] = []

    for c in cands:
        md = c.doc.metadata or {}
        c_tenant = str(md.get("tenant_id", ""))
        c_ver = str(md.get("version", ""))

        if c_tenant != tenant_id:
            dropped.append(
                {
                    "chunk_id": c.chunk_id,
                    "score": c.score,
                    "reason": f"tenant_mismatch({c_tenant} != {tenant_id})",
                }
            )
            continue

        if not version_gte(c_ver, min_version):
            dropped.append(
                {
                    "chunk_id": c.chunk_id,
                    "score": c.score,
                    "reason": f"version_too_old({c_ver} < {min_version})",
                }
            )
            continue

        kept.append(c)

    return kept, dropped


def rank_candidates(cands: List[Candidate], method: str = "score_desc") -> List[Candidate]:
    # Explicit: treat higher score as better.
    # If you switch to a distance metric later, flip to score_asc.
    if method == "score_asc":
        return sorted(cands, key=lambda c: c.score)
    return sorted(cands, key=lambda c: c.score, reverse=True)


# -----------------------------
# Main
# -----------------------------
def main() -> None:
    trace_path = Path("traces") / "support_rag_trace.jsonl"
    tracer = JsonlTracer(trace_path)

    # Inputs
    question = "How long do refunds take after you receive my return?"
    tenant_id = "shop_1"
    min_version = "2025-01"
    k = 4
    char_budget = 260
    rank_method = "score_desc"  # change to "score_asc" if your backend uses distance

    vs = build_vectorstore()

    # Demo LLM output (offline). The grounding guard prevents it from "winning" if context lacks facts.
    llm = FakeListLLM(
        responses=[
            "Refunds are issued within 5 business days after the return is received and inspected. "
            "During peak season, inspection can take up to 2 business days, so the total can be slightly longer."
        ]
    )

    try:
        with tracer.span(
            "request",
            question=question,
            tenant_id=tenant_id,
            min_version=min_version,
            k=k,
            char_budget=char_budget,
        ):
            # Retrieve
            with tracer.span("retrieve_candidates", query=question, k=k):
                cands = retrieve_candidates(vs, question, k=k)

            tracer.emit(
                "retrieve_candidates",
                "info",
                returned=[
                    {
                        "chunk_id": c.chunk_id,
                        "score": c.score,
                        "doc_id": c.doc.metadata.get("doc_id"),
                        "version": c.doc.metadata.get("version"),
                        "tenant_id": c.doc.metadata.get("tenant_id"),
                        "source": c.doc.metadata.get("source"),
                    }
                    for c in cands
                ],
            )

            # Filter by tenant/version
            with tracer.span("eligibility_filter", tenant_id=tenant_id, min_version=min_version):
                kept, dropped = eligibility_filter(cands, tenant_id=tenant_id, min_version=min_version)
                tracer.emit(
                    "eligibility_filter",
                    "info",
                    kept=[{"chunk_id": c.chunk_id, "score": c.score} for c in kept],
                    dropped=dropped,
                )

            # Rank
            with tracer.span("rank", method=rank_method):
                ranked = rank_candidates(kept, method=rank_method)

            tracer.emit(
                "rank",
                "info",
                ranking=[{"rank": i + 1, "chunk_id": c.chunk_id, "score": c.score} for i, c in enumerate(ranked)],
            )

            # Pack
            with tracer.span("pack_context", char_budget=char_budget):
                context_text, decisions = pack_context(question, ranked, char_budget=char_budget)

            tracer.emit("pack_context", "info", decisions=decisions, context=context_text)

            # Prompt
            prompt = build_prompt(context_text, question)
            tracer.emit("llm", "info", prompt=prompt)

            # LLM invoke (timed separately)
            with tracer.span("llm_invoke", model="FakeListLLM"):
                answer = llm.invoke(prompt)

            # Grounding check
            ok, reason = is_answer_supported(answer, context_text)
            tracer.emit("grounding_check", "info", ok=ok, reason=reason)

            if not ok:
                answer = "I don't know based on the provided context."
                tracer.emit("grounding_check", "info", overridden_answer=answer)

            tracer.emit("llm", "info", answer=answer)

    finally:
        tracer.close()


if __name__ == "__main__":
    main()