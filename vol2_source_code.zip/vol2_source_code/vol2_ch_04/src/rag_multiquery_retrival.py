from __future__ import annotations
import os
from typing import List

from langchain_core.documents import Document

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

from langchain_classic.retrievers.multi_query import MultiQueryRetriever
from .config import OPENAI_API_KEY

# ---- ADD THIS ----
from langchain_core.globals import set_debug
set_debug(True)
# ------------------


def build_support_kb() -> List[Document]:
    return [
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines"},
        ),
        Document(
            page_content=(
                "A return is considered received when the carrier tracking shows delivered "
                "to our returns center."
            ),
            metadata={"source": "refund_policy", "section": "definitions"},
        ),
        Document(
            page_content=("Inspection may take up to 2 business days during peak season."),
            metadata={"source": "refund_policy", "section": "timelines"},
        ),
    ]


def main() -> None:
    docs = build_support_kb()

    vectordb = Chroma.from_documents(
        documents=docs,
        embedding=OpenAIEmbeddings(),
        collection_name="support_kb_multiquery",
    )
    base_retriever = vectordb.as_retriever(search_kwargs={"k": 3})

    llm = ChatOpenAI(temperature=0)

    mq_retriever = MultiQueryRetriever.from_llm(
        retriever=base_retriever,
        llm=llm,
        include_original=True,
    )

    query = "How long does it take to get my money back after I return an item?"
    docs = mq_retriever.invoke(query)

    print(f"\nRetrieved {len(docs)} unique chunks:")
    for i, d in enumerate(docs, start=1):
        print(f"\n[{i}] {d.metadata}\n{d.page_content}")


if __name__ == "__main__":
    main()