from __future__ import annotations
from typing import List
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from .config import OPENAI_API_KEY

# -----------------------------
# 1) Build a tiny support KB
# -----------------------------
docs: List[Document] = [
    Document(
        page_content=(
            "Refunds are issued to the original payment method within 5 business days "
            "after the returned item is received and inspected."
        ),
        metadata={"source": "refund_policy", "section": "timelines"},
    ),
    Document(
        page_content=(
            "Items can be returned within 30 days of delivery if they are unused and in "
            "their original packaging. Perishable goods are not returnable."
        ),
        metadata={"source": "refund_policy", "section": "eligibility"},
    ),
    Document(
        page_content=(
            "If your order shows as delivered but you did not receive it, contact support "
            "within 7 days so we can open an investigation with the carrier."
        ),
        metadata={"source": "shipping_policy", "section": "delivery_issues"},
    ),
]

# -----------------------------
# 2) Index into a vector store and create a retriever
# -----------------------------
embeddings = OpenAIEmbeddings()
vectordb = Chroma.from_documents(
    documents=docs,
    embedding=embeddings,
    collection_name="support_kb",
)
retriever = vectordb.as_retriever(search_kwargs={"k": 3})

# -----------------------------
# 3) Define prompt and formatter (format step)
# -----------------------------
prompt = ChatPromptTemplate.from_template(
    """You are a support assistant.
Answer the question using only the provided context.
If the context does not contain the answer, say "I don't know."

Context:
{context}

Question:
{question}
"""
)

def format_docs(docs: List[Document]) -> str:
    # Minimal, predictable formatting: one chunk per block.
    return "\n\n".join(d.page_content for d in docs)

# -----------------------------
# 4) Compose the LCEL RAG chain (retrieve → format → answer)
# -----------------------------
rag_chain = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough(),
    }
    | prompt
    | ChatOpenAI(temperature=0)
    | StrOutputParser()
)

if __name__ == "__main__":
    print(rag_chain.invoke("How long do refunds take after you receive my return?"))


