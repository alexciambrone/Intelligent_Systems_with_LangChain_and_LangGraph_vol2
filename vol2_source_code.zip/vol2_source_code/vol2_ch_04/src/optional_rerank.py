from __future__ import annotations

import re
from typing import List

from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.vectorstores import InMemoryVectorStore

from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.callbacks import get_openai_callback

from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors.listwise_rerank import LLMListwiseRerank
from .config import OPENAI_API_KEY

def build_docs() -> List[Document]:
    return [
        Document(page_content="Refunds are issued within 5 business days after the returned item is received and inspected.", metadata={"id": "rp-1"}),
        Document(page_content="Inspection may take up to 2 business days during peak season.", metadata={"id": "rp-5"}),
        Document(page_content="Shipping fees are not refundable unless the return is due to our error.", metadata={"id": "rp-3"}),
        Document(page_content="Returns are accepted within 30 days if unused and in original packaging.", metadata={"id": "rp-2"}),
    ]


def looks_risky(query: str) -> bool:
    # Heuristic gate: short queries and code-like tokens often correlate with ranking failures.
    if len(query.split()) <= 4:
        return True
    if re.search(r"\b[A-Z]{1,3}\d{2,}\b", query):  # e.g., E42
        return True
    return False


def format_context(docs: List[Document]) -> str:
    return "\n\n".join(f"[{i}] {d.page_content}" for i, d in enumerate(docs, start=1))


def main() -> None:
    docs = build_docs()
    vs = InMemoryVectorStore(embedding=OpenAIEmbeddings())
    vs.add_documents(docs)

    base_retriever = vs.as_retriever(search_kwargs={"k": 4})

    llm = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0,
        max_tokens=200
    )
    reranker = LLMListwiseRerank.from_llm(llm=llm, top_n=2)
    rerank_retriever = ContextualCompressionRetriever(
        base_retriever=base_retriever,
        base_compressor=reranker,
    )

    prompt = ChatPromptTemplate.from_template(
        "You are a support assistant.\n"
        "Answer using only the context.\n"
        "If the context is insufficient, say you don't know.\n\n"
        "Context:\n{context}\n\nQuestion:\n{question}\n"
    )

    def answer(question: str) -> str:
        retriever = rerank_retriever if looks_risky(question) else base_retriever
        hits = retriever.invoke(question)
        ctx = format_context(hits)

        with get_openai_callback() as cb:
            out = (prompt | llm | StrOutputParser()).invoke({"context": ctx, "question": question})
            print("\n=== Token usage ===")
            print(f"prompt_tokens:     {cb.prompt_tokens}")
            print(f"completion_tokens: {cb.completion_tokens}")
            print(f"total_tokens:      {cb.total_tokens}")
            print(f"total_cost_usd:    {cb.total_cost}")
        return out

    print(answer("refund timeline"))
    print(answer("How long do refunds take after you receive my return?"))


if __name__ == "__main__":
    main()


