from __future__ import annotations
import json
import os
from typing import List, Dict, Any, Tuple
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from .config import OPENAI_API_KEY


def build_support_kb() -> List[Document]:
    return [
        Document(
            page_content=(
                "Items can be returned within 30 days of delivery if they are unused and in "
                "their original packaging. Perishable goods are not returnable."
            ),
            metadata={"source": "refund_policy", "section": "eligibility"},
        ),
        Document(
            page_content=(
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "refund_policy", "section": "timelines"},
        ),
        Document(
            page_content=("Exchanges are only available for damaged items reported within 48 hours."),
            metadata={"source": "refund_policy", "section": "exchanges"},
        ),
    ]


def format_docs(docs: List[Document]) -> str:
    return "\n\n".join(d.page_content for d in docs)


def unique_union(docs: List[Document]) -> List[Document]:
    out: List[Document] = []
    for d in docs:
        if d not in out:
            out.append(d)
    return out


def main() -> None:
    docs = build_support_kb()

    vectordb = Chroma.from_documents(
        documents=docs,
        embedding=OpenAIEmbeddings(),
        collection_name="support_kb_decomposition",
    )
    retriever = vectordb.as_retriever(search_kwargs={"k": 3})

    decompose_prompt = ChatPromptTemplate.from_template(
        """Decompose the user question into 1-4 simple sub-questions.
Each sub-question should be answerable from a policy document.
Return ONLY valid JSON in the shape: {{"subquestions": ["...","..."]}}.

User question: {question}
"""
    )

    llm = ChatOpenAI(temperature=0)
    decompose_chain = decompose_prompt | llm | StrOutputParser()

    answer_prompt = ChatPromptTemplate.from_template(
        """You are a support assistant.
Answer using only the provided context.
If the context does not contain enough information, say "I don't know."

Context:
{context}

Question:
{question}
"""
    )

    answer_chain = answer_prompt | llm | StrOutputParser()

    def decompose(question: str) -> Tuple[List[str], bool]:
        raw = decompose_chain.invoke({"question": question})
        try:
            data: Dict[str, Any] = json.loads(raw)
            subs: List[str] = data.get("subquestions", [])
            if not isinstance(subs, list) or not all(isinstance(x, str) for x in subs) or len(subs) == 0:
                raise ValueError("Invalid 'subquestions' list")
            return subs, True
        except Exception:
            return [question], False

    def run_with_traces(question: str) -> str:
        print(f"Original question: {question}")

        subs, parsed_ok = decompose(question)

        # ---- CHANGED: print only the parsed JSON label/output (no raw) ----
        if parsed_ok:
            print("Decomposition JSON (parsed):")
            print(json.dumps({"subquestions": subs}, indent=2, ensure_ascii=False))
        else:
            print("Decomposition JSON (parsed): <invalid JSON, fallback to single sub-question>")
        # ------------------------------------------------------------------

        all_docs: List[Document] = []
        print("\nIndividual sub-answers:")
        for i, sq in enumerate(subs, start=1):
            docs_sq = retriever.invoke(sq)
            all_docs.extend(docs_sq)

            context_sq = format_docs(docs_sq)
            ans_sq = answer_chain.invoke({"context": context_sq, "question": sq})

            print(f"\n[{i}] Sub-question: {sq}")
            print(f"[{i}] Answer: {ans_sq}")

        merged_docs = unique_union(all_docs)
        merged_context = format_docs(merged_docs)
        merged_answer = answer_chain.invoke({"context": merged_context, "question": question})

        print("\nMerged answer (from union of retrieved docs):")
        print(merged_answer)

        return merged_answer

    final_answer = run_with_traces(
        "Can I return an unused item, and how long does the refund take after you receive it?"
    )

if __name__ == "__main__":
    main()