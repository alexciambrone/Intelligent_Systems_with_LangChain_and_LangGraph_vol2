# file: src/support_chat_memory_entity_kg.py
from __future__ import annotations

from typing import Optional, List, Dict, Any, Tuple
from pydantic import BaseModel, Field

from langchain.chat_models import init_chat_model
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_core.messages.utils import trim_messages
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from .config import OPENAI_API_KEY


# Intentionally tiny to demonstrate that the raw window can "forget",
# while derived state (case file + triples) still carries key context.
PROMPT_LAST_MESSAGES = 2


class SupportCase(BaseModel):
    order_id: Optional[str] = Field(default=None)
    product: Optional[str] = Field(default=None)
    purchase_timing: Optional[str] = Field(default=None)
    is_gift: Optional[bool] = Field(default=None)
    issue: Optional[str] = Field(default=None)
    desired_outcome: Optional[str] = Field(default=None)


class Triple(BaseModel):
    subject: str
    predicate: str
    obj: str


class TriplePatch(BaseModel):
    # Patch semantics: only NEW triples for this turn.
    triples: List[Triple] = Field(default_factory=list)


class State(BaseModel):
    messages: List[BaseMessage] = Field(default_factory=list)
    case: SupportCase = Field(default_factory=SupportCase)
    kg: List[Triple] = Field(default_factory=list)


answer_model = init_chat_model("gpt-4.1", temperature=0)

# Extract a PATCH only: fields not mentioned should stay null in the patch.
case_extractor = init_chat_model("gpt-4.1-mini", temperature=0).with_structured_output(
    SupportCase,
    method="function_calling",
    include_raw=False,
)

# Extract NEW triples only (patch), based on this turn's user message.
kg_extractor = init_chat_model("gpt-4.1-mini", temperature=0).with_structured_output(
    TriplePatch,
    method="function_calling",
    include_raw=False,
)


def case_summary(case: SupportCase) -> str:
    parts: List[str] = []
    if case.order_id:
        parts.append(f"order_id={case.order_id}")
    if case.product:
        parts.append(f"product={case.product}")
    if case.purchase_timing:
        parts.append(f"purchase_timing={case.purchase_timing}")
    if case.is_gift is not None:
        parts.append(f"is_gift={case.is_gift}")
    if case.issue:
        parts.append(f"issue={case.issue}")
    if case.desired_outcome:
        parts.append(f"desired_outcome={case.desired_outcome}")
    return ", ".join(parts) if parts else "(empty)"


def kg_summary(kg: List[Triple]) -> str:
    if not kg:
        return "(empty)"
    return "; ".join([f"({t.subject}, {t.predicate}, {t.obj})" for t in kg])


def merge_case(existing: SupportCase, patch: SupportCase) -> SupportCase:
    merged = existing.model_dump()
    for k, v in patch.model_dump().items():
        if v is not None:
            merged[k] = v
    return SupportCase(**merged)


def _triple_key(t: Triple) -> Tuple[str, str, str]:
    # Normalize lightly to reduce duplicate noise.
    return (t.subject.strip(), t.predicate.strip(), t.obj.strip())


def merge_triples(existing: List[Triple], patch: List[Triple]) -> List[Triple]:
    seen = {_triple_key(t) for t in existing}
    merged = list(existing)
    for t in patch:
        key = _triple_key(t)
        if key not in seen:
            merged.append(t)
            seen.add(key)
    return merged


def extract_case_patch(existing: SupportCase, new_human: HumanMessage) -> SupportCase:
    prompt = [
        SystemMessage(
            content=(
                "You update a support CASE FILE.\n\n"
                "You will receive:\n"
                "1) CURRENT CASE FILE (authoritative so far)\n"
                "2) NEW USER MESSAGE (this turn only)\n\n"
                "Task:\n"
                "- Extract ONLY new or corrected facts from NEW USER MESSAGE.\n"
                "- If a field is not mentioned or not corrected, output null for that field.\n"
                "- Do not guess.\n"
                "- Do not restate old facts unless NEW USER MESSAGE changes them.\n\n"
                f"CURRENT CASE FILE:\n{existing.model_dump_json(indent=2)}\n"
            )
        ),
        new_human,
    ]
    return case_extractor.invoke(prompt)


def extract_kg_patch(existing_case: SupportCase, existing_kg: List[Triple], new_human: HumanMessage) -> List[Triple]:
    # We pass the current case summary to improve grounding (e.g., order id, product),
    # but we still require that triples be supported by the NEW USER MESSAGE.
    prompt = [
        SystemMessage(
            content=(
                "You update a conversation-derived KNOWLEDGE GRAPH as triples.\n\n"
                "You will receive:\n"
                "1) CURRENT CASE FILE SUMMARY (context)\n"
                "2) CURRENT TRIPLES (already known)\n"
                "3) NEW USER MESSAGE (this turn only)\n\n"
                "Task:\n"
                "- Extract ONLY NEW relationships explicitly stated in NEW USER MESSAGE.\n"
                "- Output at most 4 triples.\n"
                "- Do not guess or infer.\n"
                "- Do not restate triples that already exist unless the NEW USER MESSAGE changes the relationship.\n"
                "- If no new relationships are stated, return an empty list.\n\n"
                f"CURRENT CASE FILE SUMMARY:\n{case_summary(existing_case)}\n\n"
                f"CURRENT TRIPLES:\n{kg_summary(existing_kg)}\n"
            )
        ),
        new_human,
    ]
    patch_obj: TriplePatch = kg_extractor.invoke(prompt)
    return patch_obj.triples


def answer_with_case_and_kg(case: SupportCase, kg: List[Triple], messages: List[BaseMessage]) -> AIMessage:
    # Keep only a tiny window of chat messages verbatim (message-count window for the demo).
    recent = trim_messages(
        messages,
        strategy="last",
        token_counter=len,
        max_tokens=PROMPT_LAST_MESSAGES,
    )

    # Inject both derived views as controlled context.
    kg_lines = "\n".join([f"- ({t.subject}, {t.predicate}, {t.obj})" for t in kg]) if kg else "- (none)"

    system = SystemMessage(
        content=(
            "You are a customer support assistant.\n"
            "Use the CASE FILE and TRIPLES to avoid asking the user to repeat stable facts.\n"
            "Treat them as conversation-derived context, not as policy evidence.\n\n"
            f"CASE FILE SUMMARY: {case_summary(case)}\n"
            f"CASE FILE (JSON):\n{case.model_dump_json(indent=2)}\n\n"
            "KNOWN RELATIONSHIPS (triples):\n"
            f"{kg_lines}\n"
        )
    )

    # For teaching: print what the model actually sees.
    print("\n--- PROMPT WINDOW (LAST MESSAGES) ---")
    for m in recent:
        print(f"{m.type}: {m.content}")

    print("\n--- DERIVED STATE (INJECTED) ---")
    print(f"CASE: {case_summary(case)}")
    print(f"TRIPLES: {kg_summary(kg)}")

    return answer_model.invoke([system, *recent])


def step(state: State) -> Dict[str, Any]:
    # One processing step runs after each incoming user message:
    # 1) extract a case patch from the NEW human message
    # 2) merge into the case file
    # 3) extract a triples patch from the NEW human message
    # 4) merge into the KG triples list
    # 5) call the model using (tiny verbatim window + derived state)
    # 6) append AI response to messages
    if not state.messages or state.messages[-1].type != "human":
        return {}

    human = state.messages[-1]
    assert isinstance(human, HumanMessage)

    before_case = state.case
    before_kg = state.kg

    case_patch = extract_case_patch(before_case, human)
    after_case = merge_case(before_case, case_patch)

    kg_patch = extract_kg_patch(after_case, before_kg, human)
    after_kg = merge_triples(before_kg, kg_patch)

    print("\n--- TURN ---")
    print(f"HUMAN: {human.content}")

    print("\n--- CASE PATCH (THIS TURN) ---")
    print(case_patch.model_dump_json(indent=2))

    print("\n--- CASE (MERGED) ---")
    print(after_case.model_dump_json(indent=2))
    print(f"CASE SUMMARY: {case_summary(after_case)}")

    print("\n--- TRIPLES PATCH (THIS TURN) ---")
    if kg_patch:
        for t in kg_patch:
            print(f"({t.subject}, {t.predicate}, {t.obj})")
    else:
        print("(none)")

    print("\n--- TRIPLES (MERGED) ---")
    if after_kg:
        for t in after_kg:
            print(f"({t.subject}, {t.predicate}, {t.obj})")
    else:
        print("(none)")

    ai = answer_with_case_and_kg(after_case, after_kg, state.messages)
    print("\nAI:", ai.content)

    return {"case": after_case, "kg": after_kg, "messages": state.messages + [ai]}


def build_graph() -> CompiledStateGraph:
    checkpointer = InMemorySaver()
    g = StateGraph(State)
    g.add_node("step", step)
    g.add_edge(START, "step")
    return g.compile(checkpointer=checkpointer)


def main() -> None:
    graph = build_graph()
    config = {"configurable": {"thread_id": "entity-kg-demo-clean"}}

    # Turn 1: establish early facts (order/product/timing/gift)
    state = graph.invoke(
        {
            "messages": [
                HumanMessage(
                    content="Hi. My order ID is ORD-7781. I bought headphones two weeks ago and it was a gift."
                )
            ]
        },
        config,
    )

    # Turn 2: add issue + desired outcome, expressed as a relationship too
    state = graph.invoke(
        {
            "messages": state["messages"]
            + [
                HumanMessage(
                    content="The left earcup is defective. I want a replacement, not a refund."
                )
            ]
        },
        config,
    )

    # Turn 3: query an early fact (the prompt window is tiny, so raw chat will often not contain it)
    state = graph.invoke(
        {"messages": state["messages"] + [HumanMessage(content="What order ID did I give you?")]},
        config,
    )

    print("\n--- FINAL CASE FILE ---")
    print(state["case"].model_dump_json(indent=2))

    print("\n--- FINAL TRIPLES ---")
    if state["kg"]:
        for t in state["kg"]:
            print(f"({t.subject}, {t.predicate}, {t.obj})")
    else:
        print("(none)")


if __name__ == "__main__":
    main()


