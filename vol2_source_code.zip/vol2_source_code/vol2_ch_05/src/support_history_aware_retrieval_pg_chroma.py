from __future__ import annotations

import os
import re
import sys
from typing import List, Dict, Tuple

import psycopg
from psycopg.rows import dict_row

from langchain_core.documents import Document
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_chroma import Chroma

from .config import OPENAI_API_KEY  # noqa: F401


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS chat_messages (
  id          bigserial PRIMARY KEY,
  session_id  text NOT NULL,
  role        text NOT NULL CHECK (role IN ('system','user','assistant')),
  content     text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_messages_session_time_idx
ON chat_messages (session_id, created_at);
"""


def connect() -> psycopg.Connection:
    db_url = "postgresql://postgres:root@localhost:5432/chat"
    if not db_url:
        raise RuntimeError("DATABASE_URL is not set")
    return psycopg.connect(db_url, row_factory=dict_row)


def ensure_schema(conn: psycopg.Connection) -> None:
    with conn.cursor() as cur:
        cur.execute(SCHEMA_SQL)
    conn.commit()


def reset_session(conn: psycopg.Connection, session_id: str) -> None:
    with conn.cursor() as cur:
        cur.execute("DELETE FROM chat_messages WHERE session_id = %s", (session_id,))
    conn.commit()


def save_message(conn: psycopg.Connection, session_id: str, role: str, content: str) -> None:
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO chat_messages(session_id, role, content) VALUES (%s, %s, %s)",
            (session_id, role, content),
        )
    conn.commit()


def load_messages(conn: psycopg.Connection, session_id: str, limit: int = 6) -> List[BaseMessage]:
    """
    Loads a small slice of recent conversation for coreference resolution and query rewriting.
    """
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT role, content
            FROM chat_messages
            WHERE session_id = %s
            ORDER BY created_at DESC
            LIMIT %s
            """,
            (session_id, limit),
        )
        rows = list(reversed(cur.fetchall()))

    out: List[BaseMessage] = []
    for r in rows:
        role = r["role"]
        content = r["content"]
        if role == "system":
            out.append(SystemMessage(content=content))
        elif role == "user":
            out.append(HumanMessage(content=content))
        else:
            out.append(AIMessage(content=content))
    return out


def load_all_rows(conn: psycopg.Connection, session_id: str) -> List[Dict[str, str]]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT role, content, created_at
            FROM chat_messages
            WHERE session_id = %s
            ORDER BY created_at ASC
            """,
            (session_id,),
        )
        return cur.fetchall()


def print_transcript(conn: psycopg.Connection, session_id: str) -> None:
    rows = load_all_rows(conn, session_id)
    print("\n--- CONVERSATION (FROM POSTGRES) ---\n")
    if not rows:
        print("(empty)")
        return

    for r in rows:
        role = r["role"]
        content = r["content"]
        if role == "system":
            label = "SYSTEM"
        elif role == "user":
            label = "USER"
        else:
            label = "ASSISTANT"
        print(f"{label}: {content}")


def build_policy_docs() -> List[Dict[str, str]]:
    return [
        {
            "doc_id": "refunds_v1",
            "text": (
                "Refunds: You can request a refund within 30 days of delivery. "
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
        },
        {
            "doc_id": "gifts_v1",
            "text": (
                "Gift purchases: If an item was purchased as a gift, refunds are issued as store credit "
                "unless the original purchaser requests a refund to the original payment method."
            ),
        },
        {
            "doc_id": "returns_v1",
            "text": (
                "Returns: Items must be returned in original condition. "
                "Return shipping is free for defective items. For non-defective returns, "
                "return shipping is paid by the customer."
            ),
        },
    ]


def open_policy_store(chroma_dir: str, embedder: OpenAIEmbeddings) -> Chroma:
    return Chroma(
        collection_name="support_policy",
        persist_directory=chroma_dir,
        embedding_function=embedder,
    )


def seed_policy(store: Chroma) -> None:
    splitter = RecursiveCharacterTextSplitter(chunk_size=240, chunk_overlap=40)

    docs: List[Document] = []
    ids: List[str] = []
    for d in build_policy_docs():
        parts = splitter.split_text(d["text"])
        for i, part in enumerate(parts):
            doc_id = d["doc_id"]
            ids.append(f"{doc_id}#{i}")
            docs.append(
                Document(
                    page_content=part,
                    metadata={"kind": "policy", "doc_id": doc_id, "chunk_no": i},
                )
            )

    try:
        store.add_documents(docs, ids=ids)
        print(f"Seeded policy chunks into Chroma: {len(docs)}")
    except Exception as e:
        print("Policy likely already seeded (or duplicate IDs).")
        print("Details:", str(e))


def ensure_policy_seeded(store: Chroma) -> None:
    """Seed automatically if the persistent collection is empty."""
    try:
        count = store._collection.count()  # chromadb Collection API (internal access)
    except Exception:
        count = 0
    if count == 0:
        seed_policy(store)


def rewrite_followup(llm: ChatOpenAI, history: List[BaseMessage], user_input: str) -> str:
    """
    Rewrite step is NOT answering.
    It only produces a standalone retrieval query that makes sense in isolation.
    """
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "Rewrite the user's latest message as a standalone search query for a policy knowledge base. "
                "Use chat history only to resolve references like 'that/it/those'. "
                "Do NOT answer the question. "
                "Return a single line query (no preamble). Keep it short (max ~18 words).",
            ),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )
    msg = (prompt | llm).invoke({"chat_history": history, "input": user_input})
    return msg.content.strip()


def is_probably_answer(text: str) -> bool:
    """
    Defensive check: if the model starts answering instead of producing a query,
    treat it as a contract violation and fall back to a safe query template.
    """
    t = text.strip().lower()
    if not t:
        return True

    answer_like_prefixes = (
        "yes",
        "no",
        "refunds are",
        "gift purchases",
        "the policy",
        "according to",
        "it depends",
        "typically",
    )
    if t.startswith(answer_like_prefixes):
        return True

    # If it looks like multiple sentences, it's probably trying to explain.
    if t.count(".") >= 1:
        return True

    return False


def fallback_query_from_context(history: List[BaseMessage], user_input: str) -> str:
    """
    Conservative fallback: user message + anchor terms.
    """
    anchors = ["refund", "inspection", "gift purchase", "store credit", "original payment method", "timeline"]
    parts = [user_input.strip(), *anchors]
    q = " ".join(parts)

    q = re.sub(r"[^\w\s]", " ", q)
    q = " ".join(q.split())
    return q[:220]


def retrieve_policy(store: Chroma, query: str, k: int = 3) -> List[Tuple[Document, float]]:
    return store.similarity_search_with_score(query, k=k, filter={"kind": "policy"})


def format_evidence(hits: List[Tuple[Document, float]]) -> str:
    """
    Build a simple evidence pack that the answer step can cite mechanically.
    """
    lines: List[str] = []
    for i, (doc, _score) in enumerate(hits, start=1):
        meta = doc.metadata or {}
        tag = f"{meta.get('doc_id', 'unknown')}#{meta.get('chunk_no', '?')}"
        lines.append(f"[{i}] ({tag}) {doc.page_content}")
    return "\n".join(lines)


def answer_from_evidence(llm: ChatOpenAI, question: str, evidence: str) -> str:
    """
    Answer step: must use evidence only; if missing, say so.
    """
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a support assistant. Answer the user's question using ONLY the provided evidence.\n"
                "Rules:\n"
                "- If the evidence does not contain the answer, say: \"I don't know based on the provided policy evidence.\"\n"
                "- Keep it concise (1-3 sentences).\n"
                "- When you use evidence, include citations like [1] or [2] at the end of the sentence.\n",
            ),
            ("human", "Question:\n{question}\n\nPolicy evidence:\n{evidence}\n\nAnswer:"),
        ]
    )
    msg = (prompt | llm).invoke({"question": question, "evidence": evidence})
    return msg.content.strip()


def main() -> None:
    session_id = os.environ.get("SESSION_ID", "session-42")
    chroma_dir = os.environ.get("CHROMA_DIR", ".chroma")

    chat_model = os.environ.get("OPENAI_CHAT_MODEL", "gpt-4o-mini")
    embed_model = os.environ.get("OPENAI_EMBED_MODEL", "text-embedding-3-small")

    llm = ChatOpenAI(model=chat_model, temperature=0)
    embedder = OpenAIEmbeddings(model=embed_model)

    conn = connect()
    ensure_schema(conn)

    policy_store = open_policy_store(chroma_dir, embedder)

    if "--seed-policy" in sys.argv:
        seed_policy(policy_store)
        conn.close()
        return

    ensure_policy_seeded(policy_store)

    # Demo conversation persisted in Postgres
    reset_session(conn, session_id)
    save_message(conn, session_id, "system", "You are a concise support assistant.")
    save_message(conn, session_id, "user", "How long do refunds take after inspection?")
    save_message(
        conn,
        session_id,
        "assistant",
        "Refunds are issued within 5 business days after inspection. (example prior answer)",
    )

    followup = "Does that include gifts?"
    save_message(conn, session_id, "user", followup)

    # Print the transcript BEFORE we do rewriting/retrieval/answer, so you see the initial exchange too.
    print_transcript(conn, session_id)

    # Small slice of history for rewriting (coreference resolution only).
    history = load_messages(conn, session_id, limit=6)

    rewritten = rewrite_followup(llm, history, followup)
    violated = is_probably_answer(rewritten)
    if violated:
        rewritten = fallback_query_from_context(history, followup)

    hits = retrieve_policy(policy_store, rewritten, k=3)
    evidence = format_evidence(hits)

    # Produce the actual answer to the last user question using retrieved evidence.
    answer = answer_from_evidence(llm, followup, evidence)

    # Save and show the final assistant answer (also goes in the table).
    save_message(conn, session_id, "assistant", answer)

    print("\n--- FOLLOW-UP ---\n", followup)
    print("\n--- REWRITTEN RETRIEVAL QUERY ---")
    if violated:
        print("(rewrite contract violated; using fallback query)")
    print(rewritten)

    print("\n--- RETRIEVED POLICY EVIDENCE ---\n")
    if not hits:
        print("(no evidence retrieved)")
    else:
        for i, (doc, score) in enumerate(hits, start=1):
            meta = doc.metadata
            print(f"[{i}] {meta.get('doc_id')}#{meta.get('chunk_no')}  score={score:.4f}")
            print("   ", doc.page_content)

    print("\n--- ANSWER (evidence-grounded) ---\n")
    print(answer)

    # Optional: show the transcript again including the final assistant answer.
    print_transcript(conn, session_id)

    conn.close()


if __name__ == "__main__":
    main()