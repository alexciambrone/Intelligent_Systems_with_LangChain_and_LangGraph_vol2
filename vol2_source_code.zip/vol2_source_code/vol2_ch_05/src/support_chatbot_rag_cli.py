from __future__ import annotations
import argparse
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from langchain.chat_models import init_chat_model
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_text_splitters import RecursiveCharacterTextSplitter
from .config import OPENAI_API_KEY

# -----------------------------
# Utilities: trace logging
# -----------------------------

@dataclass
class TraceWriter:
    path: Path

    def write(self, event_type: str, payload: Dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            **payload,
        }
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


# -----------------------------
# Knowledge base (private data)
# -----------------------------
def build_toy_support_kb() -> List[Document]:
    # Keep docs small and policy-like: rules + exceptions.
    # In a real system these come from your private corpus (PDFs, wikis, CMS, etc.).
    docs = [
        Document(
            page_content=(
                "Refunds: You can request a refund within 30 days of delivery. "
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            metadata={"source": "policy/refunds", "doc_id": "refunds_v1"},
        ),
        Document(
            page_content=(
                "Returns: Items must be returned in original condition. "
                "Return shipping is free for defective items. "
                "For non-defective returns, return shipping is paid by the customer."
            ),
            metadata={"source": "policy/returns", "doc_id": "returns_v1"},
        ),
        Document(
            page_content=(
                "Exchanges: Exchanges are available for size or color within 30 days of delivery, "
                "subject to stock availability. If the item is out of stock, a refund is offered."
            ),
            metadata={"source": "policy/exchanges", "doc_id": "exchanges_v1"},
        ),
        Document(
            page_content=(
                "Gift purchases: For gifts, refunds are issued as store credit unless the purchaser "
                "requests a refund to the original payment method and provides the order number."
            ),
            metadata={"source": "policy/gifts", "doc_id": "gifts_v1"},
        ),
    ]
    return docs


def chunk_documents(
    docs: List[Document],
    chunk_size: int = 320,
    chunk_overlap: int = 40,
) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        is_separator_regex=False,
    )

    chunks: List[Document] = []
    for d in docs:
        pieces = splitter.split_text(d.page_content)
        for i, piece in enumerate(pieces):
            chunks.append(
                Document(
                    page_content=piece,
                    metadata={**d.metadata, "chunk_index": i},
                )
            )
    return chunks


def ensure_vector_store(
    persist_dir: Path,
    collection_name: str,
    rebuild: bool,
    trace: Optional[TraceWriter],
) -> Chroma:
    persist_dir.mkdir(parents=True, exist_ok=True)

    embeddings = OpenAIEmbeddings(model=os.getenv("OPENAI_EMBEDDINGS_MODEL", "text-embedding-3-large"))

    vs = Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=str(persist_dir),
    )

    # Detect empty collection (fresh run without --rebuild-index).
    try:
        count = vs._collection.count()  # Chroma collection count (works with langchain_chroma wrapper)
    except Exception:
        count = 0

    should_build = rebuild or (count == 0)

    if should_build:
        # Clear existing docs to avoid duplicates when rebuilding.
        try:
            vs._collection.delete(where={})  # delete all
        except Exception:
            pass

        kb_docs = build_toy_support_kb()
        kb_chunks = chunk_documents(kb_docs)
        vs.add_documents(kb_chunks)

        if trace:
            trace.write(
                "index_built",
                {
                    "collection": collection_name,
                    "persist_dir": str(persist_dir),
                    "num_source_docs": len(kb_docs),
                    "num_chunks": len(kb_chunks),
                },
            )

    return vs

# -----------------------------
# Chat turn: rewrite -> retrieve -> answer
# -----------------------------

REWRITE_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system",
         "Rewrite the user's latest message into a standalone search query for a support policy KB. "
         "Use the conversation only to resolve pronouns and missing context. "
         "Return ONLY the rewritten query."),
        MessagesPlaceholder("history"),
        ("human", "{user_message}"),
    ]
)

ANSWER_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system",
         "You are a customer support assistant. Answer using ONLY the EVIDENCE provided.\n"
         "If the evidence does not contain the answer, say: "
         "\"I don't know based on the provided policy excerpts.\""),
        MessagesPlaceholder("history"),
        ("human",
         "EVIDENCE:\n{evidence}\n\n"
         "USER QUESTION:\n{user_message}\n\n"
         "Answer in 3-6 sentences. When you use evidence, cite it like [E1], [E2]."),
    ]
)

def format_evidence(docs: List[Document], max_chars: int = 380) -> Tuple[str, List[Dict[str, Any]]]:
    lines: List[str] = []
    items: List[Dict[str, Any]] = []

    for i, d in enumerate(docs, start=1):
        text = d.page_content.strip().replace("\n", " ")
        if len(text) > max_chars:
            text = text[: max_chars - 1] + "…"

        label = f"E{i}"
        lines.append(f"[{label}] {text}")

        items.append(
            {
                "label": label,
                "source": d.metadata.get("source"),
                "doc_id": d.metadata.get("doc_id"),
                "chunk_index": d.metadata.get("chunk_index"),
            }
        )

    return "\n".join(lines), items


def to_history_messages(history: List[Tuple[str, str]]) -> List[Dict[str, str]]:
    # LangChain chat history in the “dictionary format” (role/content).
    messages: List[Dict[str, str]] = []
    for user, assistant in history:
        messages.append({"role": "user", "content": user})
        messages.append({"role": "assistant", "content": assistant})
    return messages

def allowed_sources_for_query(q: str) -> Optional[List[str]]:
    """
    Cheap intent-to-sources routing using keywords.
    Returns a list of allowed `metadata["source"]` values, or None for "no filter".
    """
    s = q.lower()

    # Refund intent
    if any(k in s for k in ["refund", "refunded", "money back", "reimbursement"]):
        return ["policy/refunds", "policy/returns"]

    # Exchange intent
    if any(k in s for k in ["exchange", "swap", "replace", "replacement"]):
        return ["policy/exchanges", "policy/returns"]

    # Gift intent (gift return / gift refund rules)
    if "gift" in s:
        return ["policy/gifts", "policy/returns", "policy/refunds"]

    # Generic returns intent
    if any(k in s for k in ["return", "returned", "returning"]):
        return ["policy/returns"]

    return None

def run_chatbot(
    vector_store: Chroma,
    model_name: str,
    top_k: int,
    trace: TraceWriter,
) -> None:
    model = init_chat_model(model_name, temperature=0)
    parser = StrOutputParser()

    rewrite_chain = REWRITE_PROMPT | model | parser
    answer_chain = ANSWER_PROMPT | model | parser

    history: List[Tuple[str, str]] = []

    print("\nSupport Chatbot (private policy KB). Type 'exit' to quit.\n")

    while True:
        user_message = input("You: ").strip()
        if not user_message:
            continue
        if user_message.lower() in {"exit", "quit"}:
            break

        # Step A: rewrite to a standalone retrieval query (chatbot-specific necessity).
        history_msgs = to_history_messages(history)
        search_query = rewrite_chain.invoke({"history": history_msgs, "user_message": user_message})

        # Step B: retrieve evidence for this turn (with metadata filtering).
        allowed_sources = allowed_sources_for_query(search_query)

        search_kwargs: Dict[str, Any] = {"k": top_k}
        if allowed_sources:
            if len(allowed_sources) == 1:
                # Chroma rejects $or with a single clause
                search_kwargs["filter"] = {"source": allowed_sources[0]}
            else:
                search_kwargs["filter"] = {"$or": [{"source": src} for src in allowed_sources]}
        
        retriever = vector_store.as_retriever(search_kwargs=search_kwargs)
        retrieved = retriever.invoke(search_query)
        
        evidence_text, evidence_items = format_evidence(retrieved)

        # Step C: answer using conversation + evidence.
        answer = answer_chain.invoke(
            {
                "history": history_msgs,
                "user_message": user_message,
                "evidence": evidence_text,
            }
        )

        # Step D: append to conversation state.
        history.append((user_message, answer))

        # Step E: emit diagnostics.
        print("\n--- Turn diagnostics ---")
        print(f"Search query: {search_query}")
        if allowed_sources:
            print(f"Allowed sources: {', '.join(allowed_sources)}")
        for item in evidence_items:
            print(f"  {item['label']}: source={item['source']} doc_id={item['doc_id']} chunk={item['chunk_index']}")
        print("---\n")
        print(f"Assistant: {answer}\n")

        # Step F: trace record (one JSONL event per turn).
        trace.write(
            "turn",
            {
                "model": model_name,
                "user_message": user_message,
                "search_query": search_query,
                "evidence": evidence_items,
                "answer": answer,
            },
        )


def main() -> None:
    p = argparse.ArgumentParser(description="Support chatbot over a private policy KB (RAG).")
    p.add_argument("--persist-dir", default="./chroma_support_kb", help="Chroma persistence directory.")
    p.add_argument("--collection", default="support_policies", help="Chroma collection name.")
    p.add_argument("--rebuild-index", action="store_true", help="Rebuild the vector index on startup.")
    p.add_argument("--model", default="gpt-4.1", help="Chat model name for init_chat_model().")
    p.add_argument("--top-k", type=int, default=4, help="Number of retrieved chunks per turn.")
    p.add_argument("--trace", default="./traces/support_chatbot.jsonl", help="JSONL trace output path.")
    args = p.parse_args()

    trace = TraceWriter(Path(args.trace))
    vs = ensure_vector_store(
        persist_dir=Path(args.persist_dir),
        collection_name=args.collection,
        rebuild=args.rebuild_index,
        trace=trace,
    )

    run_chatbot(vs, model_name=args.model, top_k=args.top_k, trace=trace)


if __name__ == "__main__":
    main()


