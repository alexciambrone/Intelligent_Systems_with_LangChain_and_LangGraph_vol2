from __future__ import annotations

import argparse
import json
import os
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, TypedDict, Annotated

from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from .config import OPENAI_API_KEY  # noqa: F401


# -----------------------------
# Configuration
# -----------------------------

DEBUG = os.getenv("DEBUG", "1") == "1"

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
DEFAULT_EMBEDDINGS_MODEL = os.getenv("OPENAI_EMBEDDINGS_MODEL", "text-embedding-3-small")

DATA_DIR = Path(__file__).parent / "data_enterprise"
CHROMA_DIR = DATA_DIR / "chroma"
POLICY_JSON = DATA_DIR / "policies.json"

TOP_K = int(os.getenv("TOP_K", "4"))
ABSTAIN = "I don't know based on the provided policy excerpts."


# -----------------------------
# Small helpers
# -----------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def print_step(title: str) -> None:
    print("\n" + "=" * 90)
    print(f"[step] {title}")


def redact_pii_basic(text: str) -> Tuple[str, List[str]]:
    pii_types: List[str] = []
    out = text

    email_re = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
    if email_re.search(out):
        pii_types.append("email")
        out = email_re.sub("[REDACTED_EMAIL]", out)

    phone_re = re.compile(r"\b(\+?\d{1,3}[\s-]?)?(\(?\d{2,4}\)?[\s-]?)?\d{3,4}[\s-]?\d{3,4}\b")
    if phone_re.search(out):
        pii_types.append("phone")
        out = phone_re.sub("[REDACTED_PHONE]", out)

    cc_re = re.compile(r"\b(?:\d[ -]*?){13,16}\b")
    if cc_re.search(out):
        pii_types.append("payment_card")
        out = cc_re.sub("[REDACTED_CARD]", out)

    return out, pii_types


def simple_moderation_check(text: str) -> bool:
    banned = ["kill yourself", "suicide", "bomb", "make a bomb"]
    t = text.lower()
    return any(b in t for b in banned)


def simple_jailbreak_check(text: str) -> Tuple[bool, str]:
    t = text.lower()
    suspicious = [
        "ignore previous instructions",
        "you are not bound",
        "reveal system prompt",
        "bypass",
        "developer message",
    ]
    if any(s in t for s in suspicious):
        return False, "Possible prompt-injection attempt."
    return True, "User is asking a normal customer support question about return policy."


def _json_safe(obj: Any) -> Any:
    if isinstance(obj, BaseMessage):
        return {
            "type": obj.__class__.__name__,
            "content": obj.content,
            "additional_kwargs": getattr(obj, "additional_kwargs", {}),
            "response_metadata": getattr(obj, "response_metadata", {}),
        }
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if hasattr(obj, "model_dump"):
        try:
            return _json_safe(obj.model_dump())
        except Exception:
            pass
    return str(obj)


def debug_dump(obj: Any) -> None:
    if DEBUG:
        print(json.dumps(_json_safe(obj), indent=2, ensure_ascii=False))


# -----------------------------
# Data model / State
# -----------------------------

@dataclass
class SessionContext:
    session_id: str
    tenant_id: str
    user_id: str
    roles: List[str]


class GraphState(TypedDict, total=False):
    # Critical: this makes messages append/merge correctly inside LangGraph.
    messages: Annotated[List[BaseMessage], add_messages]

    session: Dict[str, Any]
    violation_count: int

    user_text: str
    redacted_user_text: str
    input_pii_types: List[str]
    input_moderation_flagged: bool
    jailbreak_allowed: bool
    jailbreak_reason: str

    search_query: str
    enforced_retrieval_filter: Dict[str, Any]
    raw_hits: List[Dict[str, Any]]
    retrieval_hits: List[Dict[str, Any]]
    dropped_evidence: List[Dict[str, Any]]
    evidence_text: str
    evidence_items: List[Dict[str, Any]]

    draft_answer_text: str
    final_answer_text: str
    output_pii_types: List[str]
    output_moderation_flagged: bool


def empty_state(session: SessionContext, messages: Optional[List[BaseMessage]] = None) -> GraphState:
    return {
        "session": {
            "session_id": session.session_id,
            "tenant_id": session.tenant_id,
            "user_id": session.user_id,
            "roles": session.roles,
        },
        "violation_count": 0,
        "messages": messages or [],
        # per-turn fields
        "user_text": "",
        "redacted_user_text": "",
        "input_pii_types": [],
        "input_moderation_flagged": False,
        "jailbreak_allowed": True,
        "jailbreak_reason": "",
        "search_query": "",
        "enforced_retrieval_filter": {},
        "raw_hits": [],
        "retrieval_hits": [],
        "dropped_evidence": [],
        "evidence_text": "",
        "evidence_items": [],
        "draft_answer_text": "",
        "final_answer_text": "",
        "output_pii_types": [],
        "output_moderation_flagged": False,
    }


# -----------------------------
# Enterprise policy indexing
# -----------------------------

def ensure_demo_policies() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CHROMA_DIR.mkdir(parents=True, exist_ok=True)
    if POLICY_JSON.exists():
        return

    policies = [
        {
            "doc_id": "refunds_v1#0",
            "text": (
                "Refunds: You can request a refund within 30 days of delivery. "
                "Refunds are issued to the original payment method within 5 business days "
                "after the returned item is received and inspected."
            ),
            "metadata": {
                "source": "refunds_v1",
                "version": "1",
                "tenant_id": "public",
                "sensitivity": "public",
                "allow_role_support_agent": True,
            },
        },
        {
            "doc_id": "returns_v1#0",
            "text": (
                "Returns: Items must be returned in original condition. "
                "Return shipping is free for defective items. "
                "For non-defective returns, return shipping is paid by the customer."
            ),
            "metadata": {
                "source": "returns_v1",
                "version": "1",
                "tenant_id": "public",
                "sensitivity": "public",
                "allow_role_support_agent": True,
            },
        },
        {
            "doc_id": "gifts_v1#0",
            "text": (
                "Gift purchases: If an item was purchased as a gift, refunds are issued as store credit "
                "unless the original purchaser requests a refund to the original payment method."
            ),
            "metadata": {
                "source": "gifts_v1",
                "version": "1",
                "tenant_id": "public",
                "sensitivity": "public",
                "allow_role_support_agent": True,
            },
        },
        {
            "doc_id": "vip_refunds_v1#0",
            "text": (
                "VIP refunds (tenant=vip): VIP customers can request refunds within 60 days of delivery. "
                "VIP returns are always free shipping."
            ),
            "metadata": {
                "source": "vip_refunds_v1",
                "version": "1",
                "tenant_id": "vip",
                "sensitivity": "restricted",
                "allow_role_support_agent": True,
                "allow_role_vip_agent": True,
            },
        },
    ]
    POLICY_JSON.write_text(json.dumps(policies, indent=2, ensure_ascii=False), encoding="utf-8")


def build_vectorstore(rebuild: bool = False) -> Chroma:
    ensure_demo_policies()
    embeddings = OpenAIEmbeddings(model=DEFAULT_EMBEDDINGS_MODEL)

    if rebuild and CHROMA_DIR.exists():
        for p in CHROMA_DIR.rglob("*"):
            if p.is_file():
                try:
                    p.unlink()
                except Exception:
                    pass

    vs = Chroma(
        collection_name="enterprise_policies",
        embedding_function=embeddings,
        persist_directory=str(CHROMA_DIR),
    )

    existing = 0
    try:
        existing = vs._collection.count()
    except Exception:
        existing = 0

    if rebuild or existing == 0:
        policies = json.loads(POLICY_JSON.read_text(encoding="utf-8"))
        texts = [p["text"] for p in policies]
        metadatas = []
        ids = []
        for p in policies:
            md = dict(p["metadata"])
            md["doc_id"] = p["doc_id"]
            metadatas.append(md)
            ids.append(p["doc_id"])
        vs.add_texts(texts=texts, metadatas=metadatas, ids=ids)

    return vs


# -----------------------------
# Tenant + ACL Retriever boundary
# -----------------------------

class TenantAclRetriever:
    def __init__(
        self,
        vs: Chroma,
        tenant_id: str,
        user_id: str,
        roles: List[str],
        top_k: int = 4,
        allow_shared_public: bool = True,
    ) -> None:
        self.vs = vs
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.roles = roles
        self.top_k = top_k
        self.allow_shared_public = allow_shared_public

        self.last_enforced_filter: Dict[str, Any] = {}
        self.last_retrieval_hits: List[Dict[str, Any]] = []

    def _build_filter(self) -> Dict[str, Any]:
        if not self.tenant_id:
            raise ValueError("tenant_id is required (fail closed)")

        tenant_clause: Dict[str, Any] = {"tenant_id": {"$eq": self.tenant_id}}
        if self.allow_shared_public and self.tenant_id != "public":
            tenant_clause = {"tenant_id": {"$in": [self.tenant_id, "public"]}}

        or_clauses: List[Dict[str, Any]] = [{"sensitivity": {"$eq": "public"}}]
        for r in self.roles:
            or_clauses.append({f"allow_role_{r}": {"$eq": True}})

        return {"$and": [tenant_clause, {"$or": or_clauses}]}

    def _post_check(self, docs_with_scores: List[Tuple[Any, float]]) -> List[Tuple[Any, float]]:
        out: List[Tuple[Any, float]] = []
        allowed_tenants = {self.tenant_id}
        if self.allow_shared_public and self.tenant_id != "public":
            allowed_tenants.add("public")

        for doc, score in docs_with_scores:
            meta = doc.metadata or {}
            t = meta.get("tenant_id")
            if t not in allowed_tenants:
                continue

            sensitivity = meta.get("sensitivity", "public")
            if sensitivity == "public":
                out.append((doc, score))
                continue

            ok = False
            for r in self.roles:
                if meta.get(f"allow_role_{r}") is True:
                    ok = True
                    break
            if ok:
                out.append((doc, score))

        return out

    def invoke(self, query: str) -> List[Any]:
        enforced = self._build_filter()
        self.last_enforced_filter = enforced

        raw: List[Tuple[Any, float]] = []
        try:
            raw = self.vs.similarity_search_with_score(query, k=self.top_k, filter=enforced)
        except Exception:
            raw = []

        if not raw:
            allowed_tenants = [self.tenant_id]
            if self.allow_shared_public and self.tenant_id != "public":
                allowed_tenants.append("public")

            merged: List[Tuple[Any, float]] = []
            per_tenant_k = max(self.top_k, 8)

            for t in allowed_tenants:
                try:
                    merged.extend(
                        self.vs.similarity_search_with_score(
                            query,
                            k=per_tenant_k,
                            filter={"tenant_id": {"$eq": t}},
                        )
                    )
                except Exception:
                    merged.extend(self.vs.similarity_search_with_score(query, k=per_tenant_k))

            seen = set()
            deduped: List[Tuple[Any, float]] = []
            for doc, score in merged:
                meta = doc.metadata or {}
                key = (meta.get("doc_id"), meta.get("source"), (doc.page_content or "")[:80])
                if key in seen:
                    continue
                seen.add(key)
                deduped.append((doc, score))

            raw = sorted(deduped, key=lambda x: x[1])[: per_tenant_k]

        checked = self._post_check(raw)[: self.top_k]

        hits: List[Dict[str, Any]] = []
        for doc, score in checked:
            meta = dict(doc.metadata or {})
            meta["retrieval_score"] = score
            doc.metadata = meta
            hits.append(
                {
                    "doc_id": meta.get("doc_id"),
                    "source": meta.get("source"),
                    "version": meta.get("version"),
                    "tenant_id": meta.get("tenant_id"),
                    "sensitivity": meta.get("sensitivity"),
                    "score": score,
                }
            )

        self.last_retrieval_hits = hits
        return [doc for doc, _ in checked]


# -----------------------------
# Prompting
# -----------------------------

def build_rewrite_chain(model_name: str):
    llm = init_chat_model(model_name, temperature=0)
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "Rewrite the user question into a standalone retrieval query. Be concise."),
            ("human", "{user_text}"),
        ]
    )
    return prompt | llm | StrOutputParser()


def build_answer_chain(model_name: str):
    llm = init_chat_model(model_name, temperature=0)
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a support assistant.\n"
                "Answer using ONLY the POLICY EXCERPTS.\n"
                "If the excerpts contain the answer, answer directly and cite excerpt numbers like [1].\n"
                "Only if the excerpts truly do not contain the answer, reply exactly:\n"
                f"\"{ABSTAIN}\""
            ),
            ("human", "USER QUESTION:\n{question}\n\nPOLICY EXCERPTS:\n{evidence}\n"),
        ]
    )
    return prompt | llm | StrOutputParser()


# -----------------------------
# Graph nodes
# -----------------------------

def node_prepare(state: GraphState) -> Dict[str, Any]:
    messages = state.get("messages", [])
    last = messages[-1] if messages else None
    user_text = last.content if isinstance(last, HumanMessage) else ""

    return {
        "user_text": user_text,
        "redacted_user_text": "",
        "input_pii_types": [],
        "input_moderation_flagged": False,
        "jailbreak_allowed": True,
        "jailbreak_reason": "",
        "search_query": "",
        "enforced_retrieval_filter": {},
        "retrieval_hits": [],
        "raw_hits": [],
        "dropped_evidence": [],
        "evidence_text": "",
        "evidence_items": [],
        "draft_answer_text": "",
        "final_answer_text": "",
        "output_pii_types": [],
        "output_moderation_flagged": False,
    }


def node_guard_input(state: GraphState) -> Dict[str, Any]:
    user_text = state.get("user_text", "")
    redacted, pii_types = redact_pii_basic(user_text)
    flagged = simple_moderation_check(redacted)
    allowed, reason = simple_jailbreak_check(redacted)

    return {
        "redacted_user_text": redacted,
        "input_pii_types": pii_types,
        "input_moderation_flagged": flagged,
        "jailbreak_allowed": allowed,
        "jailbreak_reason": reason,
    }


def node_rewrite_query(state: GraphState, rewrite_chain) -> Dict[str, Any]:
    q = state.get("redacted_user_text", "")
    if not q:
        return {"search_query": ""}
    rewritten = rewrite_chain.invoke({"user_text": q})
    return {"search_query": rewritten}


def node_retrieve(state: GraphState, retriever: TenantAclRetriever) -> Dict[str, Any]:
    query = state.get("search_query", "")
    if not query:
        return {"raw_hits": [], "enforced_retrieval_filter": {}, "retrieval_hits": []}

    docs = retriever.invoke(query)

    raw_hits: List[Dict[str, Any]] = []
    for d in docs:
        meta = d.metadata or {}
        raw_hits.append(
            {
                "doc_id": meta.get("doc_id"),
                "source": meta.get("source"),
                "version": meta.get("version"),
                "tenant_id": meta.get("tenant_id"),
                "sensitivity": meta.get("sensitivity"),
                "retrieval_score": meta.get("retrieval_score"),
                "text": (d.page_content or "")[:500],
            }
        )

    return {
        "raw_hits": raw_hits,
        "enforced_retrieval_filter": retriever.last_enforced_filter,
        "retrieval_hits": retriever.last_retrieval_hits,
    }


def node_sanitize_evidence(state: GraphState) -> Dict[str, Any]:
    raw_hits = state.get("raw_hits", [])
    evidence_items: List[Dict[str, Any]] = []

    for h in raw_hits:
        text = (h.get("text") or "").strip()
        if not text:
            continue
        evidence_items.append(
            {
                "doc_id": h.get("doc_id"),
                "source": h.get("source"),
                "version": h.get("version"),
                "score": h.get("retrieval_score"),
                "text": text,
            }
        )

    # Human-debug evidence text (includes ids/scores)
    evidence_text = ""
    for i, item in enumerate(evidence_items, start=1):
        evidence_text += f"[{i}] {item['doc_id']} score={item.get('score')}\n{item['text']}\n\n"

    return {
        "dropped_evidence": [],
        "evidence_items": evidence_items,
        "evidence_text": evidence_text.strip(),
    }


def node_answer(state: GraphState, answer_chain) -> Dict[str, Any]:
    question_raw = state.get("redacted_user_text", "") or ""
    question = question_raw.lower()
    items = state.get("evidence_items", []) or []

    # Build clean excerpts for the LLM
    clean: List[Tuple[int, str]] = []
    for i, it in enumerate(items, start=1):
        txt = (it.get("text") or "").strip()
        if txt:
            clean.append((i, txt))

    clean_evidence = "\n\n".join([f"[{i}] {txt}" for i, txt in clean]).strip()

    # Deterministic “obvious answers” first (prevents needless abstains)
    if "refund" in question:
        for i, txt in clean:
            if "Refunds:" in txt or "Refunds are issued" in txt:
                return {"draft_answer_text": f"Refunds are issued to the original payment method within 5 business days after the returned item is received and inspected. [{i}]"}
    if ("return" in question or "returns" in question) and ("pay" in question or "shipping" in question):
        for i, txt in clean:
            if "return shipping" in txt.lower():
                # Keep it faithful to excerpt wording
                return {"draft_answer_text": f"{txt} [{i}]"}
    if "gift" in question:
        for i, txt in clean:
            if "gift" in txt.lower():
                return {"draft_answer_text": f"{txt} [{i}]"}

    # LLM fallback
    draft = answer_chain.invoke({"question": question_raw, "evidence": clean_evidence}).strip()

    # If LLM still abstains but we have evidence, fall back to top excerpt (retriever-ranked)
    if draft == ABSTAIN and clean:
        best_i, best_txt = clean[0]
        draft = f"{best_txt} [{best_i}]"

    return {"draft_answer_text": draft}


def node_guard_output(state: GraphState) -> Dict[str, Any]:
    draft = state.get("draft_answer_text", "")
    redacted, pii_types = redact_pii_basic(draft)
    flagged = simple_moderation_check(redacted)
    return {
        "final_answer_text": redacted,
        "output_pii_types": pii_types,
        "output_moderation_flagged": flagged,
    }


def node_commit(state: GraphState) -> Dict[str, Any]:
    # With add_messages reducer, we return ONLY the new message to append.
    return {"messages": [AIMessage(content=state.get("final_answer_text", ""))]}


def should_stop_early(state: GraphState) -> bool:
    if state.get("input_moderation_flagged"):
        return True
    if not state.get("jailbreak_allowed", True):
        return True
    return False


def node_refuse(state: GraphState) -> Dict[str, Any]:
    if state.get("input_moderation_flagged"):
        msg = "I can’t help with that request."
    else:
        msg = "I can’t comply with that request."
    return {"draft_answer_text": msg}


# -----------------------------
# Graph builder
# -----------------------------

def build_graph(retriever: TenantAclRetriever, model_name: str):
    rewrite_chain = build_rewrite_chain(model_name)
    answer_chain = build_answer_chain(model_name)

    g = StateGraph(GraphState)

    g.add_node("prepare", node_prepare)
    g.add_node("guard_input", node_guard_input)
    g.add_node("rewrite_query", lambda s: node_rewrite_query(s, rewrite_chain=rewrite_chain))
    g.add_node("retrieve", lambda s: node_retrieve(s, retriever=retriever))
    g.add_node("sanitize_evidence", node_sanitize_evidence)
    g.add_node("answer", lambda s: node_answer(s, answer_chain=answer_chain))
    g.add_node("guard_output", node_guard_output)
    g.add_node("commit", node_commit)
    g.add_node("refuse", node_refuse)

    g.set_entry_point("prepare")
    g.add_edge("prepare", "guard_input")

    def route_after_guard(s: GraphState) -> str:
        return "refuse" if should_stop_early(s) else "rewrite_query"

    g.add_conditional_edges("guard_input", route_after_guard, {"refuse": "refuse", "rewrite_query": "rewrite_query"})

    g.add_edge("refuse", "guard_output")
    g.add_edge("rewrite_query", "retrieve")
    g.add_edge("retrieve", "sanitize_evidence")
    g.add_edge("sanitize_evidence", "answer")
    g.add_edge("answer", "guard_output")
    g.add_edge("guard_output", "commit")
    g.add_edge("commit", END)

    return g.compile()


# -----------------------------
# CLI
# -----------------------------

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tenant", default="public")
    parser.add_argument("--user", default="user_123")
    parser.add_argument("--roles", default="support_agent")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--rebuild-index", action="store_true")
    args = parser.parse_args()

    vs = build_vectorstore(rebuild=args.rebuild_index)

    session = SessionContext(
        session_id=str(uuid.uuid4()),
        tenant_id=args.tenant,
        user_id=args.user,
        roles=[r.strip() for r in args.roles.split(",") if r.strip()],
    )

    retriever = TenantAclRetriever(
        vs=vs,
        tenant_id=session.tenant_id,
        user_id=session.user_id,
        roles=session.roles,
        top_k=TOP_K,
        allow_shared_public=True,
    )

    graph = build_graph(retriever=retriever, model_name=args.model)

    state: GraphState = empty_state(session=session, messages=[])

    print("Safety-wrapped Support Chatbot (enterprise policy KB). Type '/exit' to quit.\n")

    while True:
        user = input("user> ").strip()
        if not user:
            continue
        if user.lower() in ("/exit", "exit", "quit"):
            break

        # IMPORTANT: with add_messages, you append by returning a delta list
        # but here (outside the graph) we just add it to the state.
        state["messages"] = (state.get("messages", []) or []) + [HumanMessage(content=user)]

        print("(running graph...)")

        # We'll maintain a local "view" of updates for debugging output.
        # The actual state inside the graph uses GraphState + add_messages.
        local_view: GraphState = dict(state)

        for event in graph.stream(state, stream_mode="updates"):
            for node_name, update in event.items():
                print_step(node_name)
                print("- update:")
                debug_dump(update)

                # Apply update to local view for human-readable tracing
                if isinstance(update, dict):
                    local_view.update(update)

                preview = {
                    "session": local_view.get("session"),
                    "violation_count": local_view.get("violation_count", 0),
                    "input": {
                        "redacted_user_text": local_view.get("redacted_user_text", ""),
                        "input_pii_types": local_view.get("input_pii_types", []),
                        "input_moderation_flagged": local_view.get("input_moderation_flagged", False),
                        "jailbreak_allowed": local_view.get("jailbreak_allowed", True),
                        "jailbreak_reason": local_view.get("jailbreak_reason", ""),
                    },
                    "retrieval": {
                        "search_query": local_view.get("search_query", ""),
                        "enforced_filter": local_view.get("enforced_retrieval_filter", {}),
                        "retrieval_hits": local_view.get("retrieval_hits", []),
                        "raw_hits_count": len(local_view.get("raw_hits", []) or []),
                        "dropped_evidence": local_view.get("dropped_evidence", []),
                        "evidence_items": local_view.get("evidence_items", []),
                        "evidence_preview": (local_view.get("evidence_text", "") or "")[:250],
                    },
                    "answer": {
                        "draft_preview": (local_view.get("draft_answer_text", "") or "")[:250],
                        "final_preview": (local_view.get("final_answer_text", "") or "")[:250],
                        "output_pii_types": local_view.get("output_pii_types", []),
                        "output_moderation_flagged": local_view.get("output_moderation_flagged", False),
                    },
                    "chat_preview": {
                        "message_count": len(local_view.get("messages", []) or []),
                        "last_user": user,
                        "last_assistant": (
                            local_view.get("final_answer_text")
                            or local_view.get("draft_answer_text")
                            or ""
                        ),
                    },
                }
                print("- state:")
                debug_dump(preview)

        # After the run, we need the real updated state for the next turn.
        # Easiest: re-run a final invoke to get final merged state.
        # But stream(updates) doesn't return the final. So we do a normal invoke.
        # This is cheap because it reuses cached vector store; and correctness > cleverness.
        final_state: GraphState = graph.invoke(state)

        # Preserve across turns
        state = final_state

        print(f"\nassistant> {state.get('final_answer_text','')}\n")


if __name__ == "__main__":
    main()