from __future__ import annotations

from typing import List, Tuple

from langchain.chat_models import init_chat_model
from langchain_core.messages import BaseMessage
from langchain_core.messages.utils import trim_messages, count_tokens_approximately
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, StateGraph, MessagesState
from .config import OPENAI_API_KEY


MAX_TOKENS = 140  # keep small so we lose early context after ~2 turns


def _render(msgs: List[BaseMessage]) -> str:
    lines = []
    for m in msgs:
        role = getattr(m, "type", m.__class__.__name__)
        lines.append(f"{role}: {m.content}")
    return "\n".join(lines)


def _trim(messages: List[BaseMessage]) -> Tuple[List[BaseMessage], int, int]:
    """
    Trim by token budget, keeping the latest messages.
    Returns (trimmed_messages, dropped_count, approx_tokens_trimmed).
    """
    #trimmed = trim_messages(
    #    messages,
    #    strategy="last",
    #    token_counter=count_tokens_approximately,
    #    max_tokens=MAX_TOKENS,
    #    start_on="human",
    #    end_on=("human", "tool"),
    #)

    trimmed = trim_messages(
        messages,
        strategy="last",
        token_counter=len, # measure budget in number of messages
        max_tokens=1, # keep at most 2 messages
    )




    dropped = len(messages) - len(trimmed)
    approx_tokens = count_tokens_approximately(trimmed)
    return trimmed, dropped, approx_tokens


def call_model(state: MessagesState) -> dict:
    full_history = state["messages"]
    trimmed, dropped, approx_tokens = _trim(full_history)

    print("\n--- FULL HISTORY (DEBUG) ---")
    print(_render(full_history))

    print("\n--- PROMPT (TRIMMED BY TOKENS) ---")
    print(f"max_tokens={MAX_TOKENS}  dropped_messages={dropped}  approx_tokens_sent={approx_tokens}")
    print(_render(trimmed))

    model = init_chat_model("gpt-4.1", temperature=0)
    response = model.invoke(trimmed)
    return {"messages": [response]}


def main() -> None:
    checkpointer = InMemorySaver()

    builder = StateGraph(MessagesState)
    builder.add_node("call_model", call_model)
    builder.add_edge(START, "call_model")
    graph = builder.compile(checkpointer=checkpointer)

    config = {"configurable": {"thread_id": "token-window-demo"}}

    # Turn 1: put the key fact early, and force a verbose reply to consume tokens.
    graph.invoke(
        {
            "messages": (
                "My order number is 12345.\n"
                "Reply with a detailed paragraph of ~90–120 words confirming you understood."
            )
        },
        config,
    )

    # Turn 2: add another fact, again force verbosity so the token budget is exceeded quickly.
    graph.invoke(
        {
            "messages": (
                "The item is headphones.\n"
                "Again, reply with a detailed paragraph of ~90–120 words."
            )
        },
        config,
    )

    # Turn 3: ask to recall the first fact.
    final_state = graph.invoke(
        {"messages": "What order number did I give you?"},
        config,
    )

    print("\n--- FINAL ANSWER ---")
    final_state["messages"][-1].pretty_print()


if __name__ == "__main__":
    main()