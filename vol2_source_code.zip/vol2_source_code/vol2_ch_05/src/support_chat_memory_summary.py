from __future__ import annotations

from typing import Optional, List

from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, SystemMessage, RemoveMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, StateGraph, MessagesState
from .config import OPENAI_API_KEY


# Keep the last N messages verbatim (this is your "high-fidelity recency window").
KEEP_LAST_MESSAGES = 4  # 2 turns (human+ai, human+ai)

# Trigger summarization once the transcript grows beyond this size.
# Keep this small so the demo triggers quickly.
MAX_MESSAGES_BEFORE_SUMMARY = 6


class State(MessagesState):
    summary: Optional[str]


def _render_messages(msgs) -> str:
    lines = []
    for m in msgs:
        lines.append(f"{m.type}: {m.content}")
    return "\n".join(lines)


# Two models: one for answering, one for summarizing.
# Using a smaller model for summarization is common, but not required.
answer_model = init_chat_model("gpt-4.1", temperature=0)
summarizer_model = init_chat_model("gpt-4.1-mini", temperature=0)


def summarize_if_needed(state: State) -> dict:
    messages = state["messages"]

    if len(messages) <= MAX_MESSAGES_BEFORE_SUMMARY:
        return {}  # no changes

    # Split the transcript into:
    # - older messages to compress into the running summary
    # - recent messages to keep verbatim
    older = messages[:-KEEP_LAST_MESSAGES]
    recent = messages[-KEEP_LAST_MESSAGES:]

    existing_summary = state.get("summary") or ""

    # The summarizer gets:
    # - the older messages (verbatim)
    # - plus a final instruction asking it to create/extend the summary
    #
    # The instruction explicitly asks to preserve identifiers verbatim.
    if existing_summary:
        instruction = (
            "You are maintaining a running summary of a customer support conversation.\n"
            f"Current summary:\n{existing_summary}\n\n"
            "Update the summary to include the NEW information from the messages above.\n"
            "Rules:\n"
            "- Preserve any identifiers (order IDs, dates, numbers) exactly as written.\n"
            "- Keep the summary under 90 words.\n"
            "- Write as plain sentences (no bullet points).\n"
        )
    else:
        instruction = (
            "Create a concise running summary of the customer support conversation above.\n"
            "Rules:\n"
            "- Preserve any identifiers (order IDs, dates, numbers) exactly as written.\n"
            "- Keep the summary under 90 words.\n"
            "- Write as plain sentences (no bullet points).\n"
        )

    summarizer_prompt = [*older, HumanMessage(content=instruction)]
    summary_response = summarizer_model.invoke(summarizer_prompt)
    new_summary = summary_response.content.strip()

    # Delete the older messages from the graph state, keeping only the recent window.
    deletions = [RemoveMessage(id=m.id) for m in older]

    print("\n--- SUMMARY UPDATED ---")
    print("Older messages summarized:")
    print(_render_messages(older))
    print("\nNew running summary:")
    print(new_summary)
    print("\nMessages kept verbatim:")
    print(_render_messages(recent))

    return {"summary": new_summary, "messages": deletions}


def call_model(state: State) -> dict:
    summary = (state.get("summary") or "").strip()

    # The answering model sees:
    # - a system message containing the running summary (if any)
    # - plus the most recent messages verbatim
    #
    # This is the hybrid pattern: "story so far" + "what just happened".
    if summary:
        system = SystemMessage(
            content=(
                "You are a customer support assistant.\n"
                "The following is a running summary of the conversation so far.\n"
                "Treat it as conversation context (what the user has said/asked), not as policy evidence.\n\n"
                f"RUNNING SUMMARY:\n{summary}\n"
            )
        )
        prompt = [system, *state["messages"]]
    else:
        prompt = state["messages"]

    response = answer_model.invoke(prompt)
    return {"messages": [response]}


def main() -> None:
    checkpointer = InMemorySaver()

    builder = StateGraph(State)
    builder.add_node("summarize_if_needed", summarize_if_needed)
    builder.add_node("call_model", call_model)
    builder.add_edge(START, "summarize_if_needed")
    builder.add_edge("summarize_if_needed", "call_model")

    graph = builder.compile(checkpointer=checkpointer)

    config = {"configurable": {"thread_id": "summary-demo-1"}}

    # A scripted conversation so the behavior is deterministic and easy to verify.
    graph.invoke({"messages": "Hi. My order ID is ORD-7781."}, config)
    graph.invoke({"messages": "I bought headphones two weeks ago and it was a gift."}, config)
    graph.invoke({"messages": "I want a refund, but I no longer have the original packaging."}, config)

    # This turn will often trigger summarization (because the transcript is now long enough).
    final_state = graph.invoke({"messages": "What order ID did I give you?"}, config)

    print("\n--- FINAL ANSWER ---")
    final_state["messages"][-1].pretty_print()

    print("\n--- FINAL STATE (FOR VERIFICATION) ---")
    print("Running summary:")
    print(final_state.get("summary") or "(none)")
    print("\nMessages currently stored in state (verbatim window):")
    print(_render_messages(final_state["messages"]))


if __name__ == "__main__":
    main()


