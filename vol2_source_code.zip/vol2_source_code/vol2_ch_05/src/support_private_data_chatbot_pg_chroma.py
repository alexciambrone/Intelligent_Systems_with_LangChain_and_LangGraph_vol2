from __future__ import annotations

import json
import os
import re
import uuid
from typing import List, Sequence, Optional, Dict, Tuple

import psycopg
from psycopg.rows import dict_row

from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.documents import Document
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from .config import OPENAI_API_KEY  # noqa: F401


# ----------------------------
# Config
# ----------------------------

DEFAULT_DB_URL = "postgresql://postgres:root@localhost:5432/episodic"
DEBUG = os.getenv("DEBUG", "1").strip().lower() not in ("0", "false", "no")


def dbg(msg: str) -> None:
    if DEBUG:
        print(msg)


# ----------------------------
# Postgres schema (transcript + episodes)
# ----------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS chat_messages (
  id          bigserial PRIMARY KEY,
  session_id  text NOT NULL,
  role        text NOT NULL CHECK (role IN ('system','user','assistant')),
  content     text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_messages_session_time_idx
ON chat_messages (session_id, created_at);

CREATE TABLE IF NOT EXISTS episodes (
  id          uuid PRIMARY KEY,
  user_id     text NOT NULL,

  -- Structured episode fields
  summary     text NOT NULL,
  outcome     text NOT NULL,
  tags        jsonb NOT NULL DEFAULT '[]'::jsonb,

  -- Optional identifiers
  case_id     text NULL,
  order_id    text NULL,

  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS episodes_user_time_idx
ON episodes (user_id, created_at);
"""


def connect() -> psycopg.Connection:
    db_url = os.getenv("DATABASE_URL", DEFAULT_DB_URL)
    if not db_url:
        raise RuntimeError("DATABASE_URL is not set (e.g., postgresql://user:pass@host:5432/db)")
    dbg(f"[db] Connecting: {db_url}")
    return psycopg.connect(db_url, row_factory=dict_row)


def ensure_schema(conn: psycopg.Connection) -> None:
    dbg("[db] Ensuring schema...")
    with conn.cursor() as cur:
        cur.execute(SCHEMA_SQL)
    conn.commit()
    dbg("[db] Schema ready.")


def insert_message(conn: psycopg.Connection, session_id: str, role: str, content: str) -> None:
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO chat_messages(session_id, role, content)
            VALUES (%s, %s, %s)
            """,
            (session_id, role, content),
        )
    conn.commit()
    dbg(f"[db] Inserted message: role={role} chars={len(content)} session_id={session_id}")


def load_transcript(conn: psycopg.Connection, session_id: str, limit: int = 50) -> List[BaseMessage]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT role, content
            FROM chat_messages
            WHERE session_id = %s
            ORDER BY created_at ASC
            LIMIT %s
            """,
            (session_id, limit),
        )
        rows = cur.fetchall()

    messages: List[BaseMessage] = []
    for r in rows:
        role = r["role"]
        content = r["content"]
        if role == "system":
            messages.append(SystemMessage(content=content))
        elif role == "user":
            messages.append(HumanMessage(content=content))
        else:
            messages.append(AIMessage(content=content))

    dbg(f"[db] Loaded transcript: {len(messages)} messages (limit={limit})")
    return messages


# ----------------------------
# Chroma setup (policy + episodes)
# ----------------------------

POLICY_CHUNKS = [
    {
        "id": "policy-1",
        "kind": "policy",
        "text": (
            "Never reveal private data from the transcript. If the user asks for private data "
            "(e.g., full chat logs, full PII, or secrets), refuse and offer a safe alternative. "
            "You may summarize at a high level if it doesn't reveal private details."
        ),
    },
    {
        "id": "policy-2",
        "kind": "policy",
        "text": (
            "PII includes emails, phone numbers, physical addresses, payment info, and any unique identifiers. "
            "If asked to output such data, refuse. If asked to confirm if something exists, respond cautiously."
        ),
    },
    {
        "id": "policy-3",
        "kind": "policy",
        "text": (
            "Episodes are short structured records created only when the user requests /close (or 'close'). "
            "Episodes should store only a brief summary, outcome, and tags. Do not store full transcripts."
        ),
    },
]


def make_embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(model="text-embedding-3-small")


def make_policy_store(persist_dir: str, embeddings: OpenAIEmbeddings) -> Chroma:
    return Chroma(
        collection_name="policy",
        embedding_function=embeddings,
        persist_directory=persist_dir,
    )


def make_episode_store(persist_dir: str, embeddings: OpenAIEmbeddings) -> Chroma:
    return Chroma(
        collection_name="episodes",
        embedding_function=embeddings,
        persist_directory=persist_dir,
    )


def seed_policy(policy_store: Chroma) -> int:
    """
    Seed policy chunks once. We do a best-effort "already seeded?" check.
    (Exact APIs differ across Chroma/LangChain versions, so we guard calls.)
    """
    existing_ids: set[str] = set()
    try:
        got = policy_store._collection.get(include=["ids"])  # type: ignore[attr-defined]
        existing_ids.update(got.get("ids") or [])
    except Exception:
        # If we can't read ids, we'll just add (Chroma may dedupe by id, depending on version).
        pass

    to_add: List[Document] = []
    to_add_ids: List[str] = []
    for chunk in POLICY_CHUNKS:
        if chunk["id"] in existing_ids:
            continue
        to_add.append(
            Document(
                page_content=chunk["text"],
                metadata={"kind": chunk["kind"], "chunk_id": chunk["id"]},
            )
        )
        to_add_ids.append(chunk["id"])

    if to_add:
        policy_store.add_documents(to_add, ids=to_add_ids)

    return len(to_add)


# ----------------------------
# Retrieval helpers
# ----------------------------

def rewrite_for_retrieval(llm: ChatOpenAI, user_text: str) -> str:
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "Rewrite the user request into a short search query (max 12 words). Output only the query."),
            ("user", "{text}"),
        ]
    )
    rewritten = (prompt | llm).invoke({"text": user_text}).content or ""
    rewritten = rewritten.strip()
    dbg(f"[retrieve] rewrite: '{user_text}' -> '{rewritten}'")
    return rewritten


def retrieve_policy(policy_store: Chroma, query: str, k: int = 4) -> List[Tuple[Document, float]]:
    hits = policy_store.similarity_search_with_score(
        query,
        k=k,
        # IMPORTANT: Chroma expects operator-style filters in many versions
        filter={"kind": {"$eq": "policy"}},
    )
    dbg(f"[retrieve] policy hits: {len(hits)} (k={k})")
    for i, (doc, score) in enumerate(hits, 1):
        dbg(f"  [policy#{i}] chunk_id={doc.metadata.get('chunk_id')} score={score:.4f}")
    return hits


def retrieve_episodes(
    conn: psycopg.Connection,
    episode_store: Chroma,
    user_id: str,
    query: str,
    k: int = 3,
) -> List[dict]:
    hits = episode_store.similarity_search_with_score(
        query,
        k=k,
        filter={
            "$and": [
                {"kind": {"$eq": "episode"}},
                {"user_id": {"$eq": user_id}},
            ]
        },
    )
    dbg(f"[retrieve] episode vector hits: {len(hits)} (k={k}) user_id={user_id}")
    episode_ids: List[str] = []
    for i, (doc, score) in enumerate(hits, 1):
        eid = doc.metadata.get("episode_id")
        dbg(f"  [episode_vec#{i}] episode_id={eid} score={score:.4f}")
        if eid:
            episode_ids.append(eid)

    if not episode_ids:
        dbg("[retrieve] episode db fetch: skipped (no vector hits)")
        return []

    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT id, summary, outcome, tags, case_id, order_id, created_at
            FROM episodes
            WHERE id = ANY(%s::uuid[])
            """,
            (episode_ids,),
        )
        rows = cur.fetchall()

    row_by_id = {str(r["id"]): r for r in rows}
    ordered = [row_by_id[eid] for eid in episode_ids if eid in row_by_id]

    dbg(f"[retrieve] episode db rows: {len(ordered)} (requested ids={len(episode_ids)})")
    for i, r in enumerate(ordered, 1):
        dbg(f"  [episode_db#{i}] id={r['id']} created_at={r['created_at']}")
    return ordered


# ----------------------------
# Episode extraction + storage
# ----------------------------

EPISODE_EXTRACT_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
You are extracting an "episode" from a support conversation.

Rules:
- Only include a short, structured memory: summary, outcome, and tags.
- Do NOT store full transcript content.
- Do NOT include any PII (emails, phone numbers, addresses, payment info).
- If the conversation includes PII, omit it and generalize.

Return JSON only with keys:
- summary: string (1-2 sentences)
- outcome: string (1 sentence)
- tags: array of short strings (3-8 tags)
- case_id: string or null (only if explicitly present as a non-sensitive ticket/case id)
- order_id: string or null (only if explicitly present as a non-sensitive order id)
""".strip(),
        ),
        MessagesPlaceholder("messages"),
    ]
)


def extract_episode(llm: ChatOpenAI, messages: List[BaseMessage]) -> dict:
    raw = (EPISODE_EXTRACT_PROMPT | llm).invoke({"messages": messages}).content or "{}"
    raw = raw.strip()
    raw = re.sub(r"^```json\s*", "", raw)
    raw = re.sub(r"^```\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    dbg("[episode] extractor raw json:")
    dbg(raw if len(raw) < 2000 else raw[:2000] + " ...<truncated>")

    try:
        data = json.loads(raw)
    except Exception:
        data = {}

    summary = str(data.get("summary") or "").strip()
    outcome = str(data.get("outcome") or "").strip()
    tags = data.get("tags") or []
    if not isinstance(tags, list):
        tags = []
    tags = [str(t).strip() for t in tags if str(t).strip()]

    case_id = data.get("case_id")
    order_id = data.get("order_id")
    case_id = str(case_id).strip() if case_id not in (None, "", "null") else None
    order_id = str(order_id).strip() if order_id not in (None, "", "null") else None

    cleaned = {
        "summary": summary[:500],
        "outcome": outcome[:300],
        "tags": tags[:12],
        "case_id": case_id,
        "order_id": order_id,
    }

    dbg("[episode] extractor parsed (cleaned):")
    dbg(json.dumps(cleaned, ensure_ascii=False, indent=2))
    return cleaned


def store_episode(
    conn: psycopg.Connection,
    episode_store: Chroma,
    user_id: str,
    summary: str,
    outcome: str,
    tags: Sequence[str],
    case_id: Optional[str],
    order_id: Optional[str],
) -> str:
    episode_id = str(uuid.uuid4())

    dbg(f"[episode] storing: user_id={user_id} episode_id={episode_id}")
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO episodes(id, user_id, summary, outcome, tags, case_id, order_id)
            VALUES (%s, %s, %s, %s, %s::jsonb, %s, %s)
            """,
            (episode_id, user_id, summary, outcome, json.dumps(list(tags)), case_id, order_id),
        )
    conn.commit()
    dbg("[episode] stored in Postgres.")

    # Vector side: compact embedding text (NOT the transcript)
    text_for_embedding = f"summary: {summary}\noutcome: {outcome}\ntags: {', '.join(tags)}"

    # IMPORTANT: avoid None metadata values (some Chroma versions reject them)
    meta: Dict[str, object] = {"kind": "episode", "user_id": user_id, "episode_id": episode_id}
    if case_id is not None:
        meta["case_id"] = case_id
    if order_id is not None:
        meta["order_id"] = order_id

    doc = Document(page_content=text_for_embedding, metadata=meta)
    episode_store.add_documents([doc], ids=[episode_id])
    dbg("[episode] stored in Chroma vectors.")

    return episode_id


def count_episodes(conn: psycopg.Connection, user_id: str) -> int:
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM episodes WHERE user_id=%s", (user_id,))
        row = cur.fetchone()
    return int(row["n"])


# ----------------------------
# Answering
# ----------------------------

ANSWER_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
You are a support chatbot.

You have:
- The transcript for this session (messages).
- Retrieved policy excerpts (policy_text).
- Retrieved episodic memories (episode_text).

Follow policy strictly. Never reveal private transcript data. If user requests private data, refuse.
If the user asks about a past situation, you may use episodes, but do not invent details.

Keep responses helpful and concise.
""".strip(),
        ),
        MessagesPlaceholder("messages"),
        ("system", "Policy excerpts:\n{policy_text}\n\nEpisode summaries:\n{episode_text}"),
        ("user", "{user_text}"),
    ]
)


def format_policy_chunks(chunks: List[Tuple[Document, float]]) -> str:
    if not chunks:
        return "(none)"
    lines = []
    for doc, score in chunks:
        cid = doc.metadata.get("chunk_id", "unknown")
        lines.append(f"[{cid}] {doc.page_content} (score={score:.4f})")
    return "\n".join(lines)


def format_episodes(rows: List[dict]) -> str:
    if not rows:
        return "(none)"
    out = []
    for r in rows:
        tags = r.get("tags") or []
        try:
            if isinstance(tags, str):
                tags = json.loads(tags)
        except Exception:
            tags = []
        tag_str = ", ".join(tags) if isinstance(tags, list) else ""
        out.append(
            f"- summary: {r.get('summary','')}\n"
            f"  outcome: {r.get('outcome','')}\n"
            f"  tags: {tag_str}"
        )
    return "\n".join(out)


def answer(
    llm: ChatOpenAI,
    messages: List[BaseMessage],
    policy_chunks: List[Tuple[Document, float]],
    episodes: List[dict],
    user_text: str,
) -> str:
    policy_text = format_policy_chunks(policy_chunks)
    episode_text = format_episodes(episodes)

    dbg("[prompt] injecting policy_text:")
    dbg(policy_text if len(policy_text) < 1500 else policy_text[:1500] + " ...<truncated>")
    dbg("[prompt] injecting episode_text:")
    dbg(episode_text if len(episode_text) < 1500 else episode_text[:1500] + " ...<truncated>")

    msg = (ANSWER_PROMPT | llm).invoke(
        {
            "messages": messages,
            "policy_text": policy_text,
            "episode_text": episode_text,
            "user_text": user_text,
        }
    )
    return (msg.content or "").strip()


# ----------------------------
# CLI loop
# ----------------------------

def main() -> None:
    persist_dir = os.getenv("CHROMA_DIR", ".chroma_pg_chroma")
    os.makedirs(persist_dir, exist_ok=True)

    conn = connect()
    ensure_schema(conn)

    embeddings = make_embeddings()
    policy_store = make_policy_store(persist_dir, embeddings)
    episode_store = make_episode_store(persist_dir, embeddings)

    added = seed_policy(policy_store)
    dbg(f"[init] Seeded policy chunks into Chroma: {added}")

    llm = ChatOpenAI(model=os.getenv("CHAT_MODEL", "gpt-4o-mini"), temperature=0)

    print("Support chatbot (Postgres transcript + Chroma vectors)")
    session_id = os.getenv("SESSION_ID", "session-1")
    user_id = os.getenv("USER_ID", "user-123")
    print(f"session_id={session_id}  user_id={user_id}")
    print("Commands: /exit | /close (or 'close') to extract & store episode\n")

    # Ensure we have at least one system message
    insert_message(conn, session_id, "system", "System initialized.")

    dbg(f"[db] episodes currently for user_id={user_id}: {count_episodes(conn, user_id)}")

    while True:
        try:
            user_text = input("user> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nbye")
            return

        if not user_text:
            continue

        if user_text == "/exit":
            print("bye")
            return

        # Accept both "/close" and "close" (your transcript showed you typed "close")
        if user_text in ("/close", "close"):
            dbg("[episode] close command received; extracting episode from transcript...")
            transcript = load_transcript(conn, session_id, limit=200)
            episode = extract_episode(llm, transcript)

            episode_id = store_episode(
                conn=conn,
                episode_store=episode_store,
                user_id=user_id,
                summary=episode["summary"],
                outcome=episode["outcome"],
                tags=episode["tags"],
                case_id=episode.get("case_id"),
                order_id=episode.get("order_id"),
            )
            dbg(f"[episode] stored OK: id={episode_id}")
            dbg(f"[db] episodes now for user_id={user_id}: {count_episodes(conn, user_id)}")
            print(f"[episode stored] id={episode_id}\n")
            continue

        # Store user message
        insert_message(conn, session_id, "user", user_text)

        # Load transcript (after insert), retrieve context
        transcript = load_transcript(conn, session_id, limit=50)

        rewritten = rewrite_for_retrieval(llm, user_text)
        policy_chunks = retrieve_policy(policy_store, rewritten, k=4)
        episodes = retrieve_episodes(conn, episode_store, user_id, rewritten, k=3)

        # Answer and store assistant message
        assistant_text = answer(llm, transcript, policy_chunks, episodes, user_text)
        print(assistant_text + "\n")
        insert_message(conn, session_id, "assistant", assistant_text)


if __name__ == "__main__":
    main()