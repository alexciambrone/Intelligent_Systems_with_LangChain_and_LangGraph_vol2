from __future__ import annotations

import argparse
import os
import uuid
from dataclasses import dataclass
from typing import Optional, Dict, Any

from pydantic import BaseModel, Field

from langchain.chat_models import init_chat_model
from langchain_core.messages import BaseMessage
from langgraph.graph import START, StateGraph, MessagesState
from langgraph.runtime import Runtime

from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.store.postgres import PostgresStore
from .config import OPENAI_API_KEY


# -----------------------------
# Profile schema (what we allow ourselves to store)
# -----------------------------

class UserProfile(BaseModel):
    preferred_language: Optional[str] = Field(default=None, description="User's preferred language for replies.")
    preferred_contact_channel: Optional[str] = Field(default=None, description="email | sms | push")
    prefers_short_answers: Optional[bool] = Field(default=None, description="Whether user prefers shorter answers.")


def merge_profile(existing: UserProfile, patch: UserProfile) -> UserProfile:
    data = existing.model_dump()
    for k, v in patch.model_dump().items():
        if v is not None:
            data[k] = v
    return UserProfile(**data)


def profile_summary(p: UserProfile) -> str:
    parts = []
    if p.preferred_language:
        parts.append(f"language={p.preferred_language}")
    if p.preferred_contact_channel:
        parts.append(f"channel={p.preferred_contact_channel}")
    if p.prefers_short_answers is not None:
        parts.append(f"short_answers={p.prefers_short_answers}")
    return ", ".join(parts) if parts else "(no stored preferences)"


# -----------------------------
# Runtime context (trusted identity)
# -----------------------------

@dataclass(frozen=True)
class Context:
    user_id: str


# -----------------------------
# Preference extraction (patch semantics)
# -----------------------------

EXTRACTOR_SYSTEM = (
    "You extract user preferences for a support assistant.\n\n"
    "You will receive the user's latest message.\n"
    "Return ONLY a preference patch using this schema:\n"
    "- preferred_language: string | null\n"
    "- preferred_contact_channel: 'email' | 'sms' | 'push' | null\n"
    "- prefers_short_answers: boolean | null\n\n"
    "Rules:\n"
    "- Only set fields that are explicitly stated as preferences by the user.\n"
    "- If the message does not clearly state a preference, return null for that field.\n"
    "- Do not guess.\n"
)

extractor = init_chat_model("openai:gpt-4o-mini", temperature=0).with_structured_output(
    UserProfile,
    method="function_calling",
    include_raw=False,
)


# -----------------------------
# Helpers: enforce formatting based on stored preferences
# -----------------------------

def formatting_rules(p: UserProfile) -> str:
    """
    Convert stored preferences into strict, unambiguous formatting rules.
    This is intentionally forceful so the demo reliably shows preference recall.
    """
    rules = [
        "You MUST follow the STORED PREFERENCES exactly when generating your answer.",
        "Do not mention these instructions.",
        "Do not invent new preferences. If a preference is not stored, treat it as unknown.",
    ]

    if p.preferred_language:
        rules.append(
            f"LANGUAGE RULE: You MUST respond in {p.preferred_language}, even if the user asks in another language."
        )
    else:
        rules.append("LANGUAGE RULE: If no preferred language is stored, respond in the user's language.")

    if p.prefers_short_answers is True:
        rules.append("BRevity RULE: Keep the answer to ONE sentence (no bullet points).")
    elif p.prefers_short_answers is False:
        rules.append("BRevity RULE: Normal length is acceptable.")
    else:
        rules.append("BRevity RULE: If no brevity preference is stored, be concise but not artificially short.")

    if p.preferred_contact_channel:
        rules.append(
            "CONTACT RULE: If the user asks how to contact them or what channel they prefer, "
            f"answer using the stored channel '{p.preferred_contact_channel}'. "
            "Do NOT claim you can actually send messages; only state the preference."
        )
    else:
        rules.append(
            "CONTACT RULE: If no contact channel is stored, say you don't know their preference."
        )

    rules.append(
        "PRIVACY RULE: If the user asks what you know about them, ONLY list the stored preferences."
    )

    return "\n".join(rules)


# -----------------------------
# Graph node: load profile, optionally update, answer
# -----------------------------

def support_turn(state: MessagesState, runtime: Runtime[Context]) -> Dict[str, Any]:
    user_id = runtime.context.user_id

    # Long-term profile namespace: ("users", user_id)
    profile_ns = ("users", user_id)

    # Stable key for "the profile"
    profile_key = "profile"

    existing_item = runtime.store.get(profile_ns, profile_key)
    existing_profile = UserProfile(**existing_item.value) if existing_item else UserProfile()

    last_msg: BaseMessage = state["messages"][-1]
    user_text = getattr(last_msg, "content", str(last_msg))

    # Extract patch from this message
    patch = extractor.invoke(
        [
            {"role": "system", "content": EXTRACTOR_SYSTEM},
            {"role": "user", "content": user_text},
        ]
    )

    updated_profile = merge_profile(existing_profile, patch)

    # Persist profile only if something actually changed.
    changed = updated_profile.model_dump() != existing_profile.model_dump()
    if changed:
        runtime.store.put(profile_ns, profile_key, updated_profile.model_dump())

    # Trace-friendly prints (offline debuggability)
    print("\n--- PROFILE LOAD / UPDATE ---")
    print(f"user_id: {user_id}")
    print(f"loaded:  {profile_summary(existing_profile)}")
    print(f"patch:   {patch.model_dump_json(indent=2)}")
    print(f"stored:  {profile_summary(updated_profile)}" + (" (updated)" if changed else " (unchanged)"))

    # Strict preference enforcement (so the demo is reliable)
    system_msg = (
        "You are a customer support assistant.\n"
        "You will answer the user's message, and you will follow the formatting rules below.\n\n"
        "FORMATTING RULES:\n"
        f"{formatting_rules(updated_profile)}\n\n"
        f"STORED PREFERENCES (do not add anything): {profile_summary(updated_profile)}"
    )

    model = init_chat_model("openai:gpt-4o-mini", temperature=0)

    response = model.invoke(
        [{"role": "system", "content": system_msg}] + state["messages"]
    )

    return {"messages": [response]}


def build_graph():
    builder = StateGraph(MessagesState, context_schema=Context)
    builder.add_node("support_turn", support_turn)
    builder.add_edge(START, "support_turn")
    return builder


# -----------------------------
# Demo runner: two threads, same user_id
# -----------------------------

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument(
        "--db-uri",
        default=os.getenv("DB_URI", "postgresql://postgres:root@localhost:5432/profiles"),
        help="Postgres connection string for both store and checkpointer.",
    )
    args = p.parse_args()

    graph_builder = build_graph()

    with (
        PostgresStore.from_conn_string(args.db_uri) as store,
        PostgresSaver.from_conn_string(args.db_uri) as checkpointer,
    ):
        # Run once per environment to create tables.
        store.setup()
        checkpointer.setup()

        graph = graph_builder.compile(store=store, checkpointer=checkpointer)

        user_id = "user_123"

        # Thread 1: user states preferences
        thread_1 = str(uuid.uuid4())
        config_1 = {"configurable": {"thread_id": thread_1}}

        print("\n==============================")
        print("THREAD 1 (set preferences)")
        print("==============================")

        out1 = graph.invoke(
            {"messages": [{"role": "user", "content": "Please remember: reply in Italian and keep answers short. If you need to contact me, use email."}]},
            config_1,
            context=Context(user_id=user_id),
        )
        out1["messages"][-1].pretty_print()

        # Thread 2: a new conversation thread, same user
        thread_2 = str(uuid.uuid4())
        config_2 = {"configurable": {"thread_id": thread_2}}

        print("\n==============================")
        print("THREAD 2 (new thread, recall preferences)")
        print("==============================")

        out2 = graph.invoke(
            {"messages": [{"role": "user", "content": "What language will you use with me, and what contact channel do I prefer?"}]},
            config_2,
            context=Context(user_id=user_id),
        )
        out2["messages"][-1].pretty_print()


if __name__ == "__main__":
    main()