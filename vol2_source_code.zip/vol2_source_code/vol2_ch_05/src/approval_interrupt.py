from __future__ import annotations

from typing import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, END, StateGraph
from langgraph.types import Command, interrupt

class State(TypedDict):
    action: str
    approved: bool

def propose_action(state: State) -> dict:
    return {"action": "issue_refund(order_id='ORD-7781', amount_eur=129.99)"}

def require_approval(state: State) -> dict:
    # The payload is surfaced to the caller in __interrupt__.
    approved = interrupt({"needs_approval": True, "proposed_action": state["action"]})
    return {"approved": bool(approved)}

def execute(state: State) -> dict:
    if not state["approved"]:
        return {"action": "CANCELLED"}
    # Tool execution would happen here.
    return {"action": f"EXECUTED: {state['action']}"}

checkpointer = InMemorySaver()

graph = (
    StateGraph(State)
    .add_node("propose", propose_action)
    .add_node("approve", require_approval)
    .add_node("execute", execute)
    .add_edge(START, "propose")
    .add_edge("propose", "approve")
    .add_edge("approve", "execute")
    .add_edge("execute", END)
    .compile(checkpointer=checkpointer)
)

config = {"configurable": {"thread_id": "refund-approval-demo"}}

# First run pauses at the interrupt.
paused = graph.invoke({}, config=config)
print(paused["__interrupt__"][0].value)

# Resume with a decision.
final = graph.invoke(Command(resume=True), config=config)
print(final["action"])

