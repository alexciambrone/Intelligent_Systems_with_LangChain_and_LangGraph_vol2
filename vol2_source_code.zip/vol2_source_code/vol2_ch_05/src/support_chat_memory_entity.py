from __future__ import annotations

from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_core.messages.utils import trim_messages
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from .config import OPENAI_API_KEY  # noqa: F401


# How many recent chat messages we keep verbatim in the answer prompt.
# This is intentionally small to demonstrate "window memory" loss.
PROMPT_LAST_MESSAGES = 2


class SupportCase(BaseModel):
    order_id: Optional[str] = Field(default=None)
    product: Optional[str] = Field(default=None)
    purchase_timing: Optional[str] = Field(default=None)
    is_gift: Optional[bool] = Field(default=None)
    issue: Optional[str] = Field(default=None)
    desired_outcome: Optional[str] = Field(default=None)


class State(BaseModel):
    messages: List[BaseMessage] = Field(default_factory=list)
    case: SupportCase = Field(default_factory=SupportCase)


answer_model = init_chat_model("gpt-4.1", temperature=0)

# Extract a PATCH only: fields not mentioned should stay null in the patch.
case_extractor = init_chat_model("gpt-4.1-mini", temperature=0).with_structured_output(
    SupportCase,
    method="function_calling",
    include_raw=False,
)


def case_summary(case: SupportCase) -> str:
    parts = []
    if case.order_id:
        parts.append(f"order_id={case.order_id}")
    if case.product:
        parts.append(f"product={case.product}")
    if case.purchase_timing:
        parts.append(f"purchase_timing={case.purchase_timing}")
    if case.is_gift is not None:
        parts.append(f"is_gift={case.is_gift}")
    if case.issue:
        parts.append(f"issue={case.issue}")
    if case.desired_outcome:
        parts.append(f"desired_outcome={case.desired_outcome}")
    return ", ".join(parts) if parts else "(empty)"


def merge_case(existing: SupportCase, patch: SupportCase) -> SupportCase:
    merged = existing.model_dump()
    for k, v in patch.model_dump().items():
        if v is not None:
            merged[k] = v
    return SupportCase(**merged)


def extract_case_patch(existing: SupportCase, new_human: HumanMessage) -> SupportCase:
    prompt = [
        SystemMessage(
            content=(
                "You update a support CASE FILE.\n\n"
                "You will receive:\n"
                "1) CURRENT CASE FILE (authoritative so far)\n"
                "2) NEW USER MESSAGE (this turn only)\n\n"
                "Task:\n"
                "- Extract ONLY new or corrected facts from NEW USER MESSAGE.\n"
                "- If a field is not mentioned or not corrected, output null for that field.\n"
                "- Do not guess.\n"
                "- Do not restate old facts unless NEW USER MESSAGE changes them.\n\n"
                f"CURRENT CASE FILE:\n{existing.model_dump_json(indent=2)}\n"
            )
        ),
        new_human,
    ]
    return case_extractor.invoke(prompt)


def answer_with_case(case: SupportCase, messages: List[BaseMessage]) -> AIMessage:
    # Keep only a tiny window of chat messages verbatim.
    recent = trim_messages(
        messages,
        strategy="last",
        token_counter=len,   # message-count window for the demo
        max_tokens=PROMPT_LAST_MESSAGES,
    )

    system = SystemMessage(
        content=(
            "You are a customer support assistant.\n"
            "Use the CASE FILE to avoid asking the user to repeat stable facts.\n"
            "Treat the CASE FILE as conversation-derived context, not as policy evidence.\n\n"
            f"CASE FILE SUMMARY: {case_summary(case)}\n"
            f"CASE FILE (JSON):\n{case.model_dump_json(indent=2)}\n"
        )
    )

    # For teaching: print what the model actually sees.
    print("\n--- PROMPT WINDOW (LAST MESSAGES) ---")
    for m in recent:
        print(f"{m.type}: {m.content}")

    return answer_model.invoke([system, *recent])


def step(state: State) -> Dict[str, Any]:
    """
    One processing step runs after each incoming user message:
    1) extract patch from the NEW human message
    2) merge into case file
    3) call the model to get an AI response (with tiny chat window + case file)
    4) append AI response to messages
    5) print a clean turn transcript
    """
    if not state.messages or state.messages[-1].type != "human":
        # Nothing to do unless the latest message is human.
        return {}

    human = state.messages[-1]
    assert isinstance(human, HumanMessage)

    before = state.case

    patch = extract_case_patch(before, human)
    after = merge_case(before, patch)

    print("\n--- TURN ---")
    print(f"HUMAN: {human.content}")

    print("\n--- CASE PATCH (THIS TURN) ---")
    print(patch.model_dump_json(indent=2))

    print("\n--- CASE (MERGED) ---")
    print(after.model_dump_json(indent=2))
    print(f"CASE SUMMARY: {case_summary(after)}")

    # Get AI response using updated case + tiny verbatim window
    ai = answer_with_case(after, state.messages)

    print("\nAI:", ai.content)

    # Update state: store new case + append AI message
    return {"case": after, "messages": state.messages + [ai]}


def build_graph() -> CompiledStateGraph:
    checkpointer = InMemorySaver()

    g = StateGraph(State)
    g.add_node("step", step)
    g.add_edge(START, "step")

    return g.compile(checkpointer=checkpointer)


def main() -> None:
    graph = build_graph()
    config = {"configurable": {"thread_id": "entity-demo-clean"}}

    # Turn 1
    state = graph.invoke(
        {"messages": [HumanMessage(content="Hi. My order ID is ORD-7781. I bought headphones two weeks ago and it was a gift.")]},
        config,
    )

    # Turn 2 (no repetition of stable facts)
    state = graph.invoke(
        {"messages": state["messages"] + [HumanMessage(content="The left earcup is defective. I want a replacement, not a refund.")]},
        config,
    )

    # Turn 3: ask for early fact to demonstrate: chat window forgets, case remembers
    state = graph.invoke(
        {"messages": state["messages"] + [HumanMessage(content="What order ID did I give you?")]},
        config,
    )

    print("\n--- FINAL CASE FILE ---")
    print(state["case"].model_dump_json(indent=2))


if __name__ == "__main__":
    main()